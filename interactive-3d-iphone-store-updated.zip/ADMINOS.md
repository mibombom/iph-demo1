# AdminOS — Enterprise Administration and Management Portal

The admin portal of this project is **AdminOS**: a complete enterprise administration
workspace implementing the official **245-function checklist** (Modules A–O), plus the
preserved 115 storefront commerce functions.

## Access (one login for everyone)

1. Open the site → account menu (top right) → **Sign in** — the regular login form.
2. Sign in with the admin credentials (demo: `admin` / `admin123`,
   alias `admin@aura.store`): the AdminOS portal opens automatically.
   **Without these credentials the portal renders nothing else** — there is
   no separate admin login panel and no account-menu entry.
3. Sessions expire after 12 hours; sign out returns to the store.

## What's inside

| Area | Content |
|---|---|
| Overview | Executive dashboard, customizable widgets, KPIs, activity feed, quick actions, date filters, comparison, export, sharing |
| Users | Directory, create/edit/delete, import/export CSV (with row-level error reports), bulk ops, lifecycle (activate/suspend/deactivate/restore), groups, tags, sessions, verification |
| Roles & Permissions | Role CRUD, permission matrix (module × action), granular/resource/field-level grants, temporary permissions, SoD check, access review |
| Security | Sessions, login history, security events, devices, IP rules, password policy, recovery tokens, incidents |
| Records | Universal record manager, custom types/fields/forms, saved views, advanced filtering, archive/restore, duplicate detection, import mapping + validation |
| Workflows | Approval inbox with real status transitions (submit/approve/reject/resubmit/escalate/comment), workflow versioning, tasks with dependencies |
| Communications | Notification center, templates with rendered preview, scheduling, announcements, delivery status (external sends are **simulated**) |
| Finance | Financial dashboard, invoices (live tax calculation), transactions, expenses, budgets with variance, receipts, refunds, reconciliation report |
| Analytics | Report builder, prebuilt reports, interactive charts with drill-down, comparative/trend/anomaly analysis (real 2σ math), scheduling, freshness |
| Documents | Library with validated uploads (type/size), versioning, sharing, expiry scan, content pages with publish/revert |
| Integrations | Directory (simulated providers labeled), config/credential rotation, webhooks with test deliveries, API keys, rate limits, usage |
| Automation | Rules with pause/resume, background job queue with run/retry/failure drills, rule-violation scans |
| System | Health, maintenance mode, error monitoring, migrations, **real JSON backup + restore**, environment template (no secrets) |
| Audit & Compliance | Central immutable audit log, search/export, privacy requests, deletion workflow with retention, consent, classifications, evidence, compliance tasks |
| Collaboration | Task board (list/board/calendar), workspaces, comments, attachments, announcements, onboarding checklist |
| Help & Support | Tickets with SLA + escalation, knowledge base, FAQ manager, feedback |
| Catalog / Matrix | All 245 functions executable; requirements matrix maps each to UI, data, permission, validation, error handling and status |

Command palette: **⌘K / Ctrl+K** — jump to any page or execute any of the 245 functions.

## Honest scope (simulated vs real)

- **Real & persistent:** all CRUD and status changes, permission checks, workflow
  transitions, validation, audit trail, CSV exports/imports, JSON backup/restore,
  reports computed from actual store data. State persists in the browser store.
- **Explicitly simulated (labeled in-UI):** payment gateway, email/SMS/push delivery,
  SSO/external integrations, webhook endpoints. No real payment, email or SMS leaves
  this system — delivery rows are marked as simulations.
- **Demo data:** the seeded dataset is development-only and clearly marked.

## Automated check

```bash
node scripts/verify-adminos.mjs   # registry conformance: 245 unique numbered functions, modules A–O complete
```

## Deliverables map

1. Frontend source — `src/` (React + TypeScript + Tailwind + framer-motion)
2. Simulated backend/engine — `src/context/AdminOS.tsx` (stores, RBAC seam, audit, jobs, executor)
3. Registry + requirements matrix — `src/data/adminos.ts` (245 entries with DB/validation/error mapping)
4. Demo seed data — `src/data/adminos-seed.ts`
5. Conformance test — `scripts/verify-adminos.mjs`
6. This guide — `ADMINOS.md`
7. For a production deployment: move the engine mutations behind a PostgreSQL-backed API,
   keep the same permission/validation seams, configure real providers server-side, and use
   the initial-admin setup flow instead of demo credentials.
