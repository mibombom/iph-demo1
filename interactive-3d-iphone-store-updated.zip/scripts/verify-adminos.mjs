/**
 * AdminOS registry conformance check (automated test).
 * Run: node scripts/verify-adminos.mjs
 * Asserts the 245-function checklist is complete, unique, and executable.
 */
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const src = readFileSync(join(root, "src/data/adminos.ts"), "utf8");

let failed = 0;
const assert = (cond, msg) => {
  if (cond) console.log(`  ok  ${msg}`);
  else { console.error(`FAIL  ${msg}`); failed += 1; }
};

// Count f(...) registry entries and extract their numbers
const nums = [...src.matchAll(/\bf\((\d+),/g)].map((m) => Number(m[1]));
console.log(`AdminOS conformance check — ${nums.length} registry entries found`);

assert(nums.length === 245, `exactly 245 numbered functions (found ${nums.length})`);
const unique = new Set(nums);
assert(unique.size === 245, `all numbers unique (${unique.size} distinct)`);
const missing = [];
for (let i = 1; i <= 245; i++) if (!unique.has(i)) missing.push(i);
assert(missing.length === 0, `numbers 1..245 all present${missing.length ? ` — missing ${missing.join(",")}` : ""}`);

// Every entry must declare a known operation kind
const opKinds = [...src.matchAll(/k: "(nav|export|import|flag|set|entity|job|notify|flow|report|backup|restore)"/g)].map((m) => m[1]);
assert(opKinds.length >= 245, `every function declares an executable op (${opKinds.length} op declarations)`);

// Modules A–O must each cover their range
const ranges = { A: [1, 15], B: [16, 35], C: [36, 50], D: [51, 70], E: [71, 90], F: [91, 105], G: [106, 120], H: [121, 140], I: [141, 155], J: [156, 170], K: [171, 185], L: [186, 200], M: [201, 215], N: [216, 230], O: [231, 245] };
const moduleTags = [...src.matchAll(/\bf\(\d+, "[^"]+", "[^"]+", "([A-O])"/g)].map((m) => m[1]);
for (const [mod, [lo, hi]] of Object.entries(ranges)) {
  const count = moduleTags.filter((t) => t === mod).length;
  assert(count === hi - lo + 1, `module ${mod} covers ${lo}–${hi} (${count} entries)`);
}

// Honesty rule: external-simulated functions must be labeled
const externalCount = (src.match(/"external"/g) ?? []).length;
assert(externalCount > 0, `external-provider functions are explicitly labeled (${externalCount} labels incl. declarations)`);

console.log(failed === 0 ? "\nPASS — AdminOS registry is conformant." : `\n${failed} assertion(s) failed.`);
process.exit(failed === 0 ? 0 : 1);
