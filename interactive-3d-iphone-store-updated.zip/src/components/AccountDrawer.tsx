import { useEffect, useRef } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { LogOut, Package, Truck, X } from "lucide-react";
import { useAuth } from "../context/Auth";
import { useScrollLock } from "../lib/scroll";
import { fmt } from "../data/products";

function initials(name: string) {
  return name
    .split(" ")
    .map((p) => p[0])
    .filter(Boolean)
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

export default function AccountDrawer() {
  const { user, orders, accountOpen, closeAccount, signOut } = useAuth();
  const closeRef = useRef<HTMLButtonElement>(null);

  // Freeze the homepage while the account panel is open
  useScrollLock(accountOpen);

  useEffect(() => {
    if (!accountOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && closeAccount();
    window.addEventListener("keydown", onKey);
    setTimeout(() => closeRef.current?.focus(), 80);
    return () => {
      window.removeEventListener("keydown", onKey);
    };
  }, [accountOpen, closeAccount]);

  const totalSpent = orders.reduce((n, o) => n + o.total, 0);

  return (
    <AnimatePresence>
      {accountOpen && user && (
        <>
          <motion.div
            key="acct-scrim"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={closeAccount}
            aria-hidden="true"
            className="fixed inset-0 z-[70] bg-ink/45 backdrop-blur-sm"
          />
          <motion.aside
            key="acct-panel"
            role="dialog"
            aria-modal="true"
            aria-label="Your account"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 300 }}
            className="fixed bottom-0 right-0 top-0 z-[80] flex w-full max-w-md flex-col bg-bone shadow-2xl"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-line px-6 py-4">
              <h2 className="text-[18px] font-bold tracking-tight">Your account</h2>
              <button
                ref={closeRef}
                onClick={closeAccount}
                aria-label="Close account panel"
                className="grid size-10 place-items-center rounded-full transition-colors hover:bg-ink/5"
              >
                <X className="size-5" strokeWidth={1.8} />
              </button>
            </div>

            <div data-lenis-prevent className="slim-scroll overscroll-contain flex-1 overflow-y-auto px-6 py-6">
              {/* Profile */}
              <div className="flex items-center gap-4 rounded-[26px] panel-dark p-5">
                <span className="grid size-14 shrink-0 place-items-center rounded-full bg-accent text-[19px] font-bold tracking-wide" aria-hidden="true">
                  {initials(user.name)}
                </span>
                <div className="min-w-0">
                  <p className="truncate text-[17px] font-bold">{user.name}</p>
                  <p className="truncate text-[13px] text-white/55">{user.email}</p>
                  <p className="mt-1 text-[11.5px] uppercase tracking-[0.14em] text-white/35">
                    Member since {new Date(user.joinedAt).toLocaleDateString("en-US", { month: "short", year: "numeric" })}
                  </p>
                </div>
              </div>

              {/* Stats */}
              <dl className="mt-4 grid grid-cols-2 gap-3">
                {[
                  { label: "Orders", value: String(orders.length) },
                  { label: "Lifetime spend", value: fmt(totalSpent) },
                ].map((s) => (
                  <div key={s.label} className="rounded-3xl surface p-4 text-center hairline">
                    <dd className="display-tight text-[24px] font-bold">{s.value}</dd>
                    <dt className="mt-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-faint">{s.label}</dt>
                  </div>
                ))}
              </dl>

              {/* Saved details */}
              {user.details && (
                <div className="mt-4 rounded-3xl surface p-5 hairline">
                  <h3 className="eyebrow text-ink-faint">Saved details</h3>
                  <p className="mt-3 text-[13.5px] font-semibold">{user.details.name}</p>
                  <p className="text-[12.5px] text-ink-soft">{user.details.email}</p>
                  <p className="mt-1 text-[12.5px] text-ink-soft">
                    {user.details.address}, {user.details.city} {user.details.zip}
                  </p>
                  <p className="mt-3 border-t border-line pt-3 text-[11px] leading-relaxed text-ink-faint">
                    Prefilled at checkout for faster orders. Payment info is never stored.
                  </p>
                </div>
              )}

              {/* Orders */}
              <div className="mt-8">
                <h3 className="eyebrow text-ink-faint">Order history</h3>
                {orders.length === 0 ? (
                  <div className="mt-4 flex flex-col items-center gap-3 rounded-[26px] surface px-6 py-10 text-center hairline">
                    <span className="grid size-14 place-items-center rounded-full bg-ink/[0.045]">
                      <Package className="size-6 text-ink-faint" strokeWidth={1.6} aria-hidden="true" />
                    </span>
                    <p className="text-[14.5px] font-semibold">No orders yet</p>
                    <p className="text-[12.5px] leading-relaxed text-ink-faint">
                      Orders you place while signed in appear here with tracking.
                    </p>
                  </div>
                ) : (
                  <ul className="mt-4 space-y-3">
                    {orders.map((o, i) => (
                      <motion.li
                        key={o.id}
                        initial={{ opacity: 0, y: 16 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.05 + i * 0.06, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                        className="rounded-[24px] surface p-4 hairline"
                      >
                        <div className="flex items-center justify-between gap-3">
                          <p className="font-mono text-[13px] font-bold tracking-wider">{o.id}</p>
                          <span className="flex items-center gap-1.5 rounded-full bg-emerald-500/12 px-2.5 py-1 text-[10.5px] font-bold uppercase tracking-[0.12em] text-emerald-600">
                            <Truck className="size-3" aria-hidden="true" />
                            Arriving {o.eta.split(",")[0]}
                          </span>
                        </div>
                        <p className="mt-1 text-[12px] text-ink-faint">
                          Placed {new Date(o.date).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })} · arrives {o.eta}
                        </p>
                        <div className="mt-3 flex items-center justify-between gap-3">
                          <div className="flex items-center gap-2">
                            {o.items.slice(0, 3).map((item, j) => (
                              <span
                                key={j}
                                title={item.title}
                                className="grid size-10 place-items-center rounded-xl text-[9px] font-bold text-black/40"
                                style={{ background: `linear-gradient(135deg, ${item.tintA}, ${item.tintB})` }}
                              >
                                ×{item.qty}
                              </span>
                            ))}
                            {o.items.length > 3 && (
                              <span className="text-[11px] font-semibold text-ink-faint">+{o.items.length - 3} more</span>
                            )}
                          </div>
                          <p className="text-[15px] font-bold">{fmt(o.total)}</p>
                        </div>
                        <p className="mt-2 truncate text-[12px] text-ink-soft">
                          {o.items.map((it) => `${it.qty}× ${it.title}`).join("  ·  ")}
                        </p>
                      </motion.li>
                    ))}
                  </ul>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="border-t border-line px-6 py-4">
              <button
                onClick={() => {
                  signOut();
                  closeAccount();
                }}
                className="flex w-full items-center justify-center gap-2 rounded-full py-3.5 text-[14px] font-bold text-ink hairline transition-colors hover:bg-ink hover:text-bone"
              >
                <LogOut className="size-4" aria-hidden="true" />
                Sign out
              </button>
            </div>
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
