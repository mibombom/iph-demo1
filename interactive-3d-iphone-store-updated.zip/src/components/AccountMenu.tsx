import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronRight, LogOut, Moon, Package, Settings, ShieldCheck, Sun, UserRound } from "lucide-react";
import { useAuth } from "../context/Auth";
import { useAdmin } from "../context/Admin";
import { useSettings } from "../context/Settings";
import { cn } from "../utils/cn";

function initials(name: string) {
  return name
    .split(" ")
    .map((p) => p[0])
    .filter(Boolean)
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

export default function AccountMenu() {
  const { user, orders, openAuth, openAccount, signOut } = useAuth();
  const { openSettings, resolvedTheme, setTheme } = useSettings();
  const { openPortal } = useAdmin();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: PointerEvent) => {
      if (!ref.current?.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("pointerdown", onDown);
    window.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("pointerdown", onDown);
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const ThemeRow = (
    <button
      role="menuitem"
      onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
      className="flex w-full items-center gap-3 rounded-2xl px-3.5 py-3 text-left text-[13.5px] font-semibold text-ink transition-colors hover:bg-ink/5"
    >
      <span className="grid size-8 place-items-center rounded-xl bg-ink/[0.05]">
        {resolvedTheme === "dark" ? <Moon className="size-4" aria-hidden="true" /> : <Sun className="size-4" aria-hidden="true" />}
      </span>
      <span className="flex-1">{resolvedTheme === "dark" ? "Dark mode" : "Light mode"}</span>
      <span
        aria-hidden="true"
        className={cn(
          "relative h-5 w-9 rounded-full transition-colors duration-300",
          resolvedTheme === "dark" ? "bg-accent" : "bg-ink/15",
        )}
      >
        <span
          className="absolute top-0.5 size-4 rounded-full bg-white shadow-sm transition-all duration-300"
          style={{ left: resolvedTheme === "dark" ? 18 : 2 }}
        />
      </span>
    </button>
  );

  const SettingsRow = (
    <button
      role="menuitem"
      onClick={() => {
        setOpen(false);
        openSettings();
      }}
      className="flex w-full items-center gap-3 rounded-2xl px-3.5 py-3 text-left text-[13.5px] font-semibold text-ink transition-colors hover:bg-ink/5"
    >
      <span className="grid size-8 place-items-center rounded-xl bg-ink/[0.05]">
        <Settings className="size-4" aria-hidden="true" />
      </span>
      <span className="flex-1">Settings</span>
      <ChevronRight className="size-3.5 text-ink-faint" aria-hidden="true" />
    </button>
  );

  const AdminRow = (
    <button
      role="menuitem"
      onClick={() => {
        setOpen(false);
        openPortal();
      }}
      className="flex w-full items-center gap-3 rounded-2xl px-3.5 py-3 text-left text-[13.5px] font-semibold text-ink transition-colors hover:bg-ink/5"
    >
      <span className="grid size-8 place-items-center rounded-xl bg-ink/[0.05]">
        <ShieldCheck className="size-4" aria-hidden="true" />
      </span>
      <span className="flex-1">Admin portal</span>
      <ChevronRight className="size-3.5 text-ink-faint" aria-hidden="true" />
    </button>
  );

  if (!user) {
    return (
      <div ref={ref} className="relative">
        <button
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-haspopup="menu"
          aria-label="Account and settings menu"
          className="grid size-10 place-items-center rounded-full transition-colors hover:bg-ink/5"
        >
          <UserRound className="size-[19px]" strokeWidth={1.8} />
        </button>

        <AnimatePresence>
          {open && (
            <motion.div
              role="menu"
              initial={{ opacity: 0, y: 8, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 6, scale: 0.97 }}
              transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
              className="absolute right-0 top-12 z-50 w-64 overflow-hidden rounded-3xl glass-nav hairline shadow-[0_28px_60px_-18px_rgba(0,0,0,0.4)]"
            >
              <div className="border-b border-line p-2">
                <button
                  role="menuitem"
                  onClick={() => {
                    setOpen(false);
                    openAuth("signin");
                  }}
                  className="w-full rounded-2xl bg-ink px-4 py-3 text-[13.5px] font-bold text-bone transition-colors hover:bg-accent hover:text-white"
                >
                  Sign in
                </button>
                <button
                  role="menuitem"
                  onClick={() => {
                    setOpen(false);
                    openAuth("signup");
                  }}
                  className="mt-2 w-full rounded-2xl px-4 py-2.5 text-[13px] font-semibold text-ink-soft transition-colors hover:text-accent"
                >
                  Create an account
                </button>
              </div>
              <div className="p-2">
                {ThemeRow}
                {SettingsRow}
                {AdminRow}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-haspopup="menu"
        aria-label={`Account menu for ${user.name}`}
        className="grid size-9 place-items-center rounded-full bg-accent text-[12.5px] font-bold text-white transition-transform duration-300 hover:scale-105"
      >
        {initials(user.name)}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            role="menu"
            initial={{ opacity: 0, y: 8, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 6, scale: 0.97 }}
            transition={{ duration: 0.28, ease: [0.22, 1, 0.36, 1] }}
            className="absolute right-0 top-12 z-50 w-64 overflow-hidden rounded-3xl glass-nav hairline shadow-[0_28px_60px_-18px_rgba(20,20,23,0.4)]"
          >
            <div className="border-b border-line px-5 py-4">
              <p className="truncate text-[14.5px] font-bold">{user.name}</p>
              <p className="truncate text-[12px] text-ink-faint">{user.email}</p>
            </div>
            <div className="p-2">
              <button
                role="menuitem"
                onClick={() => {
                  setOpen(false);
                  openAccount();
                }}
                className="flex w-full items-center gap-3 rounded-2xl px-3.5 py-3 text-left text-[13.5px] font-semibold text-ink transition-colors hover:bg-ink/5"
              >
                <span className="grid size-8 place-items-center rounded-xl bg-ink/[0.05]">
                  <Package className="size-4" aria-hidden="true" />
                </span>
                <span className="flex-1">Account &amp; orders</span>
                <span className="flex items-center gap-1 text-[11.5px] font-medium text-ink-faint">
                  {orders.length} <ChevronRight className="size-3.5" aria-hidden="true" />
                </span>
              </button>
              {SettingsRow}
              {AdminRow}
              {ThemeRow}
              <span className="my-1 block h-px bg-line" aria-hidden="true" />
              <button
                role="menuitem"
                onClick={() => {
                  setOpen(false);
                  signOut();
                }}
                className="flex w-full items-center gap-3 rounded-2xl px-3.5 py-3 text-left text-[13.5px] font-semibold text-ink transition-colors hover:bg-red-500/10 hover:text-red-500"
              >
                <span className="grid size-8 place-items-center rounded-xl bg-ink/[0.05]">
                  <LogOut className="size-4" aria-hidden="true" />
                </span>
                Sign out
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
