import { useEffect, useRef, useState, type FormEvent } from "react";
import { motion } from "framer-motion";
import { Eye, EyeOff, KeyRound, Loader2, LockKeyhole, ShieldCheck } from "lucide-react";
import { ADMIN_CREDENTIALS, ADMIN_FUNCTIONS } from "../data/admin";
import { ADMIN_FUNCTIONS_245 } from "../data/adminos";
import { useAdmin } from "../context/Admin";
import { cn } from "../utils/cn";

const easeOut = [0.22, 1, 0.36, 1] as const;

/**
 * The single entrance to the admin portal: sign in with the admin
 * credentials or the portal stays locked.
 */
export default function AdminLogin({ compact = false }: { compact?: boolean }) {
  const { signIn } = useAdmin();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const firstInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const t = window.setTimeout(() => firstInput.current?.focus(), 120);
    return () => window.clearTimeout(t);
  }, []);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    // Small delay so the gate feels like a real auth boundary
    window.setTimeout(() => {
      const err = signIn(username, password);
      setBusy(false);
      if (err) {
        setError(err);
        setPassword("");
      }
    }, 420);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 16, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.5, ease: easeOut }}
      className={cn("w-full", compact ? "max-w-sm" : "max-w-md")}
    >
      <div className="overflow-hidden rounded-[28px] glass-nav hairline shadow-[0_40px_90px_-30px_rgba(20,20,23,0.55)]">
        <div className="relative px-7 pt-8 pb-6 text-center">
          <div className="mx-auto grid size-14 place-items-center rounded-2xl bg-ink text-bone">
            <LockKeyhole className="size-6" strokeWidth={1.8} aria-hidden="true" />
          </div>
          <p className="eyebrow mt-4 text-ink-faint">Restricted area</p>
          <h2 className="mt-1.5 text-[26px] font-bold tracking-tight text-ink">AdminOS Portal</h2>
          <p className="mx-auto mt-2 max-w-[300px] text-[13px] leading-relaxed text-ink-soft">
            {ADMIN_FUNCTIONS_245.length + ADMIN_FUNCTIONS.length} management functions
            ({ADMIN_FUNCTIONS_245.length} enterprise + {ADMIN_FUNCTIONS.length} commerce) live behind this
            login — this gate is the only way in.
          </p>
        </div>

        <form onSubmit={submit} className="space-y-4 px-7 pb-4">
          <div>
            <label
              htmlFor="admin-username"
              className="mb-1.5 block text-[12px] font-semibold uppercase tracking-[0.1em] text-ink-faint"
            >
              Admin username
            </label>
            <div className="relative">
              <ShieldCheck
                className="pointer-events-none absolute left-3.5 top-1/2 size-[17px] -translate-y-1/2 text-ink-faint"
                aria-hidden="true"
              />
              <input
                id="admin-username"
                ref={firstInput}
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="admin"
                autoComplete="username"
                aria-invalid={!!error}
                className="w-full rounded-2xl border border-line bg-bone py-3 pl-10 pr-4 text-[14.5px] outline-none transition-shadow placeholder:text-ink-faint/60 focus:ring-2 focus:ring-ink"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="admin-password"
              className="mb-1.5 block text-[12px] font-semibold uppercase tracking-[0.1em] text-ink-faint"
            >
              Admin password
            </label>
            <div className="relative">
              <KeyRound
                className="pointer-events-none absolute left-3.5 top-1/2 size-[17px] -translate-y-1/2 text-ink-faint"
                aria-hidden="true"
              />
              <input
                id="admin-password"
                type={showPw ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                autoComplete="current-password"
                aria-invalid={!!error}
                className="w-full rounded-2xl border border-line bg-bone py-3 pl-10 pr-12 text-[14.5px] outline-none transition-shadow placeholder:text-ink-faint/60 focus:ring-2 focus:ring-ink"
              />
              <button
                type="button"
                onClick={() => setShowPw((v) => !v)}
                aria-label={showPw ? "Hide password" : "Show password"}
                className="absolute right-2 top-1/2 grid size-8 -translate-y-1/2 place-items-center rounded-full text-ink-faint transition-colors hover:text-ink"
              >
                {showPw ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
              </button>
            </div>
          </div>

          {error && (
            <p role="alert" className="rounded-2xl bg-red-500/10 px-4 py-2.5 text-[12.5px] font-medium text-red-500">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={busy}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-ink px-4 py-3.5 text-[14px] font-bold text-bone transition-colors hover:bg-accent hover:text-white disabled:opacity-60"
          >
            {busy ? (
              <>
                <Loader2 className="size-4 animate-spin" aria-hidden="true" />
                Verifying credentials…
              </>
            ) : (
              "Enter admin portal"
            )}
          </button>
        </form>

        <div className="px-7 pb-8">
          <div className="rounded-2xl border border-dashed border-line px-4 py-3">
            <p className="text-[11px] font-semibold uppercase tracking-[0.12em] text-ink-faint">
              Demo credentials
            </p>
            <p className="mt-1 font-mono text-[12.5px] text-ink">
              {ADMIN_CREDENTIALS.username} / {ADMIN_CREDENTIALS.password}
            </p>
            <p className="mt-1 text-[11px] text-ink-faint">
              ({ADMIN_CREDENTIALS.alias} works too · nothing else opens this portal)
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
