import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Activity,
  Check,
  LockKeyhole,
  LogOut,
  Play,
  RotateCcw,
  Search,
  ShieldCheck,
  X,
} from "lucide-react";
import {
  ADMIN_CATEGORIES,
  ADMIN_FUNCTIONS,
  CATEGORY_BY_ID,
  formatValue,
  type AdminFunction,
} from "../data/admin";
import { useAdmin } from "../context/Admin";
import { useScrollLock } from "../lib/scroll";
import { cn } from "../utils/cn";
import AdminLogin from "./AdminLogin";
import { Logo } from "./Navbar";

const spring = { type: "spring", stiffness: 380, damping: 34, mass: 0.85 } as const;
const easeOut = [0.22, 1, 0.36, 1] as const;

const TOTAL = ADMIN_FUNCTIONS.length;

/* ──────────────────────────────────────────────────────────── function card */

function FunctionCard({ fn }: { fn: AdminFunction }) {
  const { flags, values, run } = useAdmin();
  const [busy, setBusy] = useState(false);
  const [justRan, setJustRan] = useState(false);
  const category = CATEGORY_BY_ID.get(fn.category);

  const execute = () => {
    if (busy) return;
    setBusy(true);
    window.setTimeout(() => {
      run(fn);
      setBusy(false);
      setJustRan(true);
      window.setTimeout(() => setJustRan(false), 900);
    }, 220);
  };

  return (
    <article className="flex flex-col rounded-3xl border border-line bg-bone p-4 transition-shadow duration-300 hover:shadow-[0_18px_40px_-22px_rgba(20,20,23,0.35)]">
      <div className="flex items-start justify-between gap-2">
        <span className="eyebrow text-ink-faint">{category?.label ?? fn.category}</span>
        {fn.kind === "toggle" && (
          <span
            className={cn(
              "rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider",
              flags[fn.id] ? "bg-emerald-500/15 text-emerald-600" : "bg-ink/[0.06] text-ink-faint",
            )}
          >
            {flags[fn.id] ? "On" : "Off"}
          </span>
        )}
        {fn.kind === "value" && (
          <span className="rounded-full bg-ink/[0.06] px-2 py-0.5 text-[10px] font-bold text-ink-soft">
            {formatValue(fn, values[fn.id] ?? fn.value?.start ?? 0)}
          </span>
        )}
      </div>

      <h3 className="mt-2 text-[14.5px] font-bold leading-snug text-ink">{fn.label}</h3>
      <p className="mt-1 flex-1 text-[12px] leading-relaxed text-ink-faint">{fn.desc}</p>

      <div className="mt-3.5">
        {fn.kind === "action" && (
          <button
            onClick={execute}
            disabled={busy}
            className={cn(
              "flex w-full items-center justify-center gap-2 rounded-2xl px-3.5 py-2.5 text-[12.5px] font-bold transition-colors",
              justRan
                ? "bg-emerald-500/15 text-emerald-600"
                : "bg-ink text-bone hover:bg-accent hover:text-white",
            )}
          >
            {busy ? (
              <>
                <Activity className="size-3.5 animate-pulse" aria-hidden="true" /> Running…
              </>
            ) : justRan ? (
              <>
                <Check className="size-3.5" aria-hidden="true" /> Done
              </>
            ) : (
              <>
                <Play className="size-3.5" aria-hidden="true" /> Run
              </>
            )}
          </button>
        )}

        {fn.kind === "toggle" && (
          <button
            role="switch"
            aria-checked={!!flags[fn.id]}
            onClick={execute}
            className={cn(
              "flex w-full items-center justify-between rounded-2xl border px-3.5 py-2.5 text-[12.5px] font-bold transition-colors",
              flags[fn.id] ? "border-accent/40 bg-accent/10 text-accent" : "border-line text-ink-soft",
            )}
          >
            {flags[fn.id] ? "Enabled" : "Disabled"}
            <span
              aria-hidden="true"
              className={cn(
                "relative h-5 w-9 rounded-full transition-colors duration-300",
                flags[fn.id] ? "bg-accent" : "bg-ink/15",
              )}
            >
              <span
                className="absolute top-0.5 size-4 rounded-full bg-white shadow-sm transition-all duration-300"
                style={{ left: flags[fn.id] ? 18 : 2 }}
              />
            </span>
          </button>
        )}

        {fn.kind === "value" && (
          <div className="flex items-center gap-2">
            <button
              onClick={() => run(fn, -1)}
              aria-label={`Decrease ${fn.label}`}
              className="grid size-9 place-items-center rounded-2xl border border-line text-ink-soft transition-colors hover:border-ink hover:text-ink"
            >
              −
            </button>
            <span className="flex-1 rounded-2xl bg-ink/[0.05] py-2 text-center text-[13px] font-bold text-ink">
              {formatValue(fn, values[fn.id] ?? fn.value?.start ?? 0)}
            </span>
            <button
              onClick={execute}
              aria-label={`Increase ${fn.label}`}
              className="grid size-9 place-items-center rounded-2xl border border-line text-ink-soft transition-colors hover:border-ink hover:text-ink"
            >
              +
            </button>
          </div>
        )}
      </div>
    </article>
  );
}

/* ──────────────────────────────────────────────────────────────── toast */

interface Toast {
  id: string;
  text: string;
}

/* ──────────────────────────────────────────────────────────── portal shell */

export default function AdminPortal() {
  const { portalOpen, closePortal, session, signOut, log, flags, totalRuns, resetState } = useAdmin();
  const [category, setCategory] = useState<string>("all");
  const [query, setQuery] = useState("");
  const [toasts, setToasts] = useState<Toast[]>([]);

  useScrollLock(portalOpen);

  useEffect(() => {
    if (!portalOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && closePortal();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [portalOpen, closePortal]);

  // Log entries arriving while the portal is open surface as toasts
  useEffect(() => {
    if (!session) return;
    const latest = log[0];
    if (!latest) return;
    const id = `${latest.id}-toast`;
    setToasts((prev) => (prev.some((t) => t.id === id) ? prev : [...prev, { id, text: latest.detail }].slice(-3)));
    const t = window.setTimeout(() => setToasts((prev) => prev.filter((x) => x.id !== id)), 2800);
    return () => window.clearTimeout(t);
  }, [log, session]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return ADMIN_FUNCTIONS.filter((fn) => {
      if (category !== "all" && fn.category !== category) return false;
      if (!q) return true;
      return (
        fn.label.toLowerCase().includes(q) ||
        fn.desc.toLowerCase().includes(q) ||
        fn.id.toLowerCase().includes(q)
      );
    });
  }, [category, query]);

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: TOTAL };
    for (const fn of ADMIN_FUNCTIONS) map[fn.category] = (map[fn.category] ?? 0) + 1;
    return map;
  }, []);

  const enabledToggles = Object.values(flags).filter(Boolean).length;

  return (
    <AnimatePresence>
      {portalOpen && (
        <>
          <motion.button
            key="admin-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closePortal}
            aria-hidden="true"
            tabIndex={-1}
            className="fixed inset-0 z-[88] bg-ink/55 backdrop-blur-md"
          />
          <div
            key="admin-shell"
            data-lenis-prevent
            className="fixed inset-0 z-[92] overflow-y-auto overscroll-contain p-0 md:p-6"
          >
            <motion.div
              role="dialog"
              aria-modal="true"
              aria-label="AURA admin portal"
              initial={{ opacity: 0, y: 26, scale: 0.985 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 18, scale: 0.985 }}
              transition={{ duration: 0.45, ease: easeOut }}
              className="mx-auto flex min-h-full max-w-7xl flex-col overflow-hidden rounded-none border border-line bg-bone shadow-[0_50px_120px_-40px_rgba(20,20,23,0.6)] md:min-h-[86vh] md:rounded-[28px]"
            >
              {/* Header */}
              <header className="glass-nav sticky top-0 z-10 flex items-center justify-between gap-3 border-b border-line px-5 py-3.5 md:px-7">
                <div className="flex items-center gap-3">
                  <Logo />
                  <span className="hidden h-5 w-px bg-line sm:block" aria-hidden="true" />
                  <div className="hidden sm:block">
                    <p className="text-[14px] font-bold leading-none text-ink">Admin Portal</p>
                    <p className="mt-1 text-[11px] text-ink-faint">
                      {TOTAL} functions · {enabledToggles} toggles on · {totalRuns} runs
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {session && (
                    <span className="hidden items-center gap-1.5 rounded-full bg-emerald-500/12 px-3 py-1.5 text-[11.5px] font-semibold text-emerald-600 sm:inline-flex">
                      <ShieldCheck className="size-3.5" aria-hidden="true" />
                      {session.username}
                    </span>
                  )}
                  <button
                    onClick={() => {
                      signOut();
                    }}
                    className="flex items-center gap-1.5 rounded-full border border-line px-3.5 py-1.5 text-[12px] font-semibold text-ink-soft transition-colors hover:border-red-400 hover:text-red-500"
                  >
                    <LogOut className="size-3.5" aria-hidden="true" />
                    Sign out
                  </button>
                  <button
                    onClick={closePortal}
                    aria-label="Close admin portal"
                    className="grid size-9 place-items-center rounded-full transition-colors hover:bg-ink/5"
                  >
                    <X className="size-[18px]" strokeWidth={1.8} aria-hidden="true" />
                  </button>
                </div>
              </header>

              {/* GATE: nothing below renders without an authenticated session */}
              {!session ? (
                <div className="flex flex-1 items-center justify-center px-5 py-14">
                  <AdminLogin compact />
                </div>
              ) : (
                <div className="flex-1 px-5 py-6 md:px-7">
                  {/* Stats */}
                  <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
                    {[
                      { label: "Registered functions", value: String(TOTAL), hint: "across 10 categories" },
                      { label: "Toggles enabled", value: String(enabledToggles), hint: "of live feature flags" },
                      { label: "Actions executed", value: String(totalRuns), hint: "recorded this session" },
                      { label: "Activity log", value: String(log.length), hint: "recent admin events" },
                    ].map((s) => (
                      <div key={s.label} className="rounded-3xl border border-line bg-bone px-4 py-3.5">
                        <p className="eyebrow text-ink-faint">{s.label}</p>
                        <p className="mt-1 text-[24px] font-bold leading-none text-ink">{s.value}</p>
                        <p className="mt-1 text-[11px] text-ink-faint">{s.hint}</p>
                      </div>
                    ))}
                  </div>

                  <div className="mt-6 grid gap-6 lg:grid-cols-[230px_1fr]">
                    {/* Sidebar */}
                    <aside className="lg:sticky lg:top-24 lg:self-start">
                      <div className="relative">
                        <Search
                          className="pointer-events-none absolute left-3.5 top-1/2 size-[16px] -translate-y-1/2 text-ink-faint"
                          aria-hidden="true"
                        />
                        <input
                          value={query}
                          onChange={(e) => setQuery(e.target.value)}
                          placeholder="Search functions…"
                          aria-label="Search admin functions"
                          className="w-full rounded-2xl border border-line bg-bone py-2.5 pl-10 pr-3 text-[13px] outline-none transition-shadow placeholder:text-ink-faint/60 focus:ring-2 focus:ring-ink"
                        />
                      </div>

                      <nav aria-label="Function categories" className="mt-3 flex flex-wrap gap-1.5 lg:flex-col">
                        {[{ id: "all", label: "All functions", blurb: `Everything in the portal` }, ...ADMIN_CATEGORIES].map(
                          (c) => {
                            const Icon = CATEGORY_BY_ID.get(c.id)?.icon ?? ShieldCheck;
                            const active = category === c.id;
                            return (
                              <button
                                key={c.id}
                                onClick={() => setCategory(c.id)}
                                aria-current={active ? "page" : undefined}
                                className={cn(
                                  "flex items-center gap-2.5 rounded-2xl px-3.5 py-2.5 text-left text-[13px] font-semibold transition-colors",
                                  active ? "bg-ink text-bone" : "text-ink-soft hover:bg-ink/[0.05]",
                                )}
                              >
                                {c.id === "all" ? (
                                  <ShieldCheck className="size-4 shrink-0" aria-hidden="true" />
                                ) : (
                                  <Icon className="size-4 shrink-0" aria-hidden="true" />
                                )}
                                <span className="flex-1">{c.label}</span>
                                <span
                                  className={cn(
                                    "rounded-full px-1.5 py-0.5 text-[10px] font-bold",
                                    active ? "bg-bone/15 text-bone" : "bg-ink/[0.06] text-ink-faint",
                                  )}
                                >
                                  {counts[c.id] ?? 0}
                                </span>
                              </button>
                            );
                          },
                        )}
                      </nav>

                      <button
                        onClick={() => {
                          resetState();
                          setToasts([]);
                        }}
                        className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl border border-line px-3.5 py-2.5 text-[12px] font-semibold text-ink-faint transition-colors hover:border-ink hover:text-ink"
                      >
                        <RotateCcw className="size-3.5" aria-hidden="true" />
                        Reset demo state
                      </button>
                    </aside>

                    {/* Function grid */}
                    <section aria-label="Admin functions">
                      <div className="flex flex-wrap items-baseline justify-between gap-2">
                        <div>
                          <p className="eyebrow text-ink-faint">
                            {category === "all" ? "All categories" : CATEGORY_BY_ID.get(category)?.label}
                          </p>
                          <h2 className="mt-1 text-[22px] font-bold tracking-tight text-ink">
                            {filtered.length} function{filtered.length === 1 ? "" : "s"}
                          </h2>
                        </div>
                        <p className="text-[12px] text-ink-faint">
                          Every change is logged · toggles and values persist
                        </p>
                      </div>

                      {filtered.length === 0 ? (
                        <div className="mt-6 rounded-3xl border border-dashed border-line px-6 py-12 text-center">
                          <LockKeyhole className="mx-auto size-6 text-ink-faint" aria-hidden="true" />
                          <p className="mt-3 text-[14px] font-semibold text-ink">No functions match</p>
                          <p className="mt-1 text-[12.5px] text-ink-faint">
                            Try a different search term or category.
                          </p>
                        </div>
                      ) : (
                        <div className="mt-4 grid gap-3.5 sm:grid-cols-2 xl:grid-cols-3">
                          {filtered.map((fn) => (
                            <FunctionCard key={fn.id} fn={fn} />
                          ))}
                        </div>
                      )}

                      {/* Activity log */}
                      <div className="mt-8 rounded-3xl border border-line bg-bone">
                        <div className="flex items-center gap-2.5 border-b border-line px-5 py-3.5">
                          <Activity className="size-4 text-accent" aria-hidden="true" />
                          <h3 className="text-[14px] font-bold text-ink">Activity log</h3>
                          <span className="ml-auto text-[11px] text-ink-faint">
                            {log.length ? `${log.length} recent events` : "No events yet"}
                          </span>
                        </div>
                        {log.length === 0 ? (
                          <p className="px-5 py-6 text-[12.5px] text-ink-faint">
                            Run any function above and it will appear here with a timestamp.
                          </p>
                        ) : (
                          <ul className="max-h-72 overflow-y-auto">
                            <AnimatePresence initial={false}>
                              {log.slice(0, 14).map((entry) => (
                                <motion.li
                                  key={entry.id}
                                  layout
                                  initial={{ opacity: 0, x: -10 }}
                                  animate={{ opacity: 1, x: 0 }}
                                  transition={spring}
                                  className="flex items-start gap-3 border-b border-line px-5 py-2.5 last:border-b-0"
                                >
                                  <span className="mt-1 size-1.5 shrink-0 rounded-full bg-accent" aria-hidden="true" />
                                  <div className="min-w-0 flex-1">
                                    <p className="truncate text-[12.5px] font-semibold text-ink">{entry.detail}</p>
                                    <p className="text-[11px] text-ink-faint">
                                      {entry.label} · {CATEGORY_BY_ID.get(entry.category)?.label ?? entry.category}
                                    </p>
                                  </div>
                                  <time className="shrink-0 text-[10.5px] text-ink-faint">
                                    {new Date(entry.at).toLocaleTimeString([], {
                                      hour: "2-digit",
                                      minute: "2-digit",
                                    })}
                                  </time>
                                </motion.li>
                              ))}
                            </AnimatePresence>
                          </ul>
                        )}
                      </div>
                    </section>
                  </div>
                </div>
              )}
            </motion.div>
          </div>

          {/* Toasts */}
          <div className="pointer-events-none fixed right-4 top-20 z-[100] flex w-[290px] flex-col gap-2">
            <AnimatePresence>
              {toasts.map((t) => (
                <motion.div
                  key={t.id}
                  initial={{ opacity: 0, x: 40, scale: 0.95 }}
                  animate={{ opacity: 1, x: 0, scale: 1 }}
                  exit={{ opacity: 0, x: 40, scale: 0.95 }}
                  transition={spring}
                  className="rounded-2xl bg-ink px-4 py-3 text-[12.5px] font-semibold text-bone shadow-[0_18px_40px_-16px_rgba(20,20,23,0.55)]"
                >
                  {t.text}
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}
