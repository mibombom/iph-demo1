import { useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import { useAdmin } from "../context/Admin";
import { AdminOSProvider } from "../context/AdminOS";
import { useScrollLock } from "../lib/scroll";
import { cn } from "../utils/cn";
import AdminLogin from "./AdminLogin";
import AdminOSShell from "./adminos/Shell";

const easeOut = [0.22, 1, 0.36, 1] as const;

/**
 * AdminOS portal shell. The ONLY way into the workspace is the admin
 * login gate below — without a valid session nothing else renders.
 */
export default function AdminPortal() {
  const { portalOpen, closePortal, session } = useAdmin();

  useScrollLock(portalOpen);

  useEffect(() => {
    if (!portalOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && closePortal();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [portalOpen, closePortal]);

  return (
    <AnimatePresence>
      {portalOpen && (
        <>
          <motion.button
            key="admin-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closePortal}
            aria-hidden="true"
            tabIndex={-1}
            className="fixed inset-0 z-[88] bg-ink/55 backdrop-blur-md"
          />
          <div
            key="admin-shell"
            data-lenis-prevent
            className="fixed inset-0 z-[92] overflow-y-auto overscroll-contain p-0 md:p-6"
          >
            <motion.div
              role="dialog"
              aria-modal="true"
              aria-label="AdminOS — enterprise administration portal"
              initial={{ opacity: 0, y: 26, scale: 0.985 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 18, scale: 0.985 }}
              transition={{ duration: 0.45, ease: easeOut }}
              className={cn(
                "mx-auto flex min-h-full max-w-[1400px] flex-col overflow-hidden rounded-none border border-line bg-bone shadow-[0_50px_120px_-40px_rgba(20,20,23,0.6)] md:min-h-[86vh] md:rounded-[28px]",
                session && "p-0",
              )}
            >
              {!session ? (
                <>
                  <header className="flex items-center justify-end px-4 pt-4">
                    <button
                      onClick={closePortal}
                      aria-label="Close admin portal"
                      className="grid size-9 place-items-center rounded-full transition-colors hover:bg-ink/5"
                    >
                      <X className="size-[18px]" strokeWidth={1.8} aria-hidden="true" />
                    </button>
                  </header>
                  <div className="flex flex-1 items-center justify-center px-5 pb-14">
                    <AdminLogin compact />
                  </div>
                </>
              ) : (
                /* Authenticated: the AdminOS workspace — engine + all 245 functions */
                <AdminOSProvider>
                  <AdminOSShell />
                </AdminOSProvider>
              )}
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}
