import { useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useAdmin } from "../context/Admin";
import { AdminOSProvider } from "../context/AdminOS";
import { useScrollLock } from "../lib/scroll";
import AdminOSShell from "./adminos/Shell";

const easeOut = [0.22, 1, 0.36, 1] as const;

/**
 * AdminOS portal shell. There is no separate admin login panel — the
 * portal opens only after the admin signs in through the regular sign-in
 * form with the admin credentials, so without a valid session nothing
 * renders.
 */
export default function AdminPortal() {
  const { portalOpen, closePortal, session } = useAdmin();

  useScrollLock(portalOpen);

  // Defensive: the portal never stays open without an admin session.
  useEffect(() => {
    if (portalOpen && !session) closePortal();
  }, [portalOpen, session, closePortal]);

  useEffect(() => {
    if (!portalOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && closePortal();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [portalOpen, closePortal]);

  return (
    <AnimatePresence>
      {portalOpen && session && (
        <>
          <motion.button
            key="admin-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closePortal}
            aria-hidden="true"
            tabIndex={-1}
            className="fixed inset-0 z-[88] bg-ink/55 backdrop-blur-md"
          />
          <div
            key="admin-shell"
            data-lenis-prevent
            className="fixed inset-0 z-[92] overflow-y-auto overscroll-contain p-0 md:p-6"
          >
            <motion.div
              role="dialog"
              aria-modal="true"
              aria-label="AdminOS — enterprise administration portal"
              initial={{ opacity: 0, y: 26, scale: 0.985 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 18, scale: 0.985 }}
              transition={{ duration: 0.45, ease: easeOut }}
              className="mx-auto flex min-h-full max-w-[1400px] flex-col overflow-hidden rounded-none border border-line bg-bone p-0 shadow-[0_50px_120px_-40px_rgba(20,20,23,0.6)] md:min-h-[86vh] md:rounded-[28px]"
            >
              {/* Authenticated: the AdminOS workspace — engine + all 245 functions */}
              <AdminOSProvider>
                <AdminOSShell />
              </AdminOSProvider>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}
