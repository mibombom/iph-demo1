import { useEffect, useRef, useState, type FormEvent } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Eye, EyeOff, Loader2, LogIn, UserPlus, X, Zap } from "lucide-react";
import { useAuth, rememberedEmail } from "../context/Auth";
import { useAdmin } from "../context/Admin";
import { ADMIN_CREDENTIALS } from "../data/admin";
import { useScrollLock } from "../lib/scroll";
import { cn } from "../utils/cn";

const easeOut = [0.22, 1, 0.36, 1] as const;
const spring = { type: "spring", stiffness: 380, damping: 34, mass: 0.85 } as const;

function Field({
  id, label, type = "text", placeholder, value, onChange, autoComplete, error, trailing,
}: {
  id: string;
  label: string;
  type?: string;
  placeholder?: string;
  value: string;
  onChange: (v: string) => void;
  autoComplete?: string;
  error?: string;
  trailing?: React.ReactNode;
}) {
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-[12px] font-semibold uppercase tracking-[0.1em] text-ink-faint">
        {label}
      </label>
      <div className="relative">
        <input
          id={id}
          type={type}
          placeholder={placeholder}
          value={value}
          autoComplete={autoComplete}
          onChange={(e) => onChange(e.target.value)}
          aria-invalid={!!error}
          aria-describedby={error ? `${id}-error` : undefined}
          className={cn(
            "w-full rounded-2xl border bg-bone px-4 py-3 text-[14.5px] outline-none transition-shadow placeholder:text-ink-faint/60 focus:ring-2",
            trailing && "pr-12",
            error ? "border-red-400 focus:ring-red-400" : "border-line focus:ring-ink",
          )}
        />
        {trailing && <div className="absolute right-2 top-1/2 -translate-y-1/2">{trailing}</div>}
      </div>
      {error && (
        <p id={`${id}-error`} role="alert" className="mt-1.5 text-[12.5px] font-medium text-red-500">
          {error}
        </p>
      )}
    </div>
  );
}

function passwordScore(pw: string): number {
  let s = 0;
  if (pw.length >= 8) s++;
  if (pw.length >= 12) s++;
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) s++;
  if (/\d/.test(pw)) s++;
  if (/[^A-Za-z0-9]/.test(pw)) s++;
  return Math.min(4, s);
}

const STRENGTH = [
  { label: "Too short", color: "bg-red-400" },
  { label: "Weak", color: "bg-red-400" },
  { label: "Fair", color: "bg-amber-400" },
  { label: "Good", color: "bg-emerald-400" },
  { label: "Strong", color: "bg-emerald-500" },
];

export default function AuthModal() {
  const { authOpen, authView, openAuth, closeAuth, signIn, signUp } = useAuth();
  const { signIn: adminSignIn, openPortal } = useAdmin();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [agree, setAgree] = useState(false);
  const [errors, setErrors] = useState<{ form?: string; email?: string; password?: string; name?: string; agree?: string }>({});
  const [busy, setBusy] = useState(false);
  const firstInput = useRef<HTMLInputElement>(null);

  const view = authView;
  const score = passwordScore(password);

  useEffect(() => {
    if (authOpen) {
      setErrors({});
      // Remember who you are: prefill the last signed-in email on the sign-in form
      if (view === "signin") setEmail((e) => e || rememberedEmail());
      window.setTimeout(() => {
        const el = document.getElementById(view === "signup" ? "auth-name" : "auth-email");
        (firstInput.current ?? el)?.focus();
      }, 120);
    }
  }, [authOpen, view]);

  // Freeze the homepage while the modal is open
  useScrollLock(authOpen);

  useEffect(() => {
    if (!authOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && closeAuth();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [authOpen, closeAuth]);

  const clearForm = () => {
    setErrors({});
    setPassword("");
  };

  const submit = (e: FormEvent) => {
    e.preventDefault();
    setErrors({});
    const next: typeof errors = {};
    // The admin uses this same form: admin credentials route straight
    // into the AdminOS portal instead of creating a user session.
    const isAdminAttempt =
      view === "signin" &&
      [ADMIN_CREDENTIALS.username, ADMIN_CREDENTIALS.alias].includes(email.trim().toLowerCase());
    if (view === "signup") {
      if (name.trim().length < 2) next.name = "Enter your full name.";
      if (!agree) next.agree = "Please accept the terms to continue.";
    }
    if (!isAdminAttempt && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) next.email = "Enter a valid email.";
    if (view === "signup" && password.length < 8) next.password = "At least 8 characters.";
    if (view === "signin" && !password) next.password = "Enter your password.";
    if (Object.keys(next).length) {
      setErrors(next);
      return;
    }
    setBusy(true);
    window.setTimeout(() => {
      if (isAdminAttempt) {
        const err = adminSignIn(email, password);
        setBusy(false);
        if (err) {
          setErrors({ form: err });
          setPassword("");
          return;
        }
        clearForm();
        closeAuth();
        openPortal();
        return;
      }
      const msg = view === "signup" ? signUp(name, email, password) : signIn(email, password);
      setBusy(false);
      if (msg) setErrors({ form: msg });
      else {
        clearForm();
        closeAuth();
      }
    }, 650);
  };

  const demo = () => {
    setBusy(true);
    window.setTimeout(() => {
      signIn("ava@demo.aura", "demo1234");
      setBusy(false);
      clearForm();
      closeAuth();
    }, 500);
  };

  return (
    <AnimatePresence>
      {authOpen && (
        <>
          <motion.div
            key="auth-scrim"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={closeAuth}
            aria-hidden="true"
            className="fixed inset-0 z-[88] bg-ink/50 backdrop-blur-md"
          />
          <div data-lenis-prevent className="fixed inset-0 z-[92] grid place-items-center overflow-y-auto overscroll-contain p-4">
            <motion.div
              role="dialog"
              aria-modal="true"
              aria-labelledby="auth-title"
              initial={{ opacity: 0, y: 42, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 28, scale: 0.97 }}
              transition={spring}
              className="w-full max-w-md overflow-hidden rounded-[30px] bg-bone shadow-[0_50px_120px_-30px_rgba(20,20,23,0.6)]"
            >
              {/* Header */}
              <div className="relative panel-dark px-7 pb-8 pt-7">
                <button
                  onClick={closeAuth}
                  aria-label="Close"
                  className="absolute right-4 top-4 grid size-9 place-items-center rounded-full text-white/55 transition-colors hover:bg-white/10 hover:text-white"
                >
                  <X className="size-4.5" aria-hidden="true" />
                </button>
                <p className="eyebrow text-accent">AURA Account</p>
                <AnimatePresence mode="wait" initial={false}>
                  <motion.h2
                    key={view}
                    id="auth-title"
                    initial={{ opacity: 0, y: 14 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.35, ease: easeOut }}
                    className="display-tight mt-3 text-[30px] font-bold"
                  >
                    {view === "signup" ? (
                      <>Create your <span className="serif-accent font-normal text-white/85">account.</span></>
                    ) : (
                      <>Welcome <span className="serif-accent font-normal text-white/85">back.</span></>
                    )}
                  </motion.h2>
                </AnimatePresence>
                <p className="mt-2 text-[13.5px] text-white/50">
                  {view === "signup"
                    ? "Track orders, faster checkout, member pricing on trade-ins."
                    : "Sign in to pick up right where you left off."}
                </p>
              </div>

              {/* Tabs */}
              <div className="px-7 pt-5">
                <div role="tablist" aria-label="Account access" className="flex rounded-full bg-ink/[0.05] p-1">
                  {(
                    [
                      { id: "signin", label: "Sign in", icon: LogIn },
                      { id: "signup", label: "Create account", icon: UserPlus },
                    ] as const
                  ).map(({ id, label, icon: Icon }) => {
                    const active = view === id;
                    return (
                      <button
                        key={id}
                        role="tab"
                        aria-selected={active}
                        onClick={() => {
                          openAuth(id);
                          setErrors({});
                        }}
                        className={cn(
                          "relative flex flex-1 items-center justify-center gap-2 rounded-full py-2.5 text-[13px] font-semibold transition-colors duration-300",
                          active ? "text-bone" : "text-ink-soft hover:text-ink",
                        )}
                      >
                        {active && <motion.span layoutId="auth-tab" className="absolute inset-0 rounded-full bg-ink" transition={spring} />}
                        <span className="relative z-10 flex items-center gap-2">
                          <Icon className="size-3.5" aria-hidden="true" />
                          {label}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Form */}
              <form onSubmit={submit} noValidate className="space-y-4 px-7 py-6">
                <AnimatePresence mode="wait" initial={false}>
                  <motion.div
                    key={view}
                    initial={{ opacity: 0, x: view === "signup" ? 22 : -22 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: view === "signup" ? -16 : 16 }}
                    transition={{ duration: 0.35, ease: easeOut }}
                    className="space-y-4"
                  >
                    {view === "signup" && (
                      <Field id="auth-name" label="Full name" placeholder="Ava Chen" value={name} onChange={setName} autoComplete="name" error={errors.name} />
                    )}
                    <Field id="auth-email" label="Email" type="email" placeholder="you@example.com" value={email} onChange={setEmail} autoComplete="email" error={errors.email} />
                    <Field
                      id="auth-password"
                      label="Password"
                      type={showPw ? "text" : "password"}
                      placeholder={view === "signup" ? "8+ characters" : "Your password"}
                      value={password}
                      onChange={setPassword}
                      autoComplete={view === "signup" ? "new-password" : "current-password"}
                      error={errors.password}
                      trailing={
                        <button
                          type="button"
                          onClick={() => setShowPw((v) => !v)}
                          aria-label={showPw ? "Hide password" : "Show password"}
                          className="grid size-9 place-items-center rounded-full text-ink-faint transition-colors hover:bg-ink/5 hover:text-ink"
                        >
                          {showPw ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                        </button>
                      }
                    />

                    {view === "signup" && (
                      <>
                        <div aria-hidden="true">
                          <div className="flex gap-1.5">
                            {[0, 1, 2, 3].map((i) => (
                              <span
                                key={i}
                                className={cn(
                                  "h-1 flex-1 rounded-full transition-colors duration-300",
                                  password && i < score ? STRENGTH[score].color : "bg-ink/10",
                                )}
                              />
                            ))}
                          </div>
                          <p className="mt-1.5 text-[11.5px] text-ink-faint">
                            {password ? STRENGTH[score].label : "Use 8+ characters, mixed case, a number or symbol."}
                          </p>
                        </div>

                        <div>
                          <label className="flex cursor-pointer items-start gap-3 text-[12.5px] leading-relaxed text-ink-soft">
                            <span
                              className={cn(
                                "mt-0.5 grid size-5 shrink-0 place-items-center rounded-md border transition-colors",
                                agree ? "border-ink bg-ink text-bone" : "border-ink/30 bg-bone",
                              )}
                            >
                              {agree && <Check className="size-3" strokeWidth={3.5} />}
                            </span>
                            <input
                              type="checkbox"
                              className="sr-only"
                              checked={agree}
                              onChange={(e) => setAgree(e.target.checked)}
                              aria-describedby={errors.agree ? "auth-agree-error" : undefined}
                            />
                            I agree to the AURA Terms of Sale and acknowledge the Privacy Policy.
                          </label>
                          {errors.agree && (
                            <p id="auth-agree-error" role="alert" className="mt-1.5 text-[12.5px] font-medium text-red-500">
                              {errors.agree}
                            </p>
                          )}
                        </div>
                      </>
                    )}
                  </motion.div>
                </AnimatePresence>

                {errors.form && (
                  <motion.p initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} role="alert" className="rounded-2xl bg-red-500/10 px-4 py-3 text-[13px] font-medium text-red-500">
                    {errors.form}
                  </motion.p>
                )}

                <button
                  type="submit"
                  disabled={busy}
                  className="flex w-full items-center justify-center gap-2 rounded-full bg-ink py-4 text-[15px] font-bold text-bone transition-colors hover:bg-accent disabled:opacity-70"
                >
                  {busy ? (
                    <>
                      <Loader2 className="size-4 animate-spin" aria-hidden="true" />
                      One moment…
                    </>
                  ) : view === "signup" ? (
                    "Create account"
                  ) : (
                    "Sign in"
                  )}
                </button>

                <div className="flex items-center gap-3" aria-hidden="true">
                  <span className="h-px flex-1 bg-line" />
                  <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-ink-faint">or</span>
                  <span className="h-px flex-1 bg-line" />
                </div>

                <button
                  type="button"
                  onClick={demo}
                  disabled={busy}
                  className="flex w-full items-center justify-center gap-2 rounded-full py-3.5 text-[13.5px] font-bold text-ink hairline transition-colors hover:bg-ink hover:text-bone disabled:opacity-70"
                >
                  <Zap className="size-4 text-accent" aria-hidden="true" />
                  Continue with the demo account
                </button>

                <p className="text-center text-[11.5px] leading-relaxed text-ink-faint">
                  Concept experience — credentials are stored only in your browser.
                </p>
              </form>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}
