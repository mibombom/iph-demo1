import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { BadgeCheck, Check, Cpu, ShieldPlus, ShoppingBag, Store, Truck, Undo2 } from "lucide-react";
import { useConfiguredPrice, useStore } from "../context/Store";
import { useAuth } from "../context/Auth";
import { CATALOG, optionsFor, type CatalogProduct } from "../data/catalog";
import { CARE_PLUS_PRICE, findFinish, findModel, findStorage, fmt, MODELS } from "../data/products";
import { cn } from "../utils/cn";
import ProductTile from "./ProductTile";
import { Eyebrow, Reveal } from "./ui/Reveal";

const easeOut = [0.22, 1, 0.36, 1] as const;

function StepHeading({ n, title, hint }: { n: string; title: string; hint?: string }) {
  return (
    <div className="flex items-baseline gap-3">
      <span className="eyebrow text-accent">{n}</span>
      <h3 className="text-[19px] font-bold tracking-tight">{title}</h3>
      {hint && <span className="text-[13px] text-ink-faint">{hint}</span>}
    </div>
  );
}

/* ————————————————— Quick-configure panel (any device) ————————————————— */

function QuickPanel({
  product,
  colorIdx,
  onColor,
  tierIdx,
  onTier,
}: {
  product: CatalogProduct;
  colorIdx: number;
  onColor: (i: number) => void;
  tierIdx: number;
  onTier: (i: number) => void;
}) {
  const { configureProduct } = useStore();
  const options = optionsFor(product);

  return (
    <div className="space-y-10">
      <Reveal>
        <div className="flex items-start justify-between gap-4 rounded-[28px] panel-dark p-6 md:p-8">
          <div className="flex items-center gap-6">
            <div
              className="hidden h-32 w-24 shrink-0 place-items-center rounded-3xl sm:grid"
              style={{ background: `color-mix(in srgb, ${product.colors[colorIdx]} 22%, #141417)` }}
            >
              <ProductTile product={{ ...product, colors: [product.colors[colorIdx], ...product.colors] }} className="h-28 w-auto" />
            </div>
            <div>
              <p className="eyebrow text-accent">Quick configure</p>
              <h3 className="display-tight mt-2 text-[26px] font-bold md:text-[32px]">{product.name}</h3>
              <p className="mt-2 flex items-center gap-2 text-[13px] text-white/55">
                <Cpu className="size-3.5" aria-hidden="true" />
                {product.chip} · {product.info}
              </p>
              {product.condition !== "New" && (
                <p className="mt-3 flex max-w-sm items-start gap-2 text-[12.5px] leading-relaxed text-emerald-300/90">
                  <BadgeCheck className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
                  {product.condition === "Concept"
                    ? "Concept preview — final specs and pricing land at announcement."
                    : "Certified Renewed — lab-tested, new battery and shell, 1-year AURA warranty."}
                </p>
              )}
            </div>
          </div>
          <button
            onClick={() => configureProduct(null)}
            aria-label="Back to iPhone 17 configurator"
            className="group grid size-10 shrink-0 place-items-center rounded-full text-white/55 transition-colors hairline-bright btn-ghost-dark"
          >
            <Undo2 className="size-4.5" aria-hidden="true" />
          </button>
        </div>
      </Reveal>

      {/* Colour */}
      <Reveal>
        <fieldset>
          <legend className="contents">
            <StepHeading n="01" title="Choose your colour" hint={product.colorNames[colorIdx]} />
          </legend>
          <div className="mt-5 flex flex-wrap gap-4" role="radiogroup" aria-label="Colour">
            {product.colors.map((c, i) => {
              const active = i === colorIdx;
              return (
                <button
                  key={c + i}
                  role="radio"
                  aria-checked={active}
                  aria-label={product.colorNames[i]}
                  onClick={() => onColor(i)}
                  className={cn(
                    "size-12 rounded-full transition-all duration-300",
                    active
                      ? "scale-110 shadow-[0_10px_24px_-8px_rgba(20,20,23,0.5)] ring-2 ring-ink ring-offset-4 ring-offset-bone-deep"
                      : "ring-1 ring-ink/20 hover:scale-105 hover:ring-ink/50",
                  )}
                  style={{ background: c }}
                />
              );
            })}
          </div>
        </fieldset>
      </Reveal>

      {/* Storage / size */}
      {options && (
        <Reveal>
          <fieldset>
            <legend className="contents">
              <StepHeading n="02" title={options.heading === "Case size" ? "Choose your case size" : "Choose your storage"} />
            </legend>
            <div className="mt-5 grid gap-2.5 sm:grid-cols-2" role="radiogroup" aria-label={options.heading}>
              {options.tiers.map((t, i) => {
                const active = i === tierIdx;
                return (
                  <button
                    key={t.label}
                    role="radio"
                    aria-checked={active}
                    onClick={() => onTier(i)}
                    className={cn(
                      "flex items-center justify-between rounded-2xl px-5 py-4 text-left transition-all duration-300",
                      active ? "bg-ink text-bone shadow-[0_16px_36px_-16px_rgba(20,20,23,0.55)]" : "bg-bone hairline hover-surface",
                    )}
                  >
                    <span className="text-[15px] font-bold">{t.label}</span>
                    <span className={cn("text-[12.5px]", active ? "text-bone/60" : "text-ink-faint")}>
                      {t.delta === 0 ? "Included" : `+ ${fmt(t.delta)}`}
                    </span>
                  </button>
                );
              })}
            </div>
          </fieldset>
        </Reveal>
      )}

      <Reveal>
        <button
          onClick={() => configureProduct(null)}
          className="group inline-flex items-center gap-2 text-[13.5px] font-semibold text-ink-soft transition-colors hover:text-accent"
        >
          <Undo2 className="size-4 transition-transform group-hover:-translate-x-0.5" aria-hidden="true" />
          Back to the iPhone studio configurator
        </button>
      </Reveal>
    </div>
  );
}

/* ————————————————— Flagship studio steps ————————————————— */

function FlagshipPanel() {
  const { state, setModel, setFinish, setStorage, toggleCare } = useStore();
  const model = findModel(state.modelId);
  const finish = findFinish(state.modelId, state.finishId);
  const storage = findStorage(state.modelId, state.storageId);

  return (
    <div className="space-y-14">
      {/* Model */}
      <Reveal>
        <fieldset>
          <legend className="contents">
            <StepHeading n="01" title="Choose your model" />
          </legend>
          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            {MODELS.map((m) => {
              const active = m.id === state.modelId;
              return (
                <button
                  key={m.id}
                  onClick={() => setModel(m.id)}
                  aria-pressed={active}
                  className={cn(
                    "group relative rounded-3xl bg-bone p-5 text-left transition-all duration-300",
                    active ? "hairline shadow-[0_18px_44px_-20px_rgba(20,20,23,0.35)] ring-2 ring-ink" : "hairline hover-surface",
                  )}
                >
                  <span className="flex items-center justify-between">
                    <span className="text-[16px] font-bold">{m.name}</span>
                    <span
                      className={cn(
                        "grid size-5 place-items-center rounded-full border transition-colors",
                        active ? "border-ink bg-ink text-bone" : "border-ink/25 text-transparent",
                      )}
                      aria-hidden="true"
                    >
                      <Check className="size-3" strokeWidth={3} />
                    </span>
                  </span>
                  <span className="mt-1 block text-[12.5px] text-ink-faint">
                    {m.chipShort} · {m.displayShort}
                  </span>
                  <span className="mt-3 block text-[14px] font-semibold">From {fmt(m.base)}</span>
                </button>
              );
            })}
          </div>
        </fieldset>
      </Reveal>

      {/* Finish */}
      <Reveal>
        <fieldset>
          <legend className="contents">
            <StepHeading n="02" title="Choose your finish" hint={finish.name} />
          </legend>
          <div className="mt-5 flex flex-wrap gap-4" role="radiogroup" aria-label="Finish">
            {model.finishes.map((f) => {
              const active = f.id === finish.id;
              return (
                <button
                  key={f.id}
                  role="radio"
                  aria-checked={active}
                  aria-label={f.name}
                  onClick={() => setFinish(f.id)}
                  className={cn(
                    "size-12 rounded-full transition-all duration-300",
                    active
                      ? "scale-110 shadow-[0_10px_24px_-8px_rgba(20,20,23,0.5)] ring-2 ring-ink ring-offset-4 ring-offset-bone-deep"
                      : "ring-1 ring-ink/20 hover:scale-105 hover:ring-ink/50",
                  )}
                  style={{ background: f.swatch }}
                />
              );
            })}
          </div>
        </fieldset>
      </Reveal>

      {/* Storage */}
      <Reveal>
        <fieldset>
          <legend className="contents">
            <StepHeading n="03" title="Choose your storage" />
          </legend>
          <div className="mt-5 grid gap-2.5 sm:grid-cols-2" role="radiogroup" aria-label="Storage">
            {model.storage.map((s) => {
              const active = s.id === storage.id;
              return (
                <button
                  key={s.id}
                  role="radio"
                  aria-checked={active}
                  onClick={() => setStorage(s.id)}
                  className={cn(
                    "flex items-center justify-between rounded-2xl px-5 py-4 text-left transition-all duration-300",
                    active ? "bg-ink text-bone shadow-[0_16px_36px_-16px_rgba(20,20,23,0.55)]" : "bg-bone hairline hover-surface",
                  )}
                >
                  <span className="text-[15px] font-bold">{s.label}</span>
                  <span className={cn("text-[12.5px]", active ? "text-bone/60" : "text-ink-faint")}>
                    {s.delta === 0 ? "Included" : `+ ${fmt(s.delta)}`}
                  </span>
                </button>
              );
            })}
          </div>
        </fieldset>
      </Reveal>

      {/* Care+ */}
      <Reveal>
        <button
          onClick={toggleCare}
          aria-pressed={state.carePlus}
          className={cn(
            "flex w-full items-center gap-4 rounded-3xl p-5 text-left transition-all duration-300",
            state.carePlus ? "bg-ink text-bone" : "bg-bone hairline hover-surface",
          )}
        >
          <span
            className={cn(
              "grid size-10 shrink-0 place-items-center rounded-2xl",
              state.carePlus ? "bg-accent text-bone" : "bg-ink/5 text-ink",
            )}
          >
            <ShieldPlus className="size-5" strokeWidth={1.8} aria-hidden="true" />
          </span>
          <span className="flex-1">
            <span className="flex items-center gap-2 text-[15px] font-bold">
              AURA Care+ <span className={cn("text-[12px] font-medium", state.carePlus ? "text-bone/55" : "text-ink-faint")}>+ {fmt(CARE_PLUS_PRICE)}</span>
            </span>
            <span className={cn("mt-0.5 block text-[12.5px] leading-relaxed", state.carePlus ? "text-bone/55" : "text-ink-faint")}>
              Two years of accidental-damage cover, priority support, and a battery swap when you need it.
            </span>
          </span>
          <span
            className={cn(
              "grid size-6 shrink-0 place-items-center rounded-full border transition-colors",
              state.carePlus ? "border-accent bg-accent text-bone" : "border-ink/25 text-transparent",
            )}
            aria-hidden="true"
          >
            <Check className="size-3.5" strokeWidth={3} />
          </span>
        </button>
      </Reveal>
    </div>
  );
}

/* ————————————————— Section ————————————————— */

export default function Buy() {
  const { state, configureProduct, addToBag, addCustomItem } = useStore();
  const { user, openAuth } = useAuth();
  const model = findModel(state.modelId);
  const finish = findFinish(state.modelId, state.finishId);
  const storage = findStorage(state.modelId, state.storageId);
  const flagshipPrice = useConfiguredPrice();

  const quick = state.productId ? CATALOG.find((p) => p.id === state.productId) ?? null : null;
  const [qColor, setQColor] = useState(0);
  const [qTier, setQTier] = useState(0);
  useEffect(() => {
    setQColor(0);
    setQTier(0);
  }, [state.productId]);

  const qOptions = quick ? optionsFor(quick) : null;
  const qTierData = qOptions?.tiers[Math.min(qTier, qOptions.tiers.length - 1)];
  const quickPrice = quick ? quick.price + (qTierData?.delta ?? 0) : 0;

  const price = quick ? quickPrice : flagshipPrice;
  const monthly = price / 24;

  const delivery = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() + 2);
    return d.toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
  }, []);

  const handleAdd = () => {
    // Buying anything requires an account — no guest purchases.
    if (!user) {
      openAuth("signup", "Create an account to buy — you need an account to purchase anything.");
      return;
    }
    if (!quick) {
      addToBag();
      return;
    }
    const colorName = quick.colorNames[qColor];
    addCustomItem({
      key: `${quick.id}|${colorName}|${qTierData?.label ?? "-"}`,
      title: quick.name,
      meta: `${colorName} · ${quick.chip}${qTierData ? ` · ${qTierData.label}` : ""}${quick.condition !== "New" ? ` · ${quick.condition}` : ""}`,
      unitPrice: quickPrice,
      tintA: quick.colors[qColor],
      tintB: quick.colors[Math.min(qColor + 1, quick.colors.length - 1)] ?? quick.colors[qColor],
    });
  };

  return (
    <section id="buy" className="scroll-mt-16 bg-bone-deep py-24 md:py-32" aria-labelledby="buy-title">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <Eyebrow>Configure yours</Eyebrow>
        </Reveal>
        <Reveal delay={0.08}>
          <h2 id="buy-title" className="display-tight mt-4 text-[11vw] font-bold sm:text-6xl md:text-7xl">
            Make it <span className="serif-accent text-ink-soft">yours.</span>
          </h2>
        </Reveal>

        <div className="mt-14 grid gap-10 lg:grid-cols-[1fr,400px] lg:gap-14">
          {/* ——— Left: steps, animated between modes ——— */}
          <div className="min-w-0">
            <AnimatePresence mode="wait" initial={false}>
              <motion.div
                key={quick ? `quick-${quick.id}` : "flagship"}
                initial={{ opacity: 0, y: 26, filter: "blur(4px)" }}
                animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                exit={{ opacity: 0, y: -18, filter: "blur(4px)" }}
                transition={{ duration: 0.5, ease: easeOut }}
              >
                {quick ? (
                  <QuickPanel product={quick} colorIdx={qColor} onColor={setQColor} tierIdx={qTier} onTier={setQTier} />
                ) : (
                  <FlagshipPanel />
                )}
              </motion.div>
            </AnimatePresence>
          </div>

          {/* ——— Right: summary ——— */}
          <Reveal delay={0.1}>
            <aside
              className="sticky top-24 rounded-[28px] panel-dark p-7 shadow-[0_36px_80px_-32px_rgba(20,20,23,0.6)]"
              aria-label="Order summary"
            >
              <AnimatePresence mode="wait" initial={false}>
                <motion.div
                  key={quick ? `q-${quick.id}-${qColor}-${qTier}` : "s-flagship"}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.3, ease: easeOut }}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="eyebrow text-white/40">Your configuration</p>
                      <h3 className="mt-2 text-[24px] font-bold tracking-tight">
                        {quick ? quick.name : model.name}
                      </h3>
                    </div>
                    <span
                      className="mt-1 size-9 shrink-0 rounded-full ring-1 ring-white/20"
                      style={{ background: quick ? quick.colors[qColor] : finish.swatch }}
                      title={quick ? quick.colorNames[qColor] : finish.name}
                      aria-hidden="true"
                    />
                  </div>

                  <dl className="mt-5 space-y-2 border-t border-white/10 pt-5 text-[13.5px]">
                    {quick ? (
                      <>
                        <div className="flex justify-between">
                          <dt className="text-white/50">Colour</dt>
                          <dd>{quick.colorNames[qColor]}</dd>
                        </div>
                        {qTierData && (
                          <div className="flex justify-between">
                            <dt className="text-white/50">{qOptions!.heading}</dt>
                            <dd>{qTierData.label}</dd>
                          </div>
                        )}
                        <div className="flex justify-between">
                          <dt className="text-white/50">Condition</dt>
                          <dd>{quick.condition}</dd>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="flex justify-between">
                          <dt className="text-white/50">Finish</dt>
                          <dd>{finish.name}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-white/50">Storage</dt>
                          <dd>{storage.label}</dd>
                        </div>
                        <div className="flex justify-between">
                          <dt className="text-white/50">AURA Care+</dt>
                          <dd>{state.carePlus ? fmt(CARE_PLUS_PRICE) : "—"}</dd>
                        </div>
                      </>
                    )}
                    <div className="flex justify-between">
                      <dt className="text-white/50">Shipping</dt>
                      <dd className="text-emerald-300">Free</dd>
                    </div>
                  </dl>

                  <div className="mt-5 border-t border-white/10 pt-5">
                    <p className="flex items-baseline justify-between">
                      <span className="text-[13px] text-white/50">Total</span>
                      <AnimatePresence mode="popLayout" initial={false}>
                        <motion.span
                          key={price}
                          initial={{ y: 12, opacity: 0 }}
                          animate={{ y: 0, opacity: 1 }}
                          exit={{ y: -12, opacity: 0 }}
                          transition={{ duration: 0.35, ease: easeOut }}
                          className="display-tight text-[34px] font-bold"
                        >
                          {fmt(price)}
                        </motion.span>
                      </AnimatePresence>
                    </p>
                    <p className="mt-1 text-right text-[12.5px] text-white/45">
                      or {fmt(Math.round(monthly * 100) / 100)}/mo. for 24 mo.
                    </p>
                  </div>
                </motion.div>
              </AnimatePresence>

              <button
                onClick={handleAdd}
                className="group mt-6 flex w-full items-center justify-center gap-2.5 rounded-full btn-light py-4 text-[15px] font-bold transition-all duration-300 focus-visible:outline-bone"
              >
                <ShoppingBag className="size-[18px] transition-transform duration-300 group-hover:-translate-y-0.5" aria-hidden="true" />
                Add to Bag
              </button>

              {quick && (
                <button
                  onClick={() => configureProduct(null)}
                  className="mt-3 w-full rounded-full py-2.5 text-[12.5px] font-semibold text-white/50 transition-colors hover:text-white"
                >
                  Switch to iPhone 17 series configurator
                </button>
              )}

              <ul className="mt-6 space-y-2.5 text-[12.5px] text-white/50">
                <li className="flex items-center gap-2.5">
                  <Truck className="size-4 shrink-0 text-emerald-300" aria-hidden="true" />
                  Order now — arrives {delivery}
                </li>
                <li className="flex items-center gap-2.5">
                  <Store className="size-4 shrink-0" aria-hidden="true" />
                  Pick up today at AURA Fifth Avenue
                </li>
                <li className="flex items-center gap-2.5">
                  <Check className="size-4 shrink-0" aria-hidden="true" />
                  14-day free returns · trade-in credit applied at checkout
                </li>
              </ul>
            </aside>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
