import { useRef } from "react";
import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { Eyebrow, Reveal } from "./ui/Reveal";

const STATS = [
  { value: "0.02 mm", label: "Machining tolerance across the aluminum unibody" },
  { value: "100%", label: "Recycled aluminum in the enclosure and thermal core" },
  { value: "IP68", label: "Water resistant to 6 metres for up to 30 minutes" },
];

export default function Craft() {
  const ref = useRef<HTMLDivElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], reduce ? [0, 0] : [-40, 40]);
  const scale = useTransform(scrollYProgress, [0, 1], reduce ? [1, 1] : [1.08, 1]);

  return (
    <section className="relative overflow-hidden py-24 md:py-32" aria-labelledby="craft-title">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 md:px-8 lg:grid-cols-2 lg:gap-16">
        {/* Image */}
        <Reveal className="relative">
          <div ref={ref} className="relative aspect-[4/4.6] overflow-hidden rounded-[28px]">
            <motion.img
              src="/img/camera-macro.jpg"
              alt="Macro photograph of the iPhone 17 Pro camera system showing machined lens rings and sapphire glass"
              loading="lazy"
              style={{ y, scale }}
              className="absolute inset-0 size-full object-cover will-change-transform"
            />
            <div className="absolute inset-0 rounded-[28px] ring-1 ring-inset ring-black/10" aria-hidden="true" />
          </div>
          <p className="mt-3 text-right text-[12px] tracking-wide text-ink-faint">
            48MP Fusion optics · sapphire lens covers · laser-welded plateau
          </p>
        </Reveal>

        {/* Copy */}
        <div>
          <Reveal>
            <Eyebrow>Craftsmanship</Eyebrow>
          </Reveal>
          <Reveal delay={0.08}>
            <h2 id="craft-title" className="display-tight mt-4 text-[10.5vw] font-bold sm:text-5xl md:text-6xl">
              Obsessive,
              <br />
              <span className="serif-accent text-ink-soft">down to the last micron.</span>
            </h2>
          </Reveal>
          <Reveal delay={0.16}>
            <p className="mt-6 max-w-lg text-[16px] leading-relaxed text-ink-soft">
              Each enclosure begins as a single billet of aerospace-grade aluminum,
              milled over nineteen hours into a unibody that is lighter, stronger,
              and dramatically cooler under load. The camera plateau isn't
              attached — it's grown from the same block, so light has one
              continuous surface to travel across.
            </p>
          </Reveal>

          <dl className="mt-12 grid gap-8 sm:grid-cols-3">
            {STATS.map((s, i) => (
              <Reveal key={s.value} delay={0.1 + i * 0.08}>
                <dt className="display-tight text-3xl font-bold text-accent md:text-[2rem]">{s.value}</dt>
                <dd className="mt-2 text-[13px] leading-relaxed text-ink-soft">{s.label}</dd>
              </Reveal>
            ))}
          </dl>
        </div>
      </div>
    </section>
  );
}
