import { AtSign, Globe, MessageCircle } from "lucide-react";
import { scrollToId } from "../lib/scroll";

const COLS: { title: string; links: { label: string; id: string }[] }[] = [
  {
    title: "Shop",
    links: [
      { label: "Full catalog", id: "models" },
      { label: "Configure & buy", id: "buy" },
      { label: "Compare models", id: "compare" },
    ],
  },
  {
    title: "Explore",
    links: [
      { label: "Design Studio", id: "studio" },
      { label: "Tech specs", id: "specs" },
      { label: "Overview", id: "overview" },
    ],
  },
];

export default function Footer() {
  return (
    <footer className="panel-night" aria-labelledby="footer-heading">
      <h2 id="footer-heading" className="sr-only">
        Footer
      </h2>
      <div className="mx-auto max-w-7xl px-5 py-16 md:px-8 md:py-20">
        <div className="grid gap-12 md:grid-cols-[1.4fr,1fr,1fr,1fr]">
          <div>
            <span className="inline-flex items-center gap-2.5">
              <svg width="26" height="26" viewBox="0 0 32 32" aria-hidden="true">
                <rect width="32" height="32" rx="8.5" fill="#f5f3ee" />
                <circle cx="12" cy="16" r="5" fill="none" className="stroke-accent" strokeWidth="2.4" />
                <circle cx="20" cy="16" r="5" fill="#141417" />
              </svg>
              <span className="text-[15px] font-bold uppercase tracking-[0.18em]">Aura</span>
            </span>
            <p className="mt-4 max-w-xs text-[13.5px] leading-relaxed text-white/45">
              The refined destination for iPhone. Sculpted hardware, honest
              pricing, and a studio that lets you judge every micron yourself.
            </p>
            <div className="mt-6 flex gap-2">
              {[
                { icon: AtSign, label: "AURA on social" },
                { icon: MessageCircle, label: "AURA community chat" },
                { icon: Globe, label: "AURA worldwide" },
              ].map(({ icon: Icon, label }) => (
                <a
                  key={label}
                  href="#"
                  onClick={(e) => e.preventDefault()}
                  aria-label={label}
                  className="grid size-10 place-items-center rounded-full text-white/55 transition-colors hairline-bright btn-ghost-dark"
                >
                  <Icon className="size-4" strokeWidth={1.8} />
                </a>
              ))}
            </div>
          </div>

          {COLS.map((col) => (
            <nav key={col.title} aria-label={col.title}>
              <p className="eyebrow text-white/35">{col.title}</p>
              <ul className="mt-4 space-y-2.5">
                {col.links.map((l) => (
                  <li key={l.label}>
                    <button
                      onClick={() => scrollToId(l.id)}
                      className="text-[14px] text-white/65 transition-colors hover:text-white"
                    >
                      {l.label}
                    </button>
                  </li>
                ))}
              </ul>
            </nav>
          ))}

          <div>
            <p className="eyebrow text-white/35">Concierge</p>
            <ul className="mt-4 space-y-2.5 text-[14px] text-white/65">
              <li>1-800-AURA-NYC</li>
              <li>hello@aura.example</li>
              <li>767 Fifth Avenue, New York</li>
              <li>Open daily 9:00 – 21:00</li>
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col gap-3 border-t border-white/10 pt-6 text-[12px] leading-relaxed text-white/35 md:flex-row md:items-center md:justify-between">
          <p>© {new Date().getFullYear()} AURA Studio. A concept experience — not affiliated with Apple Inc. All pricing, specs, and availability are illustrative samples.</p>
          <p className="shrink-0">Designed in New York. Rendered live in your browser.</p>
        </div>
      </div>
    </footer>
  );
}
