import { useRef } from "react";
import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { ArrowRight, Check, MousePointer2, Sparkles, Truck } from "lucide-react";
import { useStore } from "../context/Store";
import { usePrefersCalm, useSettings } from "../context/Settings";
import { findFinish, fmt, HERO_MODEL } from "../data/products";
import { scrollToId } from "../lib/scroll";
import { Stage } from "./three/Stage";

function StaggeredLine({ text, delay = 0, className = "" }: { text: string; delay?: number; className?: string }) {
  const reduce = useReducedMotion();
  return (
    <span className={`block ${className}`} aria-label={text}>
      {text.split(" ").map((word, i) => (
        <span key={i} className="inline-block overflow-hidden pb-1 align-bottom" aria-hidden="true">
          <motion.span
            className="inline-block will-change-transform"
            initial={{ y: reduce ? 0 : "115%", rotate: reduce ? 0 : 4 }}
            animate={{ y: 0, rotate: 0 }}
            transition={{ duration: 1.05, delay: delay + i * 0.07, ease: [0.16, 1, 0.3, 1] }}
          >
            {word}
            {i < text.split(" ").length - 1 ? " " : ""}
          </motion.span>
        </span>
      ))}
    </span>
  );
}

export default function Hero() {
  const { state } = useStore();
  const finish = findFinish(HERO_MODEL.id, state.finishId);
  const ref = useRef<HTMLDivElement>(null);
  const calm = usePrefersCalm();
  const { autoRotate3D } = useSettings();
  const reduce = calm;
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const yText = useTransform(scrollYProgress, [0, 1], [0, reduce ? 0 : 90]);
  const opacityText = useTransform(scrollYProgress, [0, 0.75], [1, 0]);

  return (
    <section id="overview" ref={ref} className="relative overflow-hidden pt-16" aria-labelledby="hero-title">
      {/* Ambient backdrop */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(58% 44% at 72% 40%, rgba(200,82,43,0.14), transparent 70%), radial-gradient(40% 34% at 18% 78%, rgba(61,75,102,0.10), transparent 70%)",
        }}
      />

      <div className="relative mx-auto grid min-h-[92svh] max-w-7xl grid-cols-1 items-center gap-6 px-5 pb-10 pt-8 md:px-8 lg:grid-cols-12 lg:gap-2 lg:pb-0 lg:pt-0">
        {/* Copy */}
        <motion.div style={{ y: yText, opacity: opacityText }} className="relative z-10 lg:col-span-6 xl:col-span-5">
          <motion.p
            className="eyebrow mb-6 flex items-center gap-2 text-accent"
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.15 }}
          >
            <Sparkles className="size-3.5" aria-hidden="true" />
            {HERO_MODEL.name}
          </motion.p>

          <h1 id="hero-title" className="display-tight text-[17vw] font-bold sm:text-[13vw] lg:text-[5.6rem] xl:text-[6.4rem]">
            <StaggeredLine text="Sculpted to" delay={0.25} />
            <StaggeredLine text="transcend." delay={0.42} className="serif-accent text-accent" />
          </h1>

          <motion.p
            className="mt-7 max-w-md text-[17px] leading-relaxed text-ink-soft"
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.75 }}
          >
            A19 Pro inside a heat-forged aluminum unibody. The most advanced camera
            system ever on iPhone, and a battery that quietly outlasts your day —
            from <span className="font-semibold text-ink">{fmt(HERO_MODEL.base)}</span>.
          </motion.p>

          <motion.div
            className="mt-9 flex flex-wrap items-center gap-3.5"
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.9 }}
          >
            <button
              onClick={() => scrollToId("buy")}
              className="group inline-flex items-center gap-2.5 rounded-full bg-ink px-7 py-3.5 text-[15px] font-semibold text-bone transition-all duration-300 hover:bg-accent hover:shadow-[0_16px_40px_-12px_rgba(200,82,43,0.55)]"
            >
              Buy {HERO_MODEL.shortName}
              <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1" aria-hidden="true" />
            </button>
            <button
              onClick={() => scrollToId("studio")}
              className="inline-flex items-center gap-2.5 rounded-full px-7 py-3.5 text-[15px] font-semibold text-ink hairline transition-colors duration-300 hover:bg-ink hover:text-bone"
            >
              Enter the studio
            </button>
          </motion.div>

          <motion.ul
            className="mt-10 flex flex-wrap gap-x-6 gap-y-2 text-[13px] text-ink-faint"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1.1 }}
            aria-label="Shopping benefits"
          >
            {[
              { icon: Truck, label: "Free next-day delivery" },
              { icon: Check, label: "Trade-in credit available" },
              { icon: Check, label: `From ${fmt(HERO_MODEL.monthly)}/mo for 24 mo.` },
            ].map(({ icon: Icon, label }) => (
              <li key={label} className="flex items-center gap-1.5">
                <Icon className="size-3.5 text-accent" aria-hidden="true" />
                {label}
              </li>
            ))}
          </motion.ul>
        </motion.div>

        {/* 3D stage */}
        <motion.div
          className="relative h-[480px] w-full sm:h-[560px] lg:col-span-6 lg:h-[calc(92svh-4rem)] xl:col-span-7"
          initial={{ opacity: 0, scale: 0.94 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.4, delay: 0.5, ease: [0.16, 1, 0.3, 1] }}
        >
          <Stage
            finish={finish}
            float={!calm}
            autoRotate={autoRotate3D && !calm}
            enableZoom={false}
            shadowTone="light"
            className="absolute inset-0 cursor-grab active:cursor-grabbing"
            label="Interactive 3D render of iPhone 17 Pro Max — drag to rotate the device"
          />

          <motion.div
            className="pointer-events-none absolute bottom-5 left-1/2 flex -translate-x-1/2 items-center gap-2 rounded-full px-4 py-2 text-[12px] font-medium text-ink-soft glass-nav hairline"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.6, duration: 0.8 }}
          >
            <MousePointer2 className="size-3.5" aria-hidden="true" />
            Drag to rotate — finishes in the studio below
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
