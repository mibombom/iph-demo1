import { Asterisk } from "lucide-react";
import { MARQUEE_ITEMS } from "../data/products";

export default function Marquee() {
  const row = [...MARQUEE_ITEMS, ...MARQUEE_ITEMS];
  return (
    <div
      className="marquee-mask marquee-track overflow-hidden border-y border-line py-4"
      aria-hidden="true"
    >
      <div className="animate-marquee flex w-max items-center gap-10 pr-10">
        {row.map((item, i) => (
          <span key={i} className="flex items-center gap-10 whitespace-nowrap">
            <span className="text-[13px] font-semibold uppercase tracking-[0.22em] text-ink-soft">
              {item}
            </span>
            <Asterisk className="size-4 text-accent" />
          </span>
        ))}
      </div>
    </div>
  );
}
