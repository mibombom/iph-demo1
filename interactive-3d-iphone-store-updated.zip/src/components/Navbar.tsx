import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, ShoppingBag, X } from "lucide-react";
import { useStore } from "../context/Store";
import { scrollToId } from "../lib/scroll";
import { cn } from "../utils/cn";
import AccountMenu from "./AccountMenu";

const LINKS = [
  { id: "models", label: "Catalog" },
  { id: "catalogue", label: "Pictures" },
  { id: "studio", label: "Design Studio" },
  { id: "specs", label: "Specs" },
  { id: "compare", label: "Compare" },
  { id: "buy", label: "Buy" },
];

export function Logo({ inverted = false }: { inverted?: boolean }) {
  return (
    <span className="inline-flex items-center gap-2.5" aria-hidden={false}>
      <svg width="26" height="26" viewBox="0 0 32 32" aria-hidden="true" className="shrink-0">
        <rect width="32" height="32" rx="8.5" className={inverted ? "fill-bone" : "fill-ink"} />
        <circle cx="12" cy="16" r="5" fill="none" className="stroke-accent" strokeWidth="2.4" />
        <circle cx="20" cy="16" r="5" className={inverted ? "fill-ink" : "fill-bone"} />
      </svg>
      <span
        className={cn(
          "text-[15px] font-bold tracking-[0.18em] uppercase",
          inverted ? "text-ink" : "text-bone",
        )}
        style={{ color: inverted ? undefined : "#141417" }}
      >
        Aura
      </span>
    </span>
  );
}

export default function Navbar() {
  const { bagCount, openDrawer } = useStore();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const go = (id: string) => {
    setOpen(false);
    scrollToId(id);
  };

  return (
    <header className="fixed inset-x-0 top-0 z-50">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-[60] focus:rounded-full focus:bg-ink focus:px-4 focus:py-2 focus:text-sm focus:text-bone"
        onClick={(e) => {
          e.preventDefault();
          document.getElementById("main")?.scrollIntoView();
        }}
      >
        Skip to content
      </a>

      <div
        className={cn(
          "mx-auto flex h-16 max-w-7xl items-center justify-between px-5 transition-all duration-500 md:px-8",
          scrolled ? "glass-nav shadow-[0_1px_0_rgba(20,20,23,0.07)]" : "bg-transparent",
        )}
      >
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          aria-label="AURA — back to top"
          className="rounded-full"
        >
          <Logo />
        </button>

        <nav aria-label="Primary" className="hidden lg:block">
          <ul className="flex items-center gap-8">
            {LINKS.map((l) => (
              <li key={l.id}>
                <button
                  onClick={() => go(l.id)}
                  className={cn(
                    "group relative text-[13.5px] font-medium tracking-wide transition-colors",
                    l.id === "buy"
                      ? "rounded-full bg-ink px-4 py-1.5 text-bone hover:bg-accent"
                      : "text-ink-soft hover:text-ink",
                  )}
                >
                  {l.label}
                  {l.id !== "buy" && (
                    <span className="absolute -bottom-1 left-0 h-px w-0 bg-ink transition-all duration-300 group-hover:w-full" />
                  )}
                </button>
              </li>
            ))}
          </ul>
        </nav>

        <div className="flex items-center gap-2">
          <AccountMenu />
          <button
            onClick={openDrawer}
            aria-label={`Open bag, ${bagCount} item${bagCount === 1 ? "" : "s"}`}
            className="relative grid size-10 place-items-center rounded-full transition-colors hover:bg-ink/5"
          >
            <ShoppingBag className="size-[19px]" strokeWidth={1.8} />
            <AnimatePresence>
              {bagCount > 0 && (
                <motion.span
                  key="badge"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  exit={{ scale: 0 }}
                  className="absolute right-0.5 top-0.5 grid size-4 place-items-center rounded-full bg-accent text-[10px] font-bold text-bone"
                  aria-hidden="true"
                >
                  {bagCount}
                </motion.span>
              )}
            </AnimatePresence>
          </button>
          <button
            className="grid size-10 place-items-center rounded-full transition-colors hover:bg-ink/5 lg:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-label={open ? "Close menu" : "Open menu"}
          >
            {open ? <X className="size-5" strokeWidth={1.8} /> : <Menu className="size-5" strokeWidth={1.8} />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.nav
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            aria-label="Mobile"
            className="glass-nav mx-3 mt-1 overflow-hidden rounded-3xl shadow-[0_24px_60px_-20px_rgba(20,20,23,0.35)] lg:hidden"
          >
            <ul className="p-3">
              {LINKS.map((l, i) => (
                <motion.li
                  key={l.id}
                  initial={{ opacity: 0, x: -14 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.05 + i * 0.04 }}
                >
                  <button
                    onClick={() => go(l.id)}
                    className="flex w-full items-center justify-between rounded-2xl px-4 py-3.5 text-left text-[17px] font-semibold tracking-tight text-ink transition-colors hover:bg-ink/5"
                  >
                    {l.label}
                    <span className="eyebrow text-ink-faint">0{i + 1}</span>
                  </button>
                </motion.li>
              ))}
            </ul>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}
