import { useId } from "react";
import type { CatalogProduct } from "../data/catalog";

/* Lighten/darken a hex colour toward a target */
function shade(hex: string, to: string, amount: number) {
  const p = (h: string) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
  const [r1, g1, b1] = p(hex);
  const [r2, g2, b2] = p(to);
  const m = (a: number, b: number) => Math.round(a + (b - a) * amount);
  return `rgb(${m(r1, r2)},${m(g1, g2)},${m(b1, b2)})`;
}

function Lens({ x, y, r = 6, uid }: { x: number; y: number; r?: number; uid: string }) {
  return (
    <g>
      <circle cx={x} cy={y} r={r + 1.6} fill="#17171b" opacity="0.92" />
      <circle cx={x} cy={y} r={r} fill={`url(#${uid}-lens)`} />
      <circle cx={x - r * 0.28} cy={y - r * 0.28} r={r * 0.22} fill="#ffffff" opacity="0.55" />
      <circle cx={x + r * 0.3} cy={y + r * 0.34} r={r * 0.1} fill="#9fc4e8" opacity="0.5" />
    </g>
  );
}

function CameraModule({ camera, uid }: { camera: CatalogProduct["camera"]; uid: string }) {
  if (camera === "bar") {
    return (
      <g>
        <rect x="34" y="20" width="52" height="15" rx="7.5" fill={`url(#${uid}-mod)`} stroke="rgba(0,0,0,0.14)" strokeWidth="0.5" />
        <Lens x={49} y={27.5} r={5.4} uid={uid} />
        <circle cx={71} cy={27.5} r={2.4} fill="#f5e9c8" opacity="0.95" />
      </g>
    );
  }
  /* Square camera plateau — dual (vertical), diag, triple share it */
  const positions: Record<string, [number, number][]> = {
    dual: [
      [47, 31],
      [47, 47],
    ],
    diag: [
      [42, 33],
      [53, 45],
    ],
    triple: [
      [42, 33],
      [42, 47],
      [54, 40],
    ],
  };
  const pts = positions[camera ?? "dual"];
  return (
    <g>
      <rect x="30" y="20" width="36" height="36" rx="11" fill={`url(#${uid}-mod)`} stroke="rgba(0,0,0,0.14)" strokeWidth="0.5" />
      {pts.map(([x, y], i) => (
        <Lens key={i} x={x} y={y} r={camera === "triple" ? 5.8 : 5.6} uid={uid} />
      ))}
      {camera === "triple" ? (
        <>
          <circle cx={54} cy={29} r={2.2} fill="#f5e9c8" opacity="0.95" />
          <circle cx={54} cy={51} r={2.4} fill="#00000035" />
        </>
      ) : (
        <circle cx={camera === "diag" ? 42 : 56} cy={camera === "diag" ? 47 : 34} r={2.4} fill="#f5e9c8" opacity="0.9" />
      )}
    </g>
  );
}

/* ---------------------------------------------------------------
   Tiles per product kind — all drawn in a 120 × 240 viewBox
---------------------------------------------------------------- */

function PhoneTile({ p, uid }: { p: CatalogProduct; uid: string }) {
  const c = p.colors[0];
  return (
    <g>
      <defs>
        <linearGradient id={`${uid}-body`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={shade(c, "#ffffff", 0.34)} />
          <stop offset="52%" stopColor={c} />
          <stop offset="100%" stopColor={shade(c, "#000000", 0.22)} />
        </linearGradient>
        <linearGradient id={`${uid}-mod`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={shade(c, "#000000", 0.28)} />
          <stop offset="100%" stopColor={shade(c, "#000000", 0.48)} />
        </linearGradient>
        <radialGradient id={`${uid}-lens`} cx="0.35" cy="0.3" r="1">
          <stop offset="0%" stopColor="#3d4b66" />
          <stop offset="55%" stopColor="#141821" />
          <stop offset="100%" stopColor="#05070c" />
        </radialGradient>
        <linearGradient id={`${uid}-sheen`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#ffffff" stopOpacity="0.34" />
          <stop offset="45%" stopColor="#ffffff" stopOpacity="0" />
        </linearGradient>
      </defs>
      <ellipse cx="60" cy="228" rx="34" ry="4.5" fill="#141419" opacity="0.14" />
      <rect x="20" y="14" width="80" height="212" rx="20" fill={`url(#${uid}-body)`} stroke="rgba(0,0,0,0.12)" strokeWidth="0.75" />
      <rect x="24" y="18" width="34" height="204" rx="17" fill={`url(#${uid}-sheen)`} />
      <CameraModule camera={p.camera} uid={uid} />
    </g>
  );
}

function WatchTile({ p, uid }: { p: CatalogProduct; uid: string }) {
  const c = p.colors[0];
  return (
    <g>
      <defs>
        <linearGradient id={`${uid}-case`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={shade(c, "#ffffff", 0.3)} />
          <stop offset="100%" stopColor={shade(c, "#000000", 0.3)} />
        </linearGradient>
        <radialGradient id={`${uid}-face`} cx="0.5" cy="0.35" r="0.9">
          <stop offset="0%" stopColor="#2b3550" />
          <stop offset="100%" stopColor="#090b12" />
        </radialGradient>
      </defs>
      <ellipse cx="60" cy="226" rx="30" ry="4" fill="#141419" opacity="0.12" />
      {/* Strap */}
      <path d="M46 18 h28 v58 q-14 8 -28 0 z" fill={shade("#3a3a40", "#000000", 0)} stroke="rgba(0,0,0,0.1)" strokeWidth="0.5" />
      <path d="M46 164 q14 8 28 0 v58 h-28 z" fill="#3a3a40" stroke="rgba(0,0,0,0.1)" strokeWidth="0.5" />
      {[26, 36, 46, 56, 66].map((y) => (
        <rect key={y} x="52" y={y} width="16" height="1.6" rx="0.8" fill="#ffffff18" />
      ))}
      {/* Case */}
      <rect x="32" y="76" width="56" height="66" rx="17" fill={`url(#${uid}-case)`} stroke="rgba(0,0,0,0.16)" strokeWidth="0.75" />
      <rect x="37" y="81" width="46" height="56" rx="12" fill={`url(#${uid}-face)`} />
      <circle cx="55" cy="102" r="7.5" fill="#c8522b" opacity="0.9" />
      <circle cx="69" cy="102" r="7.5" fill="#4f7ddc" opacity="0.85" />
      <rect x="45" y="118" width="30" height="3.5" rx="1.75" fill="#ffffff33" />
      <rect x="45" y="126" width="20" height="3.5" rx="1.75" fill="#ffffff1f" />
      {/* Crown */}
      <rect x="88" y="94" width="4.5" height="10" rx="2.25" fill={shade(c, "#000000", 0.45)} />
    </g>
  );
}

function MacTile({ p, uid }: { p: CatalogProduct; uid: string }) {
  const c = p.colors[0];
  return (
    <g>
      <defs>
        <linearGradient id={`${uid}-lid`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={shade(c, "#ffffff", 0.26)} />
          <stop offset="100%" stopColor={shade(c, "#000000", 0.24)} />
        </linearGradient>
        <linearGradient id={`${uid}-screen`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#233251" />
          <stop offset="55%" stopColor="#0c0e16" />
          <stop offset="100%" stopColor="#46271c" />
        </linearGradient>
      </defs>
      <ellipse cx="60" cy="200" rx="46" ry="4.5" fill="#141419" opacity="0.12" />
      <rect x="22" y="66" width="76" height="112" rx="6" fill="#101014" stroke="rgba(0,0,0,0.2)" strokeWidth="0.5" />
      <rect x="25" y="69" width="70" height="103" rx="3.5" fill={`url(#${uid}-screen)`} />
      <circle cx="60" cy="60" r="2" fill={`url(#${uid}-lid)`} opacity="0" />
      <path d="M16 178 h88 l7 15 q1 3 -3 3 h-96 q-4 0 -3 -3 z" fill={`url(#${uid}-lid)`} stroke="rgba(0,0,0,0.14)" strokeWidth="0.5" />
      <rect x="51" y="186.5" width="18" height="3" rx="1.5" fill="rgba(0,0,0,0.22)" />
      {/* Lid accent so colour reads on closed-rim */}
      <rect x="22" y="172" width="76" height="6" rx="3" fill={`url(#${uid}-lid)`} opacity="0.7" />
    </g>
  );
}

function IpadTile({ p, uid }: { p: CatalogProduct; uid: string }) {
  const c = p.colors[0];
  return (
    <g>
      <defs>
        <linearGradient id={`${uid}-frame`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={shade(c, "#ffffff", 0.3)} />
          <stop offset="100%" stopColor={shade(c, "#000000", 0.24)} />
        </linearGradient>
        <linearGradient id={`${uid}-glass`} x1="0" y1="0" x2="0.8" y2="1">
          <stop offset="0%" stopColor="#263554" />
          <stop offset="60%" stopColor="#0b0d15" />
          <stop offset="100%" stopColor="#31262b" />
        </linearGradient>
      </defs>
      <ellipse cx="60" cy="218" rx="38" ry="4" fill="#141419" opacity="0.12" />
      <rect x="18" y="34" width="84" height="180" rx="12" fill={`url(#${uid}-frame)`} stroke="rgba(0,0,0,0.16)" strokeWidth="0.75" />
      <rect x="24" y="40" width="72" height="168" rx="7" fill={`url(#${uid}-glass)`} />
      <circle cx="60" cy="37.4" r="1.5" fill="#00000055" />
      <circle cx="32" cy="52" r="6" fill="#ffffff08" />
    </g>
  );
}

function PodsTile({ uid }: { uid: string }) {
  return (
    <g>
      <defs>
        <linearGradient id={`${uid}-case`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="100%" stopColor="#dcdce0" />
        </linearGradient>
      </defs>
      <ellipse cx="60" cy="190" rx="36" ry="4.5" fill="#141419" opacity="0.12" />
      {/* Buds rising from case */}
      <g>
        <circle cx="48" cy="86" r="11" fill={`url(#${uid}-case)`} stroke="rgba(0,0,0,0.1)" strokeWidth="0.5" />
        <rect x="43" y="92" width="9" height="26" rx="4.5" fill={`url(#${uid}-case)`} stroke="rgba(0,0,0,0.1)" strokeWidth="0.5" />
        <circle cx="72" cy="86" r="11" fill={`url(#${uid}-case)`} stroke="rgba(0,0,0,0.1)" strokeWidth="0.5" />
        <rect x="68" y="92" width="9" height="26" rx="4.5" fill={`url(#${uid}-case)`} stroke="rgba(0,0,0,0.1)" strokeWidth="0.5" />
        <circle cx="44" cy="82" r="2.4" fill="#00000014" />
        <circle cx="68" cy="82" r="2.4" fill="#00000014" />
      </g>
      {/* Case */}
      <rect x="28" y="118" width="64" height="62" rx="17" fill={`url(#${uid}-case)`} stroke="rgba(0,0,0,0.12)" strokeWidth="0.75" />
      <rect x="28" y="128" width="64" height="1.4" fill="#00000014" />
      <circle cx="60" cy="152" r="2.6" fill="#9fe6a8" />
    </g>
  );
}

function SpeakerTile({ p, uid }: { p: CatalogProduct; uid: string }) {
  const c = p.colors[0];
  return (
    <g>
      <defs>
        <linearGradient id={`${uid}-mesh`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={shade(c, "#ffffff", 0.28)} />
          <stop offset="100%" stopColor={shade(c, "#000000", 0.3)} />
        </linearGradient>
      </defs>
      <ellipse cx="60" cy="196" rx="34" ry="4.5" fill="#141419" opacity="0.12" />
      <rect x="26" y="86" width="68" height="104" rx="34" fill={`url(#${uid}-mesh)`} stroke="rgba(0,0,0,0.14)" strokeWidth="0.75" />
      {[98, 110, 122, 134, 146, 158, 170].map((y) => (
        <rect key={y} x="30" y={y} width="60" height="1.3" rx="0.65" fill="#00000012" />
      ))}
      <ellipse cx="60" cy="90" rx="26" ry="7" fill="#1a1a1f" opacity="0.9" />
      <ellipse cx="60" cy="90" rx="16" ry="4" fill="#c8522b" opacity="0.5" />
    </g>
  );
}

function PencilTile() {
  return (
    <g>
      <ellipse cx="60" cy="212" rx="10" ry="4" fill="#141419" opacity="0.12" />
      <rect x="54" y="30" width="12" height="176" rx="6" fill="#fbfbfc" stroke="rgba(0,0,0,0.14)" strokeWidth="0.75" />
      <path d="M54 200 v6 q6 8 12 0 v-6 z" fill="#ececf0" stroke="rgba(0,0,0,0.12)" strokeWidth="0.5" />
      <rect x="54" y="52" width="12" height="1.6" fill="#00000010" />
      <circle cx="60" cy="36" r="2.5" fill="#c8522b" opacity="0.7" />
    </g>
  );
}

function PuckTile() {
  return (
    <g>
      <path d="M60 118 q22 4 22 30" fill="none" stroke="#d8d8dc" strokeWidth="4" strokeLinecap="round" />
      <ellipse cx="60" cy="152" rx="34" ry="4.5" fill="#141419" opacity="0.1" />
      <circle cx="60" cy="112" r="30" fill="#fbfbfc" stroke="rgba(0,0,0,0.14)" strokeWidth="0.75" />
      <circle cx="60" cy="112" r="20" fill="none" stroke="rgba(0,0,0,0.08)" strokeWidth="6" />
      <circle cx="60" cy="112" r="7" fill="#ececef" />
    </g>
  );
}

function TagTile({ uid }: { uid: string }) {
  return (
    <g>
      <ellipse cx="60" cy="152" rx="34" ry="4.5" fill="#141419" opacity="0.1" />
      <circle cx="60" cy="112" r="30" fill="#fbfbfc" stroke="rgba(0,0,0,0.14)" strokeWidth="0.75" />
      <circle cx="60" cy="112" r="24" fill="none" stroke="rgba(0,0,0,0.06)" strokeWidth="1" />
      <circle cx="60" cy="112" r="9" fill={`url(#${uid}-lid)`} fillOpacity="0" stroke="rgba(0,0,0,0.1)" />
      <circle cx="60" cy="112" r="8" fill="#ececef" />
      <circle cx="57" cy="109" r="2" fill="#ffffff" opacity="0.8" />
    </g>
  );
}

function KeyboardTile({ p, uid }: { p: CatalogProduct; uid: string }) {
  const c = p.colors[0];
  return (
    <g>
      <defs>
        <linearGradient id={`${uid}-deck`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={shade(c, "#ffffff", 0.06)} />
          <stop offset="100%" stopColor={shade(c, "#000000", 0.18)} />
        </linearGradient>
      </defs>
      <ellipse cx="60" cy="184" rx="44" ry="4.5" fill="#141419" opacity="0.12" />
      {/* Upright folio */}
      <rect x="24" y="58" width="72" height="70" rx="7" fill={`url(#${uid}-deck)`} stroke="rgba(0,0,0,0.16)" strokeWidth="0.75" transform="skewY(-4)" />
      {/* Keyboard base */}
      <rect x="16" y="136" width="88" height="42" rx="6" fill={`url(#${uid}-deck)`} stroke="rgba(0,0,0,0.18)" strokeWidth="0.75" />
      {[0, 1, 2].map((row) =>
        [0, 1, 2, 3, 4, 5, 6, 7].map((col) => (
          <rect key={`${row}-${col}`} x={22 + col * 10} y={141 + row * 8} width="8" height="5.6" rx="1.4" fill="rgba(0,0,0,0.22)" />
        )),
      )}
      <rect x="30" y="166" width="60" height="6" rx="2" fill="rgba(0,0,0,0.14)" />
    </g>
  );
}

export default function ProductTile({ product, className }: { product: CatalogProduct; className?: string }) {
  const rawId = useId();
  const uid = rawId.replace(/[^a-zA-Z0-9]/g, "");
  const kind = product.tile;

  return (
    <svg viewBox="0 0 120 240" className={className} role="img" aria-label={`${product.name} illustration`}>
      {kind === "phone" && <PhoneTile p={product} uid={uid} />}
      {kind === "watch" && <WatchTile p={product} uid={uid} />}
      {kind === "mac" && <MacTile p={product} uid={uid} />}
      {kind === "ipad" && <IpadTile p={product} uid={uid} />}
      {kind === "pods" && <PodsTile uid={uid} />}
      {kind === "speaker" && <SpeakerTile p={product} uid={uid} />}
      {kind === "pencil" && <PencilTile />}
      {kind === "puck" && <PuckTile />}
      {kind === "tag" && <TagTile uid={uid} />}
      {kind === "keyboard" && <KeyboardTile p={product} uid={uid} />}
    </svg>
  );
}
