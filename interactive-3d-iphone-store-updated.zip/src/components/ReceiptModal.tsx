import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Download, ExternalLink, Printer, X } from "lucide-react";
import { useScrollLock } from "../lib/scroll";
import {
  openReceiptTab,
  receiptFileName,
  receiptHtml,
  saveReceipt,
  type ReceiptData,
  type SaveOutcome,
} from "../utils/receipt";

const spring = { type: "spring", stiffness: 380, damping: 34, mass: 0.85 } as const;

/**
 * In-app receipt preview with three ways to get the file out of the
 * browser: direct download, open-in-tab, and print / save-as-PDF.
 */
export default function ReceiptModal({
  receipt,
  onClose,
}: {
  receipt: ReceiptData | null;
  onClose: () => void;
}) {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const html = useMemo(() => (receipt ? receiptHtml(receipt) : ""), [receipt]);
  const [outcome, setOutcome] = useState<SaveOutcome | "tab" | null>(null);

  useScrollLock(!!receipt);

  useEffect(() => {
    if (!receipt) return;
    setOutcome(null);
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [receipt, onClose]);

  const note =
    outcome === "saver"
      ? "This preview may block automatic downloads — finish saving in the “Save receipt” tab that just opened."
      : outcome === "blocked"
        ? "This frame blocked both the download and the save tab. Use Print / Save as PDF, or open the store in a full browser tab."
        : outcome === "tab"
          ? "The receipt opened in a new browser tab — use your browser’s save or print controls there."
          : outcome === "downloaded"
            ? "Your download has started — check your browser’s downloads."
            : "Works in any browser — the receipt is a standalone HTML file.";

  return (
    <AnimatePresence>
      {receipt && (
        <>
          <motion.button
            key="receipt-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            aria-hidden="true"
            tabIndex={-1}
            className="fixed inset-0 z-[90] bg-ink/55 backdrop-blur-md"
          />
          <motion.div
            key="receipt-panel"
            role="dialog"
            aria-modal="true"
            aria-label={`Digital receipt ${receipt.id}`}
            initial={{ opacity: 0, y: 26, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.97 }}
            transition={spring}
            data-lenis-prevent
            className="fixed left-1/2 top-1/2 z-[94] flex max-h-[88vh] w-[94vw] max-w-2xl -translate-x-1/2 -translate-y-1/2 flex-col overflow-hidden rounded-[26px] border border-line bg-bone shadow-[0_50px_120px_-40px_rgba(20,20,23,0.6)]"
          >
            <header className="flex items-center justify-between gap-3 border-b border-line px-6 py-4">
              <div>
                <h2 className="text-[16px] font-bold tracking-tight text-ink">Digital receipt</h2>
                <p className="mt-0.5 font-mono text-[11.5px] tracking-wider text-ink-faint">
                  {receipt.id} · {receiptFileName(receipt)}
                </p>
              </div>
              <button
                onClick={onClose}
                aria-label="Close receipt preview"
                className="grid size-9 place-items-center rounded-full transition-colors hover:bg-ink/5"
              >
                <X className="size-[18px]" strokeWidth={1.8} aria-hidden="true" />
              </button>
            </header>

            {/* Live preview of the exact file the user downloads */}
            <div className="min-h-0 flex-1 bg-ink/[0.04] p-4">
              <iframe
                ref={iframeRef}
                title={`Receipt preview ${receipt.id}`}
                srcDoc={html}
                sandbox="allow-modals allow-same-origin"
                className="h-full min-h-[45vh] w-full rounded-2xl border border-line bg-white"
              />
            </div>

            <footer className="flex flex-wrap items-center gap-2 border-t border-line px-6 py-4">
              <button
                onClick={() => setOutcome(saveReceipt(receipt))}
                className="flex items-center gap-2 rounded-full bg-ink px-5 py-3 text-[13px] font-bold text-bone transition-colors hover:bg-accent"
              >
                <Download className="size-4" aria-hidden="true" />
                Download file
              </button>
              <button
                onClick={() => setOutcome(openReceiptTab(receipt) ? "tab" : "blocked")}
                className="flex items-center gap-2 rounded-full border border-line px-5 py-3 text-[13px] font-semibold text-ink transition-colors hover:border-ink hover:bg-ink hover:text-bone"
              >
                <ExternalLink className="size-4" aria-hidden="true" />
                Open in browser tab
              </button>
              <button
                onClick={() => iframeRef.current?.contentWindow?.print()}
                className="flex items-center gap-2 rounded-full border border-line px-5 py-3 text-[13px] font-semibold text-ink transition-colors hover:border-ink hover:bg-ink hover:text-bone"
              >
                <Printer className="size-4" aria-hidden="true" />
                Print / Save as PDF
              </button>
              <p
                role="status"
                className="ml-auto hidden max-w-[220px] text-[10.5px] leading-snug text-ink-faint sm:block"
              >
                {note}
              </p>
            </footer>
            {/* Small screens: surface the status under the buttons */}
            <p role="status" className="border-t border-line px-6 py-2.5 text-[10.5px] leading-snug text-ink-faint sm:hidden">
              {note}
            </p>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
