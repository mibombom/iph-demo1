import { useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Gauge, Monitor, Moon, RotateCw, Sparkles, Sun, Waves, X } from "lucide-react";
import { useSettings, type ThemePref } from "../context/Settings";
import { useScrollLock } from "../lib/scroll";
import { cn } from "../utils/cn";

const spring = { type: "spring", stiffness: 380, damping: 34, mass: 0.85 } as const;

const THEMES: { id: ThemePref; label: string; icon: typeof Sun; hint: string }[] = [
  { id: "light", label: "Light", icon: Sun, hint: "Bone paper, ink type" },
  { id: "dark", label: "Dark", icon: Moon, hint: "Low-light showroom" },
  { id: "system", label: "System", icon: Monitor, hint: "Match your device" },
];

function Switch({
  checked,
  onChange,
  label,
  description,
  icon: Icon,
}: {
  checked: boolean;
  onChange: () => void;
  label: string;
  description: string;
  icon: typeof Sun;
}) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      onClick={onChange}
      className="flex w-full items-center gap-4 rounded-3xl p-4 text-left transition-colors duration-300 surface hover-surface"
    >
      <span
        className={cn(
          "grid size-10 shrink-0 place-items-center rounded-2xl transition-colors duration-300",
          checked ? "bg-accent text-white" : "bg-ink/[0.07] text-ink-faint",
        )}
      >
        <Icon className="size-[18px]" strokeWidth={1.9} aria-hidden="true" />
      </span>
      <span className="min-w-0 flex-1">
        <span className="block text-[14px] font-bold">{label}</span>
        <span className="mt-0.5 block text-[12px] leading-relaxed text-ink-faint">{description}</span>
      </span>
      <span
        aria-hidden="true"
        className={cn(
          "relative h-6 w-11 shrink-0 rounded-full transition-colors duration-300",
          checked ? "bg-accent" : "bg-ink/15",
        )}
      >
        <motion.span
          layout
          transition={spring}
          className="absolute top-0.5 size-5 rounded-full bg-white shadow-sm"
          style={{ left: checked ? 22 : 2 }}
        />
      </span>
    </button>
  );
}

export default function SettingsPanel() {
  const {
    theme,
    resolvedTheme,
    reduceMotion,
    autoRotate3D,
    smoothScroll,
    settingsOpen,
    closeSettings,
    setTheme,
    toggle,
    reset,
  } = useSettings();

  // Freeze the homepage while the settings panel is open
  useScrollLock(settingsOpen);

  useEffect(() => {
    if (!settingsOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && closeSettings();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [settingsOpen, closeSettings]);

  return (
    <AnimatePresence>
      {settingsOpen && (
        <>
          <motion.div
            key="set-scrim"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={closeSettings}
            aria-hidden="true"
            className="fixed inset-0 z-[88] bg-ink/50 backdrop-blur-md"
          />
          <div data-lenis-prevent className="fixed inset-0 z-[92] grid place-items-center overflow-y-auto overscroll-contain p-4">
            <motion.div
              role="dialog"
              aria-modal="true"
              aria-labelledby="settings-title"
              initial={{ opacity: 0, y: 40, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 26, scale: 0.97 }}
              transition={spring}
              className="w-full max-w-lg overflow-hidden rounded-[30px] bg-bone shadow-[0_50px_120px_-30px_rgba(0,0,0,0.6)]"
            >
              {/* Header */}
              <div className="relative panel-dark px-7 pb-7 pt-7">
                <button
                  onClick={closeSettings}
                  aria-label="Close settings"
                  className="absolute right-4 top-4 grid size-9 place-items-center rounded-full text-white/55 transition-colors hover:bg-white/10 hover:text-white"
                >
                  <X className="size-4.5" aria-hidden="true" />
                </button>
                <p className="eyebrow text-accent">Preferences</p>
                <h2 id="settings-title" className="display-tight mt-3 text-[30px] font-bold">
                  Site <span className="serif-accent font-normal text-white/85">settings.</span>
                </h2>
                <p className="mt-2 text-[13.5px] text-white/50">
                  Tune the appearance and motion of the AURA store. Saved to this browser.
                </p>
              </div>

              <div className="space-y-7 px-7 py-7">
                {/* Appearance */}
                <section>
                  <h3 className="eyebrow mb-3 flex items-center gap-2 text-ink-faint">
                    <Sparkles className="size-3.5 text-accent" aria-hidden="true" />
                    Appearance
                  </h3>
                  <div role="radiogroup" aria-label="Colour theme" className="grid grid-cols-3 gap-2.5">
                    {THEMES.map(({ id, label, icon: Icon, hint }) => {
                      const active = theme === id;
                      return (
                        <button
                          key={id}
                          role="radio"
                          aria-checked={active}
                          onClick={() => setTheme(id)}
                          className={cn(
                            "relative overflow-hidden rounded-3xl p-4 text-left transition-colors duration-300",
                            active ? "text-white" : "surface hover-surface text-ink",
                          )}
                        >
                          {active && (
                            <motion.span
                              layoutId="theme-pill"
                              className="absolute inset-0 bg-accent"
                              transition={spring}
                            />
                          )}
                          <span className="relative z-10 block">
                            <Icon className="size-5" strokeWidth={1.9} aria-hidden="true" />
                            <span className="mt-3 block text-[13.5px] font-bold">{label}</span>
                            <span
                              className={cn(
                                "mt-0.5 block text-[11px] leading-snug",
                                active ? "text-white/70" : "text-ink-faint",
                              )}
                            >
                              {hint}
                            </span>
                          </span>
                        </button>
                      );
                    })}
                  </div>
                  <p className="mt-2.5 text-[11.5px] text-ink-faint" aria-live="polite">
                    Currently showing the <strong className="font-semibold text-ink">{resolvedTheme}</strong> theme
                    {theme === "system" && " (following your device)"}.
                  </p>
                </section>

                {/* Motion & interaction */}
                <section>
                  <h3 className="eyebrow mb-3 flex items-center gap-2 text-ink-faint">
                    <Gauge className="size-3.5 text-accent" aria-hidden="true" />
                    Motion &amp; interaction
                  </h3>
                  <div className="space-y-2.5">
                    <Switch
                      icon={Waves}
                      checked={smoothScroll}
                      onChange={() => toggle("smoothScroll")}
                      label="Smooth scrolling"
                      description="Inertial, glass-like page movement between sections."
                    />
                    <Switch
                      icon={RotateCw}
                      checked={autoRotate3D}
                      onChange={() => toggle("autoRotate3D")}
                      label="Auto-rotate 3D iPhone"
                      description="Slowly orbit the device when you're not dragging it."
                    />
                    <Switch
                      icon={Gauge}
                      checked={reduceMotion}
                      onChange={() => toggle("reduceMotion")}
                      label="Reduce motion"
                      description="Minimise parallax, floating and reveal animations."
                    />
                  </div>
                </section>

                <div className="flex items-center justify-between gap-3 border-t border-line pt-5">
                  <button
                    onClick={reset}
                    className="text-[13px] font-semibold text-ink-soft underline-offset-4 transition-colors hover:text-accent hover:underline"
                  >
                    Reset to defaults
                  </button>
                  <button
                    onClick={closeSettings}
                    className="rounded-full bg-ink px-7 py-3 text-[14px] font-bold text-bone transition-colors hover:bg-accent hover:text-white"
                  >
                    Done
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}
