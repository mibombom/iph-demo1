import { Aperture, BatteryCharging, Cpu, Droplets, HardDrive, MonitorSmartphone, ShieldCheck, Wifi, Zap } from "lucide-react";
import { HERO_MODEL, MODELS, fmt } from "../data/products";
import { Eyebrow, Reveal } from "./ui/Reveal";

const SPECS = [
  { icon: Cpu, value: "A19 Pro", label: "6-core CPU · 6-core GPU with Neural Accelerators · vapor-chamber cooled" },
  { icon: Aperture, value: "48MP ×3", label: "Pro Fusion camera system · 8× optical-quality zoom · 4K 120fps Dolby Vision" },
  { icon: MonitorSmartphone, value: "6.9″ 3000 nits", label: "Super Retina XDR · 1–120Hz ProMotion · Always-On · anti-reflective" },
  { icon: BatteryCharging, value: "37 hours", label: "Video playback · 50% charge in 20 min with 40W adapter · MagSafe 25W" },
  { icon: Wifi, value: "Wi-Fi 7", label: "N1 wireless chip · Bluetooth 6 · Thread networking · 5G mmWave" },
  { icon: Zap, value: "USB-C 3", label: "10Gb/s transfers · ProRes direct to external drive · DisplayPort out" },
  { icon: ShieldCheck, value: "Ceramic Shield 2", label: "3× better scratch resistance, front and back — toughest glass in any phone" },
  { icon: Droplets, value: "IP68", label: "Tested to 6 m for 30 minutes · sealed sapphire lenses · dust resistant" },
];

export function Specs() {
  return (
    <section id="specs" className="scroll-mt-16 bg-bone-deep py-24 md:py-32" aria-labelledby="specs-title">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="max-w-3xl">
          <Reveal>
            <Eyebrow>Tech Specs</Eyebrow>
          </Reveal>
          <Reveal delay={0.08}>
            <h2 id="specs-title" className="display-tight mt-4 text-[11vw] font-bold sm:text-6xl md:text-7xl">
              Numbers that
              <br />
              <span className="serif-accent text-ink-soft">end arguments.</span>
            </h2>
          </Reveal>
          <Reveal delay={0.16}>
            <p className="mt-5 max-w-md text-[15px] text-ink-soft">Shown for {HERO_MODEL.name} in every finish.</p>
          </Reveal>
        </div>

        <div className="mt-14 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {SPECS.map((s, i) => (
            <Reveal key={s.value} delay={(i % 4) * 0.06} className="h-full">
              <div className="group h-full rounded-3xl bg-bone p-6 transition-colors duration-500 hover:bg-ink hover:text-bone">
                <s.icon className="size-5 text-accent" strokeWidth={1.8} aria-hidden="true" />
                <p className="display-tight mt-5 text-[26px] font-bold">{s.value}</p>
                <p className="mt-2 text-[13px] leading-relaxed text-ink-soft transition-colors duration-500 group-hover:text-bone/60">
                  {s.label}
                </p>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal delay={0.1}>
          <p className="mt-8 flex items-center gap-2 text-[12.5px] text-ink-faint">
            <HardDrive className="size-3.5" aria-hidden="true" />
            Battery life varies by use and configuration. Water resistance is not permanent and may decrease over time.
          </p>
        </Reveal>
      </div>
    </section>
  );
}

const ROWS: { label: string; get: (m: (typeof MODELS)[number]) => string }[] = [
  { label: "From", get: (m) => `${fmt(m.base)} or ${fmt(m.monthly)}/mo` },
  { label: "Display", get: (m) => m.spec.display },
  { label: "Chip", get: (m) => m.spec.chip },
  { label: "Rear camera", get: (m) => m.spec.camera },
  { label: "Telephoto", get: (m) => m.spec.zoom },
  { label: "Battery (video)", get: (m) => m.spec.battery },
  { label: "Thickness", get: (m) => m.spec.thickness },
  { label: "Weight", get: (m) => m.spec.weight },
  { label: "Connectivity", get: (m) => m.spec.connectivity },
  { label: "Finishes", get: (m) => m.finishes.map((f) => f.name).join(" · ") },
];

export function Compare() {
  return (
    <section id="compare" className="scroll-mt-16 py-24 md:py-32" aria-labelledby="compare-title">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <Reveal>
              <Eyebrow>Compare</Eyebrow>
            </Reveal>
            <Reveal delay={0.08}>
              <h2 id="compare-title" className="display-tight mt-4 text-[11vw] font-bold sm:text-6xl md:text-7xl">
                Side by side<span className="text-accent">.</span>
              </h2>
            </Reveal>
          </div>
          <Reveal delay={0.14}>
            <p className="max-w-sm text-[14px] leading-relaxed text-ink-soft">
              Every model ships with iOS, satellite Emergency SOS, and the same
              obsessive build quality. The difference is ambition.
            </p>
          </Reveal>
        </div>

        <Reveal delay={0.1} className="mt-12">
          <div className="slim-scroll overflow-x-auto rounded-[28px] border border-line" tabIndex={0} role="region" aria-label="Model comparison table, scroll horizontally">
            <table className="w-full min-w-[760px] border-collapse text-left">
              <thead>
                <tr className="border-b border-line">
                  <th scope="col" className="w-40 p-5 align-bottom">
                    <span className="eyebrow text-ink-faint">Model</span>
                  </th>
                  {MODELS.map((m) => (
                    <th key={m.id} scope="col" className="p-5 align-bottom">
                      <span className="block text-[17px] font-bold tracking-tight">{m.shortName}</span>
                      <span className="mt-0.5 block text-[12px] font-medium text-ink-faint">{m.chipShort}</span>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {ROWS.map((row, ri) => (
                  <tr key={row.label} className={ri % 2 ? "bg-ink/[0.025]" : ""}>
                    <th scope="row" className="p-5 align-top text-[12px] font-semibold uppercase tracking-[0.12em] text-ink-faint">
                      {row.label}
                    </th>
                    {MODELS.map((m, ci) => (
                      <td
                        key={m.id}
                        className={`p-5 align-top text-[13.5px] leading-relaxed ${ci === 0 ? "font-semibold" : "text-ink-soft"}`}
                      >
                        {row.get(m)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
