import { useRef, useState } from "react";
import { useInView } from "framer-motion";
import { usePrefersCalm, useSettings } from "../context/Settings";
import { Aperture, Minus, Plus, Rotate3d, Ruler, Smartphone } from "lucide-react";
import { useStore } from "../context/Store";
import { findFinish, HERO_MODEL } from "../data/products";
import { cn } from "../utils/cn";
import { Stage, type StageHandle, type StageView } from "./three/Stage";
import { Eyebrow, Reveal } from "./ui/Reveal";

const VIEWS: { id: StageView; label: string; icon: typeof Rotate3d }[] = [
  { id: "auto", label: "Orbit", icon: Rotate3d },
  { id: "front", label: "Front", icon: Smartphone },
  { id: "rear", label: "Camera", icon: Aperture },
  { id: "profile", label: "Profile", icon: Ruler },
];

export default function Studio() {
  const { state, setFinish } = useStore();
  const calm = usePrefersCalm();
  const { autoRotate3D } = useSettings();
  const finish = findFinish(HERO_MODEL.id, state.finishId);
  const [view, setView] = useState<StageView>("auto");
  const stageRef = useRef<StageHandle>(null);
  const sectionRef = useRef<HTMLElement>(null);
  const inView = useInView(sectionRef, { margin: "400px 0px", once: true });

  return (
    <section
      id="studio"
      ref={sectionRef}
      className="relative scroll-mt-16 bg-night py-24 text-bone md:py-32"
      aria-labelledby="studio-title"
    >
      {/* Ambient glow */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(52% 42% at 50% 44%, rgba(200,82,43,0.16), transparent 72%), radial-gradient(30% 26% at 84% 12%, rgba(120,150,255,0.10), transparent 70%)",
        }}
      />

      <div className="relative mx-auto max-w-7xl px-5 md:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <Eyebrow>Design Studio</Eyebrow>
          </Reveal>
          <Reveal delay={0.08}>
            <h2 id="studio-title" className="display-tight mt-4 text-[11vw] font-bold sm:text-6xl md:text-7xl">
              Every angle,
              <br />
              <span className="serif-accent text-white/90">yours to inspect.</span>
            </h2>
          </Reveal>
          <Reveal delay={0.16}>
            <p className="mx-auto mt-5 max-w-md text-[15.5px] leading-relaxed text-white/55">
              Rotate the device, zoom into the camera plateau, and switch finishes
              in real time — rendered live in your browser.
            </p>
          </Reveal>
        </div>

        {/* Stage */}
        <div className="relative mt-6 h-[62vh] min-h-[420px] w-full md:h-[72vh]">
          {inView && (
            <Stage
              ref={stageRef}
              finish={finish}
              view={view}
              onUserInteract={() => setView("free")}
              autoRotate={autoRotate3D && !calm}
              enableZoom
              shadowTone="dark"
              className="absolute inset-0 cursor-grab active:cursor-grabbing"
              label="Interactive 3D iPhone — drag to rotate, scroll to zoom, explore the camera system and finishes"
            />
          )}
          {/* Corner framelines */}
          <div aria-hidden="true" className="pointer-events-none absolute inset-6 hidden md:block">
            {["top-0 left-0 border-t border-l", "top-0 right-0 border-t border-r", "bottom-0 left-0 border-b border-l", "bottom-0 right-0 border-b border-r"].map(
              (pos) => (
                <span key={pos} className={cn("absolute size-7 border-white/20", pos)} />
              ),
            )}
          </div>
        </div>

        {/* Controls */}
        <Reveal delay={0.1} className="mt-2">
          <div className="flex flex-col items-center gap-7">
            {/* Finishes */}
            <div role="group" aria-label="Choose a finish" className="flex items-center gap-6">
              {HERO_MODEL.finishes.map((f) => {
                const active = finish.id === f.id;
                return (
                  <button
                    key={f.id}
                    onClick={() => setFinish(f.id)}
                    aria-pressed={active}
                    aria-label={`Finish: ${f.name}`}
                    className="group flex flex-col items-center gap-2.5 rounded-2xl p-1"
                  >
                    <span
                      className={cn(
                        "grid size-11 place-items-center rounded-full transition-all duration-400",
                        active
                          ? "ring-2 ring-white ring-offset-4 ring-offset-night"
                          : "ring-1 ring-white/25 hover:ring-white/60",
                      )}
                      style={{ background: f.swatch }}
                    >
                      <span className="size-4 rounded-full bg-white/25 blur-[3px] transition-opacity group-hover:opacity-0" />
                    </span>
                    <span
                      className={cn(
                        "text-[11px] font-medium tracking-wide transition-colors",
                        active ? "text-white" : "text-white/45",
                      )}
                    >
                      {f.name}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* View presets + zoom */}
            <div className="flex flex-wrap items-center justify-center gap-3">
              <div role="group" aria-label="Camera views" className="flex rounded-full p-1 hairline-bright">
                {VIEWS.map(({ id, label, icon: Icon }) => (
                  <button
                    key={id}
                    onClick={() => setView(id)}
                    aria-pressed={view === id}
                    className={cn(
                      "flex items-center gap-2 rounded-full px-4 py-2 text-[12.5px] font-semibold transition-all duration-300",
                      view === id ? "btn-light" : "text-white/55 hover:text-white",
                    )}
                  >
                    <Icon className="size-3.5" aria-hidden="true" />
                    <span className="hidden sm:inline">{label}</span>
                    <span className="sr-only sm:hidden">{label}</span>
                  </button>
                ))}
              </div>

              <div role="group" aria-label="Zoom" className="flex items-center gap-1 rounded-full p-1 hairline-bright">
                <button
                  onClick={() => stageRef.current?.zoomBy(0.85)}
                  aria-label="Zoom out"
                  className="grid size-9 place-items-center rounded-full text-white/60 transition-colors hover:bg-white/10 hover:text-white"
                >
                  <Minus className="size-4" />
                </button>
                <button
                  onClick={() => stageRef.current?.zoomBy(-0.85)}
                  aria-label="Zoom in"
                  className="grid size-9 place-items-center rounded-full text-white/60 transition-colors hover:bg-white/10 hover:text-white"
                >
                  <Plus className="size-4" />
                </button>
              </div>
            </div>

            <p className="text-[12px] tracking-wide text-white/35">
              Scroll over the device to zoom · Select “Camera” to inspect the 48MP Fusion system
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
