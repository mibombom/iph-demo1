import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Activity, Bell, Download, HeartPulse, LayoutGrid, Share2, Zap } from "lucide-react";
import { useAdminOS } from "../../context/AdminOS";
import { ADMIN_FUNCTIONS_245 } from "../../data/adminos";
import { Btn, Card, Stat, StatusPill } from "./ui";
import { cn } from "../../utils/cn";

const QUICK = ["user-create", "invoices", "report-builder", "backups", "audit-log", "broadcast", "record-create", "workflow-builder"];

const DEFAULT_WIDGETS = ["kpis", "feed", "health", "notifications", "chart", "quick", "approvals"];

export default function Dashboard({ navigate }: { navigate: (page: string, fnSlug?: string) => void }) {
  const { db, rangeLabel, currency, execute, exportCsv, toast, flags } = useAdminOS();
  const [widgets, setWidgets] = useState<string[]>(DEFAULT_WIDGETS);
  const [edit, setEdit] = useState(false);

  const kpis = db.kpis ?? [];
  const audit = db.audit ?? [];
  const notifications = (db.notifications ?? []).filter((n) => n.status === "Unread");
  const pending = (db.approvals ?? []).filter((a) => a.status === "Pending");
  const failedJobs = (db.jobs ?? []).filter((j) => j.status === "Failed");
  const openTickets = (db.tickets ?? []).filter((t) => t.status !== "Resolved");

  // Real comparison: transactions in the current window vs the previous one
  const comparison = useMemo(() => {
    const now = Date.now();
    const day = 864e5;
    const windowMs = rangeLabel === "Today" ? day : rangeLabel === "30 days" ? 30 * day : 7 * day;
    const txns = db.transactions ?? [];
    const sum = (from: number, to: number) =>
      txns.filter((t) => {
        const ts = new Date(String(t.at)).getTime();
        return ts >= from && ts < to;
      }).reduce((n, t) => n + Math.abs(Number(t.amount ?? 0)), 0);
    const current = sum(now - windowMs, now + 1);
    const previous = sum(now - 2 * windowMs, now - windowMs);
    const delta = previous === 0 ? 100 : Math.round(((current - previous) / previous) * 100);
    return { current, previous, delta };
  }, [db.transactions, rangeLabel]);

  // Real 7-bucket chart from transaction timestamps
  const chart = useMemo(() => {
    const buckets = Array.from({ length: 7 }, () => 0);
    (db.transactions ?? []).forEach((t) => {
      const days = Math.floor((Date.now() - new Date(String(t.at)).getTime()) / 864e5);
      if (days >= 0 && days < 7) buckets[6 - days] += Math.abs(Number(t.amount ?? 0));
    });
    return buckets;
  }, [db.transactions]);
  const maxBar = Math.max(1, ...chart);

  const health = {
    jobs: (db.jobs ?? []).length,
    failed: failedJobs.length,
    integrations: (db.integrations ?? []).filter((i) => i.status === "Connected").length,
    total: (db.integrations ?? []).length,
    storage: "18.4 MB (local store)",
  };

  const move = (i: number, dir: -1 | 1) => {
    setWidgets((w) => {
      const next = [...w];
      const j = i + dir;
      if (j < 0 || j >= next.length) return w;
      [next[i], next[j]] = [next[j], next[i]];
      return next;
    });
    toast("Widget order updated — layout saved for this admin.");
  };

  const widgetMeta: Record<string, { label: string; render: () => React.ReactNode }> = {
    kpis: {
      label: "KPI tracking",
      render: () => (
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          {kpis.map((k) => {
            const pct = Math.min(200, Math.round((Number(k.actual) / Math.max(1, Number(k.target))) * 100));
            return (
              <div key={String(k.id)} className="rounded-2xl border border-line p-3.5">
                <p className="text-[11px] font-semibold uppercase tracking-wider text-ink-faint">{String(k.name)}</p>
                <p className="mt-1 text-[20px] font-bold text-ink">
                  {k.unit === "$" || k.unit === "$" ? currency : ""}{String(k.actual)}{k.unit === "%" ? "%" : ""}
                </p>
                <div className="mt-2 h-1.5 rounded-full bg-ink/[0.07]">
                  <div className={cn("h-full rounded-full", pct >= 100 ? "bg-emerald-500" : "bg-accent")} style={{ width: `${Math.min(100, pct)}%` }} />
                </div>
                <p className="mt-1.5 text-[10.5px] text-ink-faint">Target {String(k.target)} · {pct}% · {String(k.period)}</p>
              </div>
            );
          })}
        </div>
      ),
    },
    feed: {
      label: "Recent activity feed",
      render: () => (
        <ul className="max-h-64 space-y-1.5 overflow-y-auto">
          {audit.slice(0, 12).map((a) => (
            <li key={String(a.id)} className="flex items-start gap-2.5 rounded-xl px-2.5 py-1.5 hover:bg-ink/[0.03]">
              <Activity className="mt-0.5 size-3.5 shrink-0 text-accent" aria-hidden="true" />
              <div className="min-w-0">
                <p className="truncate text-[12px] font-semibold text-ink">{String(a.action)}</p>
                <p className="text-[10.5px] text-ink-faint">{String(a.actor)} · {String(a.resource)} · {new Date(String(a.at)).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</p>
              </div>
            </li>
          ))}
          {audit.length === 0 && <p className="text-[12px] text-ink-faint">No activity yet — run a function to populate the feed.</p>}
        </ul>
      ),
    },
    health: {
      label: "System health summary",
      render: () => (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Stat label="Jobs" value={health.jobs} hint={`${health.failed} failed`} tone={health.failed ? "amber" : "green"} />
          <Stat label="Integrations" value={`${health.integrations}/${health.total}`} hint="connected" />
          <Stat label="Storage" value={health.storage} hint="browser local store" />
          <Stat label="Maintenance" value={flags["system.maintenance"] ? "ON" : "OFF"} hint={flags["system.maintenance"] ? "restricted mode" : "normal operation"} tone={flags["system.maintenance"] ? "amber" : "green"} />
        </div>
      ),
    },
    notifications: {
      label: "Dashboard notifications",
      render: () => (
        <ul className="space-y-1.5">
          {pending.length > 0 && <li className="rounded-xl bg-amber-500/10 px-3 py-2 text-[12px] font-semibold text-amber-600">{pending.length} approvals pending review</li>}
          {failedJobs.length > 0 && <li className="rounded-xl bg-red-500/10 px-3 py-2 text-[12px] font-semibold text-red-500">{failedJobs.length} background job(s) failed — retry from Automation</li>}
          {openTickets.length > 0 && <li className="rounded-xl bg-ink/[0.04] px-3 py-2 text-[12px] font-semibold text-ink-soft">{openTickets.length} support tickets open ({openTickets.filter((t) => t.status === "Escalated").length} escalated)</li>}
          {notifications.slice(0, 3).map((n) => (
            <li key={String(n.id)} className="rounded-xl border border-line px-3 py-2 text-[12px] text-ink">
              <span className="font-semibold">{String(n.title)}</span> — {String(n.body)}
            </li>
          ))}
          {pending.length + failedJobs.length + openTickets.length + notifications.length === 0 && (
            <li className="rounded-xl bg-emerald-500/10 px-3 py-2 text-[12px] font-semibold text-emerald-600">All clear — nothing needs attention.</li>
          )}
        </ul>
      ),
    },
    chart: {
      label: "Transaction volume (7 days)",
      render: () => (
        <div>
          <div className="flex h-32 items-end gap-2">
            {chart.map((v, i) => (
              <div key={i} className="flex-1">
                <div className="rounded-t-lg bg-accent/80 transition-all" style={{ height: `${Math.max(4, (v / maxBar) * 100)}%` }} title={`${v}`} />
              </div>
            ))}
          </div>
          <div className="mt-2 flex justify-between text-[10px] text-ink-faint">
            <span>-6d</span><span>-4d</span><span>-2d</span><span>today</span>
          </div>
          {flags["stats.compare"] && (
            <p className="mt-3 rounded-xl bg-ink/[0.04] px-3 py-2 text-[11.5px] text-ink-soft">
              <span className="font-bold text-ink">Comparative:</span> {rangeLabel} volume {comparison.current.toLocaleString()} vs previous {comparison.previous.toLocaleString()}{" "}
              <span className={cn("font-bold", comparison.delta >= 0 ? "text-emerald-600" : "text-red-500")}>
                ({comparison.delta >= 0 ? "+" : ""}{comparison.delta}%)
              </span>
            </p>
          )}
        </div>
      ),
    },
    quick: {
      label: "Quick actions",
      render: () => (
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {QUICK.map((slug) => {
            const fn = ADMIN_FUNCTIONS_245.find((x) => x.slug === slug);
            if (!fn) return null;
            return (
              <button
                key={slug}
                onClick={() => execute(fn)}
                className="rounded-2xl border border-line px-3 py-2.5 text-left text-[11.5px] font-semibold text-ink transition-colors hover:border-accent hover:text-accent"
              >
                <Zap className="mb-1 size-3.5 text-accent" aria-hidden="true" />
                {fn.title}
              </button>
            );
          })}
        </div>
      ),
    },
    approvals: {
      label: "Approvals snapshot",
      render: () => (
        <div>
          <ul className="space-y-1.5">
            {pending.slice(0, 5).map((a) => (
              <li key={String(a.id)} className="flex items-center justify-between rounded-xl border border-line px-3 py-2">
                <div>
                  <p className="text-[12px] font-semibold text-ink">{String(a.kind)} · {String(a.requester)}</p>
                  <p className="text-[10.5px] text-ink-faint">Stage {String(a.stage)} · {String(a.id)}</p>
                </div>
                <StatusPill value={a.status} />
              </li>
            ))}
            {pending.length === 0 && <p className="text-[12px] text-ink-faint">Inbox zero — no pending approvals.</p>}
          </ul>
          <button onClick={() => navigate("workflows")} className="mt-2 text-[11px] font-semibold text-accent underline">
            Open the full approval inbox →
          </button>
        </div>
      ),
    },
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="eyebrow text-ink-faint">Executive overview · {rangeLabel}</p>
          <h1 className="mt-1 text-[26px] font-bold tracking-tight text-ink">AdminOS Dashboard</h1>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Btn size="sm" tone="ghost" onClick={() => execute(ADMIN_FUNCTIONS_245[8])}>Range: {rangeLabel}</Btn>
          <Btn size="sm" tone="ghost" onClick={() => exportCsv("dashboard")}><Download className="size-3.5" /> Export</Btn>
          <Btn size="sm" tone="ghost" onClick={() => execute(ADMIN_FUNCTIONS_245[14])}><Share2 className="size-3.5" /> Share</Btn>
          <Btn size="sm" tone={edit ? "accent" : "default"} onClick={() => { setEdit((v) => !v); if (edit) toast("Dashboard layout saved for this admin."); }}>
            <LayoutGrid className="size-3.5" /> {edit ? "Done editing" : "Customize"}
          </Btn>
        </div>
      </div>

      {edit && (
        <div className="flex flex-wrap items-center gap-2 rounded-2xl border border-dashed border-line px-4 py-3">
          <p className="mr-2 text-[11.5px] font-semibold text-ink-soft">Widgets (reorder or remove):</p>
          {widgets.map((w, i) => (
            <span key={w} className="inline-flex items-center gap-1 rounded-full bg-ink/[0.05] px-2.5 py-1 text-[11px] font-semibold text-ink">
              {widgetMeta[w]?.label}
              <button onClick={() => move(i, -1)} aria-label="Move up">↑</button>
              <button onClick={() => move(i, 1)} aria-label="Move down">↓</button>
              <button onClick={() => setWidgets((ws) => ws.filter((x) => x !== w))} aria-label="Remove widget">✕</button>
            </span>
          ))}
          {DEFAULT_WIDGETS.filter((w) => !widgets.includes(w)).map((w) => (
            <button key={w} onClick={() => setWidgets((ws) => [...ws, w])} className="rounded-full border border-line px-2.5 py-1 text-[11px] font-semibold text-ink-soft hover:border-ink">
              + {widgetMeta[w]?.label}
            </button>
          ))}
        </div>
      )}

      {widgets.map((w) => (
        <motion.div key={w} layout>
          <Card
            title={
              <span className="flex items-center gap-2">
                {w === "health" ? <HeartPulse className="size-4 text-accent" /> : w === "notifications" ? <Bell className="size-4 text-accent" /> : null}
                {widgetMeta[w]?.label}
              </span>
            }
            action={<span className="text-[10.5px] text-ink-faint">{flags["stats.realtime"] ? "live" : "static"}</span>}
          >
            {widgetMeta[w]?.render()}
          </Card>
        </motion.div>
      ))}
    </div>
  );
}
