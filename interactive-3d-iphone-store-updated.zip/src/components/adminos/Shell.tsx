import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Bell, ChevronRight, Command, LogOut, Search, ShieldCheck, X,
} from "lucide-react";
import { useAdminOS } from "../../context/AdminOS";
import { useAdmin } from "../../context/Admin";
import { ADMIN_FUNCTIONS_245, NAV_GROUPS, type PageId } from "../../data/adminos";
import Dashboard from "./Dashboard";
import {
  AnalyticsPanel, AuditPanel, AutomationPanel, CollabPanel, CommsPanel, DocumentsPanel, FinancePanel, HelpPanel,
  IntegrationsPanel, RecordsPanel, RolesPanel, SecurityPanel, SettingsPanelAdmin, SystemPanel,
  UsersPanel, WorkflowsPanel,
} from "./panels";
import { BlueprintPanel, CatalogPanel, CommercePanel, MatrixPanel } from "./Views";
import { cn } from "../../utils/cn";

const PAGE_TITLES: Record<string, string> = Object.fromEntries(NAV_GROUPS.map((g) => [g.page, g.label]));

/* ─────────────────────────────── command palette ─────────────────────────── */

function CommandPalette({ open, onClose, navigate }: { open: boolean; onClose: () => void; navigate: (p: string, slug?: string) => void }) {
  const { execute } = useAdminOS();
  const [q, setQ] = useState("");

  const items = useMemo(() => {
    const pages = NAV_GROUPS.map((g) => ({ kind: "page" as const, id: g.page, label: `Go to ${g.label}` }));
    const fns = ADMIN_FUNCTIONS_245.map((fn) => ({ kind: "fn" as const, id: fn.slug, label: `#${fn.n} ${fn.title}`, fn }));
    const all = [...pages, ...fns];
    const needle = q.trim().toLowerCase();
    return (needle ? all.filter((i) => i.label.toLowerCase().includes(needle)) : all).slice(0, 40);
  }, [q]);

  useEffect(() => {
    if (open) setQ("");
  }, [open]);

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.button
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={onClose} aria-hidden="true" tabIndex={-1}
            className="fixed inset-0 z-[130] bg-ink/50 backdrop-blur-sm"
          />
          <motion.div
            role="dialog" aria-modal="true" aria-label="Command palette"
            initial={{ opacity: 0, y: -16, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -10, scale: 0.98 }}
            transition={{ type: "spring", stiffness: 380, damping: 34 }}
            className="fixed left-1/2 top-[12vh] z-[131] w-[92vw] max-w-xl -translate-x-1/2 overflow-hidden rounded-3xl border border-line bg-bone shadow-2xl"
          >
            <div className="flex items-center gap-2.5 border-b border-line px-4 py-3">
              <Search className="size-4 text-ink-faint" aria-hidden="true" />
              <input
                autoFocus value={q} onChange={(e) => setQ(e.target.value)}
                placeholder="Search pages and 245 functions…"
                aria-label="Command palette search"
                className="flex-1 bg-transparent text-[14px] outline-none placeholder:text-ink-faint/70"
              />
              <kbd className="rounded-md bg-ink/[0.06] px-1.5 py-0.5 text-[10px] font-semibold text-ink-faint">esc</kbd>
            </div>
            <ul className="max-h-[50vh] overflow-y-auto p-2">
              {items.map((item) => (
                <li key={`${item.kind}-${item.id}`}>
                  <button
                    onClick={() => {
                      if (item.kind === "page") navigate(item.id as PageId);
                      else if (item.kind === "fn" && "fn" in item) {
                        execute(item.fn);
                        navigate(item.fn.page, item.fn.slug);
                      }
                      onClose();
                    }}
                    className="flex w-full items-center justify-between rounded-2xl px-3.5 py-2.5 text-left text-[13px] font-semibold text-ink transition-colors hover:bg-ink/[0.05]"
                  >
                    <span>{item.label}</span>
                    <ChevronRight className="size-3.5 text-ink-faint" aria-hidden="true" />
                  </button>
                </li>
              ))}
              {items.length === 0 && <li className="px-4 py-8 text-center text-[12.5px] text-ink-faint">Nothing matches.</li>}
            </ul>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

/* ─────────────────────────────────── shell ───────────────────────────────── */

export default function AdminOSShell() {
  const { session, signOut, closePortal } = useAdmin();
  const { toasts, db, flags } = useAdminOS();
  const [page, setPage] = useState<string>("dashboard");
  const [collapsed, setCollapsed] = useState(false);
  const [palette, setPalette] = useState(false);
  const [bell, setBell] = useState(false);

  const navigate = (p: string) => {
    setPage(p);
    setBell(false);
  };

  // ⌘K / Ctrl+K opens the command palette
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setPalette((v) => !v);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const unread = (db.notifications ?? []).filter((n) => n.status === "Unread");

  const body = (() => {
    switch (page) {
      case "dashboard": return <Dashboard navigate={navigate} />;
      case "users": return <UsersPanel />;
      case "roles": return <RolesPanel />;
      case "security": return <SecurityPanel />;
      case "records": return <RecordsPanel />;
      case "workflows": return <WorkflowsPanel />;
      case "comms": return <CommsPanel />;
      case "finance": return <FinancePanel />;
      case "analytics": return <AnalyticsPanel navigate={navigate} />;
      case "documents": return <DocumentsPanel />;
      case "integrations": return <IntegrationsPanel />;
      case "automation": return <AutomationPanel />;
      case "system": return <SystemPanel />;
      case "audit": return <AuditPanel />;
      case "collab": return <CollabPanel />;
      case "help": return <HelpPanel />;
      case "settings": return <SettingsPanelAdmin navigate={navigate} />;
      case "catalog": return <CatalogPanel />;
      case "matrix": return <MatrixPanel />;
      case "blueprint": return <BlueprintPanel />;
      case "commerce": return <CommercePanel />;
      default: return <Dashboard navigate={navigate} />;
    }
  })();

  return (
    <div className="flex min-h-[86vh] flex-1">
      {/* Sidebar */}
      <aside
        className={cn(
          "flex shrink-0 flex-col border-r border-line bg-ink/[0.02] transition-all duration-300",
          collapsed ? "w-16" : "w-60",
        )}
      >
        <div className="flex items-center justify-between px-4 py-4">
          {!collapsed && (
            <div>
              <p className="text-[13px] font-bold tracking-[0.16em] text-ink">ADMINOS</p>
              <p className="text-[10px] text-ink-faint">Enterprise portal</p>
            </div>
          )}
          <button
            onClick={() => setCollapsed((v) => !v)}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            className="grid size-8 place-items-center rounded-full text-ink-faint hover:bg-ink/5 hover:text-ink"
          >
            <span aria-hidden="true">{collapsed ? "»" : "«"}</span>
          </button>
        </div>
        <nav aria-label="AdminOS modules" className="flex-1 overflow-y-auto px-2.5 pb-4">
          {NAV_GROUPS.map((g) => {
            const Icon = g.icon;
            const active = page === g.page;
            return (
              <button
                key={g.page}
                onClick={() => navigate(g.page)}
                aria-current={active ? "page" : undefined}
                title={g.label}
                className={cn(
                  "mb-0.5 flex w-full items-center gap-2.5 rounded-2xl px-3 py-2.5 text-left text-[12.5px] font-semibold transition-colors",
                  active ? "bg-ink text-bone" : "text-ink-soft hover:bg-ink/[0.05]",
                )}
              >
                <Icon className="size-4 shrink-0" aria-hidden="true" />
                {!collapsed && <span className="flex-1 truncate">{g.label}</span>}
              </button>
            );
          })}
        </nav>
        {!collapsed && (
          <div className="px-4 pb-4">
            <div className="rounded-2xl bg-ink/[0.04] px-3 py-2.5">
              <p className="text-[10px] font-semibold uppercase tracking-wider text-ink-faint">Environment</p>
              <p className="mt-1 text-[11px] font-semibold text-ink">Demo · simulated providers</p>
            </div>
          </div>
        )}
      </aside>

      {/* Main column */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-line bg-bone/90 px-5 py-3 backdrop-blur">
          <nav aria-label="Breadcrumb" className="hidden items-center gap-1.5 text-[11.5px] text-ink-faint sm:flex">
            <span>AdminOS</span>
            <ChevronRight className="size-3" aria-hidden="true" />
            <span className="font-semibold text-ink">{PAGE_TITLES[page] ?? page}</span>
          </nav>
          <button
            onClick={() => setPalette(true)}
            className="ml-auto flex items-center gap-2 rounded-full border border-line px-3.5 py-1.5 text-[11.5px] text-ink-faint transition-colors hover:border-ink hover:text-ink"
          >
            <Search className="size-3.5" aria-hidden="true" />
            Search or jump to…
            <kbd className="rounded-md bg-ink/[0.06] px-1.5 py-0.5 text-[9.5px] font-semibold">⌘K</kbd>
          </button>

          <div className="relative">
            <button
              onClick={() => setBell((v) => !v)}
              aria-label={`Notifications, ${unread.length} unread`}
              className="relative grid size-9 place-items-center rounded-full hover:bg-ink/5"
            >
              <Bell className="size-[17px]" strokeWidth={1.8} aria-hidden="true" />
              {unread.length > 0 && (
                <span className="absolute right-0.5 top-0.5 grid size-4 place-items-center rounded-full bg-accent text-[9px] font-bold text-white">
                  {unread.length}
                </span>
              )}
            </button>
            <AnimatePresence>
              {bell && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 6 }}
                  className="absolute right-0 top-11 z-30 w-80 overflow-hidden rounded-3xl border border-line bg-bone shadow-2xl"
                >
                  <p className="border-b border-line px-4 py-2.5 text-[12px] font-bold text-ink">Notification center</p>
                  <ul className="max-h-72 overflow-y-auto p-2">
                    {(db.notifications ?? []).slice(0, 8).map((n) => (
                      <li key={String(n.id)} className="rounded-2xl px-3 py-2 hover:bg-ink/[0.04]">
                        <p className="text-[11.5px] font-semibold text-ink">{String(n.title)}</p>
                        <p className="text-[10.5px] text-ink-faint">{String(n.body)}</p>
                      </li>
                    ))}
                    {unread.length === 0 && <li className="px-3 py-6 text-center text-[11.5px] text-ink-faint">All caught up.</li>}
                  </ul>
                  <button onClick={() => { navigate("comms"); }} className="w-full border-t border-line px-4 py-2.5 text-[11.5px] font-semibold text-accent">
                    Open notification center →
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <span className="hidden items-center gap-1.5 rounded-full bg-emerald-500/12 px-3 py-1.5 text-[11px] font-semibold text-emerald-600 sm:inline-flex">
            <ShieldCheck className="size-3.5" aria-hidden="true" />
            {session?.username ?? "admin"}
          </span>
          <button
            onClick={signOut}
            className="flex items-center gap-1.5 rounded-full border border-line px-3 py-1.5 text-[11px] font-semibold text-ink-soft hover:border-red-400 hover:text-red-500"
          >
            <LogOut className="size-3.5" aria-hidden="true" /> Sign out
          </button>
          <button
            onClick={closePortal}
            aria-label="Close admin portal"
            className="grid size-9 place-items-center rounded-full hover:bg-ink/5"
          >
            <X className="size-[17px]" strokeWidth={1.8} aria-hidden="true" />
          </button>
        </header>

        {flags["system.maintenance"] && (
          <div className="border-b border-amber-500/30 bg-amber-500/10 px-5 py-2 text-center text-[11.5px] font-semibold text-amber-600">
            ⚠ Maintenance mode is ON — non-emergency operations are restricted (admin emergency access preserved).
          </div>
        )}

        <main className="flex-1 overflow-x-hidden px-5 py-6">
          {body}
        </main>

        <footer className="border-t border-line px-5 py-3 text-[10.5px] text-ink-faint">
          AdminOS · {ADMIN_FUNCTIONS_245.length} enterprise functions + 115 commerce functions · demo dataset · simulated external providers are labeled · <Command className="inline size-3" /> K for commands
        </footer>
      </div>

      <CommandPalette open={palette} onClose={() => setPalette(false)} navigate={navigate} />

      {/* Engine toasts */}
      <div className="pointer-events-none fixed bottom-5 right-5 z-[140] flex w-[300px] flex-col gap-2">
        <AnimatePresence>
          {toasts.map((t) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 30 }}
              transition={{ type: "spring", stiffness: 380, damping: 34 }}
              className={cn(
                "rounded-2xl px-4 py-3 text-[11.5px] font-semibold shadow-lg",
                t.tone === "warn" ? "bg-amber-500 text-white" : t.tone === "info" ? "bg-ink text-bone" : "bg-emerald-600 text-white",
              )}
            >
              {t.text}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
