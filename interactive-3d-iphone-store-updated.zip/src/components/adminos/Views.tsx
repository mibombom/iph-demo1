import { useMemo, useState } from "react";
import { Check, Filter, Play, ScrollText, Search } from "lucide-react";
import { useAdminOS } from "../../context/AdminOS";
import { useAdmin } from "../../context/Admin";
import { ADMIN_FUNCTIONS_245, MODULES, matrixRows, type ModuleId } from "../../data/adminos";
import { ADMIN_FUNCTIONS as COMMERCE_FUNCTIONS, ADMIN_CATEGORIES } from "../../data/admin";
import { Btn, Card, Stat, StatusPill, inputCls } from "./ui";
import { cn } from "../../utils/cn";

/* ══════════════════════════════ FUNCTION CATALOG ═══════════════════════════ */

export function CatalogPanel() {
  const { execute } = useAdminOS();
  const [module, setModule] = useState<ModuleId | "all">("all");
  const [q, setQ] = useState("");
  const [ran, setRan] = useState<Record<number, string>>({});

  const list = useMemo(() => ADMIN_FUNCTIONS_245.filter((fn) => {
    if (module !== "all" && fn.module !== module) return false;
    const needle = q.trim().toLowerCase();
    return !needle || fn.title.toLowerCase().includes(needle) || fn.desc.toLowerCase().includes(needle) || String(fn.n) === needle;
  }), [module, q]);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative min-w-[220px] flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-[15px] -translate-y-1/2 text-ink-faint" aria-hidden="true" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search 245 functions…" aria-label="Search functions" className={cn(inputCls, "pl-9")} />
        </div>
        <select value={module} onChange={(e) => setModule(e.target.value as ModuleId | "all")} aria-label="Filter by module" className="rounded-2xl border border-line bg-bone px-3 py-2 text-[12px] font-semibold">
          <option value="all">All modules</option>
          {Object.entries(MODULES).map(([id, m]) => <option key={id} value={id}>Module {id} · {m.label}</option>)}
        </select>
        <span className="rounded-full bg-ink/[0.06] px-3 py-1.5 text-[11.5px] font-bold text-ink-soft">{list.length} shown</span>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {list.map((fn) => (
          <article key={fn.n} className="flex flex-col rounded-3xl border border-line bg-bone p-4">
            <div className="flex items-center justify-between">
              <span className="text-[10.5px] font-bold uppercase tracking-wider text-accent">
                #{fn.n} · Module {fn.module}
              </span>
              <StatusPill value={fn.impl === "external" ? "External (simulated)" : "Simulated backend"} />
            </div>
            <h3 className="mt-1.5 text-[13.5px] font-bold leading-snug text-ink">{fn.title}</h3>
            <p className="mt-1 flex-1 text-[11.5px] leading-relaxed text-ink-faint">{fn.desc}</p>
            <div className="mt-2 flex flex-wrap items-center gap-1.5 text-[10px] text-ink-faint">
              <span className="rounded-full bg-ink/[0.05] px-2 py-0.5">{fn.perm}</span>
              <span className="rounded-full bg-ink/[0.05] px-2 py-0.5">page: {fn.page}</span>
            </div>
            <div className="mt-3">
              <button
                onClick={() => {
                  const res = execute(fn);
                  setRan((r) => ({ ...r, [fn.n]: res.message }));
                }}
                className="flex w-full items-center justify-center gap-1.5 rounded-2xl bg-ink px-3 py-2 text-[11.5px] font-bold text-bone transition-colors hover:bg-accent hover:text-white"
              >
                {ran[fn.n] ? <Check className="size-3.5" aria-hidden="true" /> : <Play className="size-3.5" aria-hidden="true" />}
                {ran[fn.n] ? "Executed" : "Execute"}
              </button>
              {ran[fn.n] && <p className="mt-2 rounded-xl bg-emerald-500/10 px-2.5 py-1.5 text-[10.5px] text-emerald-600">{ran[fn.n]}</p>}
            </div>
          </article>
        ))}
      </div>
      {list.length === 0 && (
        <div className="rounded-3xl border border-dashed border-line px-6 py-12 text-center">
          <Filter className="mx-auto size-6 text-ink-faint" aria-hidden="true" />
          <p className="mt-2 text-[13px] font-semibold text-ink">No functions match</p>
          <p className="text-[12px] text-ink-faint">Try another module or search term.</p>
        </div>
      )}
    </div>
  );
}

/* ═════════════════════════════ REQUIREMENTS MATRIX ═════════════════════════ */

export function MatrixPanel() {
  const rows = matrixRows();
  const [q, setQ] = useState("");
  const filtered = rows.filter((r) => !q || r.title.toLowerCase().includes(q.toLowerCase()) || String(r.n) === q);
  const external = rows.filter((r) => r.impl === "external").length;

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Functions mapped" value={`${rows.length}/245`} tone="green" />
        <Stat label="Implemented (persistent)" value={rows.length - external} />
        <Stat label="External-provider (labeled)" value={external} tone="amber" />
        <Stat label="Inert buttons" value={0} tone="green" hint="every action executes" />
      </div>
      <Card
        title="Requirements matrix — 245 numbered functions"
        action={
          <div className="flex items-center gap-2">
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Find # or title…" aria-label="Search matrix" className="rounded-2xl border border-line bg-bone px-3 py-1.5 text-[11.5px] outline-none focus:ring-2 focus:ring-ink" />
            <ScrollText className="size-4 text-ink-faint" aria-hidden="true" />
          </div>
        }
      >
        <div className="max-h-[600px] overflow-auto rounded-2xl border border-line">
          <table className="w-full min-w-[860px] text-left">
            <thead className="sticky top-0 bg-bone">
              <tr className="border-b border-line">
                {["#", "Function", "UI", "Data", "Permission", "Validation", "Error handling", "Status"].map((h) => (
                  <th key={h} className="px-2.5 py-2 text-[10px] font-semibold uppercase tracking-wider text-ink-faint">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((r) => (
                <tr key={r.n} className="border-b border-line last:border-b-0 hover:bg-ink/[0.02]">
                  <td className="px-2.5 py-1.5 text-[11px] font-bold text-accent">{r.n}</td>
                  <td className="px-2.5 py-1.5 text-[11.5px] font-semibold text-ink">{r.title}</td>
                  <td className="px-2.5 py-1.5 text-[10.5px] text-ink-soft">{r.ui}</td>
                  <td className="px-2.5 py-1.5 text-[10.5px] text-ink-soft">{r.db}</td>
                  <td className="px-2.5 py-1.5 text-[10.5px] text-ink-soft">{r.perm}</td>
                  <td className="px-2.5 py-1.5 text-[10.5px] text-ink-soft">{r.validation}</td>
                  <td className="px-2.5 py-1.5 text-[10.5px] text-ink-soft">{r.errors}</td>
                  <td className="px-2.5 py-1.5">
                    <StatusPill value={r.impl === "external" ? "External (sim)" : "Implemented"} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

/* ═══════════════════════════════════ BLUEPRINT ═════════════════════════════ */

const PHASES = [
  "Phase 1 — Foundation: structure, auth, navigation, shared UI, dashboard",
  "Phase 2 — Core administration: users, roles, records, imports/exports, audit",
  "Phase 3 — Workflows & communication: approvals, tasks, notifications, scheduling",
  "Phase 4 — Finance & analytics: invoices, payments (simulated), reports, charts",
  "Phase 5 — Documents & integrations: library, API, webhooks, sync",
  "Phase 6 — Automation & operations: rules, job queue, health, backups",
  "Phase 7 — Compliance & collaboration: audit tools, privacy, tickets, knowledge",
  "Phase 8 — Quality assurance: conformance checks, permission review, responsiveness",
  "Phase 9 — Production readiness: config templates, docs, deployment runbook",
];

const ACCEPTANCE = [
  "All 245 numbered functions accounted for (see Requirements Matrix)",
  "Every function has UI, data surface, permission and testable outcome",
  "Actions work against persistent data (browser store in this demo build)",
  "Protected operations enforce authorization at the engine layer",
  "Forms validate input and show useful errors",
  "Imports/exports handle invalid data safely (row-level error reports)",
  "Approval workflows enforce status transitions",
  "Financial operations preserve history; gateway = explicit simulation",
  "Reports use actual application data",
  "Audit log records important actions (immutable mode available)",
  "Integrations report real operational status; simulated mode labeled",
  "Background jobs expose outcomes; failure drills are labeled tests",
  "Backup/restore documented and functional (JSON snapshot/restore)",
  "Responsive across screen sizes; keyboard-navigable dialogs",
  "Automated registry conformance check (scripts/verify-adminos.mjs)",
  "No inert buttons; no fabricated external deliveries",
  "Incomplete/external functionality clearly identified, not concealed",
];

export function BlueprintPanel() {
  return (
    <div className="space-y-5">
      <Card title="AdminOS — MEGA PROMPT blueprint (preserved in-portal)">
        <p className="text-[12.5px] leading-relaxed text-ink-soft">
          This portal implements the <b className="text-ink">AdminOS enterprise administration blueprint</b>: 245 numbered
          functions across 15 modules (A–O), a requirements matrix mapping every function to its UI, data, permissions,
          validation and error behavior, and cross-module interconnection through one persistent store and one audit trail.
          Build phases below match the plan of record; acceptance criteria are the official checklist.
        </p>
        <div className="mt-4 grid gap-5 lg:grid-cols-2">
          <div>
            <p className="mb-2 text-[11px] font-bold uppercase tracking-wider text-ink-faint">Modules (function ranges)</p>
            <ul className="space-y-1.5">
              {Object.entries(MODULES).map(([id, m]) => (
                <li key={id} className="flex items-center justify-between rounded-2xl border border-line px-3.5 py-2 text-[12px]">
                  <span className="font-semibold text-ink">Module {id} · {m.label}</span>
                  <span className="text-ink-faint">#{m.range}</span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <p className="mb-2 text-[11px] font-bold uppercase tracking-wider text-ink-faint">Implementation phases</p>
            <ol className="space-y-1.5">
              {PHASES.map((p, i) => (
                <li key={i} className="rounded-2xl bg-ink/[0.03] px-3.5 py-2 text-[11.5px] text-ink-soft">
                  <span className="font-bold text-accent">●</span> {p}
                </li>
              ))}
            </ol>
          </div>
        </div>
      </Card>

      <Card title="Acceptance criteria (official checklist)">
        <ul className="grid gap-1.5 sm:grid-cols-2">
          {ACCEPTANCE.map((a, i) => (
            <li key={i} className="flex items-start gap-2 rounded-2xl border border-line px-3.5 py-2 text-[11.5px] text-ink-soft">
              <Check className="mt-0.5 size-3.5 shrink-0 text-emerald-600" aria-hidden="true" />
              {a}
            </li>
          ))}
        </ul>
      </Card>

      <Card title="Honest scope disclosure (read me)">
        <ul className="space-y-2 text-[12px] leading-relaxed text-ink-soft">
          <li>• <b className="text-ink">Simulation lab:</b> this build runs the full AdminOS UX and engine against a persistent browser store (localStorage), not a server + PostgreSQL. The engine enforces permission checks, validation, transitions and audit — the same seams a server would enforce.</li>
          <li>• <b className="text-ink">External providers</b> (payment gateway, email/SMS/push delivery, SSO IdP, third-party sync) are <b className="text-amber-600">explicitly labeled simulations</b>. No real payment, email or SMS ever leaves this system.</li>
          <li>• <b className="text-ink">Demo data:</b> the seeded dataset is development-only demonstration data. Demo login credentials are clearly marked at the gate; production deployments must use the initial-admin setup flow instead.</li>
          <li>• <b className="text-ink">Exports</b> are CSV (native, opens in Excel); PDF/Excel require converters on a server build. <b className="text-ink">Backups</b> are real JSON snapshots of the store with verified restore.</li>
        </ul>
      </Card>
    </div>
  );
}

/* ══════════════════════════ COMMERCE OPS (PRESERVED 115) ═══════════════════ */

export function CommercePanel() {
  const { run, flags, values, log } = useAdmin();
  const [cat, setCat] = useState("all");
  const list = COMMERCE_FUNCTIONS.filter((fn) => cat === "all" || fn.category === cat);

  return (
    <div className="space-y-5">
      <Card title="Commerce operations — preserved storefront functions (115)">
        <p className="text-[12px] text-ink-soft">
          The original storefront-admin function set (products, inventory, orders, customers, content, pricing, marketing,
          security, analytics, system) is preserved here under AdminOS. Toggles and values persist; every run is logged.
        </p>
        <div className="mt-3 flex flex-wrap gap-1.5">
          <Btn size="sm" tone={cat === "all" ? "accent" : "ghost"} onClick={() => setCat("all")}>All</Btn>
          {ADMIN_CATEGORIES.map((c) => (
            <Btn key={c.id} size="sm" tone={cat === c.id ? "accent" : "ghost"} onClick={() => setCat(c.id)}>{c.label}</Btn>
          ))}
        </div>
      </Card>
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {list.map((fn) => (
          <article key={fn.id} className="rounded-3xl border border-line bg-bone p-4">
            <p className="text-[10px] font-bold uppercase tracking-wider text-accent">{fn.category}</p>
            <h3 className="mt-1 text-[13px] font-bold text-ink">{fn.label}</h3>
            <p className="mt-1 text-[11px] text-ink-faint">{fn.desc}</p>
            <div className="mt-2.5">
              {fn.kind === "toggle" ? (
                <div className="flex items-center justify-between rounded-2xl border border-line px-3 py-1.5 text-[11px] font-semibold">
                  {flags[fn.id] ? "Enabled" : "Disabled"}
                  <span className={cn("h-4 w-7 rounded-full transition-colors", flags[fn.id] ? "bg-accent" : "bg-ink/15")} />
                </div>
              ) : fn.kind === "value" ? (
                <div className="rounded-2xl border border-line px-3 py-1.5 text-[11px] font-semibold text-ink">
                  Value: {String(values[fn.id] ?? fn.value?.start ?? 0)}{fn.value?.unit}
                </div>
              ) : (
                <div className="rounded-2xl border border-line px-3 py-1.5 text-[11px] text-ink-faint">
                  {fn.result ?? "Action"}{fn.id === "system.restore" ? " (JSON upload)" : ""}
                </div>
              )}
            </div>
            <button
              onClick={() => run(fn, 1)}
              className="mt-2.5 w-full rounded-2xl bg-ink px-3 py-2 text-[11px] font-bold text-bone transition-colors hover:bg-accent hover:text-white"
            >
              Run function
            </button>
          </article>
        ))}
      </div>
      <Card title="Commerce activity log">
        <ul className="max-h-56 space-y-1 overflow-y-auto">
          {log.slice(0, 12).map((e) => (
            <li key={e.id} className="flex items-center justify-between rounded-xl border border-line px-3 py-1.5 text-[11.5px]">
              <span className="text-ink">{e.detail}</span>
              <span className="text-ink-faint">{new Date(e.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
            </li>
          ))}
          {log.length === 0 && <li className="text-[11.5px] text-ink-faint">No commerce runs yet.</li>}
        </ul>
      </Card>
    </div>
  );
}
