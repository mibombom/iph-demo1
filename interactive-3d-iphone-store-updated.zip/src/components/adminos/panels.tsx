import { useRef, useState } from "react";
import {
  AlertTriangle, Archive, Check, Download, FileUp, History, Play, Plus, RefreshCw, RotateCcw,
  ShieldAlert, Upload, UserPlus,
} from "lucide-react";
import { useAdminOS } from "../../context/AdminOS";
import { MODULES, type PageId } from "../../data/adminos";
import { Btn, Card, DataTable, Dialog, Field, Stat, StatusPill, inputCls, type Column } from "./ui";
import type { Row } from "../../data/adminos-seed";
import { cn } from "../../utils/cn";

/* ══════════════════════════════════ USERS ═════════════════════════════════ */

export function UsersPanel() {
  const { db, create, update, setStatus, exportCsv, importCsv, toast, execute, bulkPatch } = useAdminOS();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", role: "Viewer", group: "Support" });
  const fileRef = useRef<HTMLInputElement>(null);

  const columns: Column<Row>[] = [
    { key: "name", label: "Name" },
    { key: "email", label: "Email" },
    { key: "role", label: "Role" },
    { key: "group", label: "Group" },
    { key: "status", label: "Status", render: (v) => <StatusPill value={v} /> },
    { key: "verified", label: "Verified" },
    { key: "lastLogin", label: "Last login", render: (v) => new Date(String(v)).toLocaleDateString() },
  ];

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Total users" value={(db.users ?? []).length} />
        <Stat label="Active" value={(db.users ?? []).filter((u) => u.status === "Active").length} tone="green" />
        <Stat label="Suspended / inactive" value={(db.users ?? []).filter((u) => u.status === "Suspended" || u.status === "Inactive").length} tone="amber" />
        <Stat label="Pending verification" value={(db.users ?? []).filter((u) => u.verified === "no").length} />
      </div>

      <Card title="User directory" action={<span className="text-[10.5px] text-ink-faint">search · sort · filter · bulk · export</span>}>
        <DataTable
          type="users" title="users" rows={db.users ?? []} columns={columns}
          searchKeys={["name", "email", "role", "group", "status"]}
          onCreate={() => setOpen(true)} createLabel="Create user"
          extraActions={
            <>
              <Btn size="sm" tone="ghost" onClick={() => fileRef.current?.click()}><Upload className="size-3.5" /> Import CSV</Btn>
              <input
                ref={fileRef} type="file" accept=".csv,text/csv" className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  f.text().then((text) => {
                    const res = importCsv("users", text);
                    if (res.errors.length) {
                      const blob = new Blob([res.errors.join("\n")], { type: "text/plain" });
                      const a = document.createElement("a");
                      a.href = URL.createObjectURL(blob);
                      a.download = "adminos-import-errors-users.txt";
                      a.click();
                      URL.revokeObjectURL(a.href);
                    }
                  });
                  e.target.value = "";
                }}
              />
            </>
          }
          rowActions={(row) => (
            <>
              <Btn size="sm" tone="ghost" onClick={() => { setStatus("users", String(row.id), "Active"); toast(`${row.name} activated.`); }}>Activate</Btn>
              <Btn size="sm" tone="ghost" onClick={() => { setStatus("users", String(row.id), "Suspended"); toast(`${row.name} suspended — records preserved.`); }}>Suspend</Btn>
              <Btn size="sm" tone="ghost" onClick={() => { update("users", String(row.id), { verified: "yes" }); toast(`${row.name} marked verified.`); }}><Check className="size-3.5" /></Btn>
            </>
          )}
        />
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="Lifecycle & bulk actions">
          <div className="flex flex-wrap gap-2">
            <Btn tone="primary" onClick={() => { const r = create("users", { name: "Quick Add User", email: `quick${Date.now() % 1000}@demo.aura` }); toast(`Created ${r.id}.`); }}><UserPlus className="size-3.5" /> Quick create</Btn>
            <Btn tone="ghost" onClick={() => bulkPatch("users", (db.users ?? []).filter((u) => u.status === "Pending").map((u) => String(u.id)), { status: "Active" })}>Activate all pending</Btn>
            <Btn tone="ghost" onClick={() => exportCsv("users")}><Download className="size-3.5" /> Export users</Btn>
            <Btn tone="ghost" onClick={() => execute({ n: 27, slug: "user-dupes", title: "Duplicate Account Detection", module: "B", page: "users", desc: "", perm: "users.view", impl: "simulated", op: { k: "report", kind: "user-duplicates" }, db: "", validation: "", errors: "" })}>Duplicate scan</Btn>
            <Btn tone="ghost" onClick={() => execute({ n: 33, slug: "password-reset", title: "Password Reset Administration", module: "B", page: "security", desc: "", perm: "users.edit", impl: "external", op: { k: "notify", channel: "email", scope: "user" }, db: "", validation: "", errors: "" })}>Password reset (sim email)</Btn>
          </div>
          <p className="mt-3 text-[11.5px] leading-relaxed text-ink-faint">
            Deletion applies the retention policy: rows are marked <em>pending-purge</em>, not destroyed. Audit history is preserved for every lifecycle change.
          </p>
        </Card>
        <Card title="Groups & tags">
          <ul className="space-y-1.5">
            {(db.groups ?? []).slice(0, 8).map((g) => (
              <li key={String(g.id)} className="flex items-center justify-between rounded-2xl border border-line px-3.5 py-2 text-[12.5px]">
                <span className="font-semibold text-ink">{String(g.name)}</span>
                <span className="text-ink-faint">{String(g.members)} members · {String(g.desc)}</span>
              </li>
            ))}
          </ul>
          <div className="mt-3 flex gap-2">
            <Btn size="sm" tone="ghost" onClick={() => { create("groups"); }}><Plus className="size-3.5" /> Group</Btn>
            <Btn size="sm" tone="ghost" onClick={() => { create("tags"); }}><Plus className="size-3.5" /> Tag</Btn>
          </div>
        </Card>
      </div>

      <Dialog open={open} onClose={() => setOpen(false)} title="Create user">
        <div className="space-y-3">
          <Field label="Full name"><input className={inputCls} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Jane Doe" /></Field>
          <Field label="Email"><input className={inputCls} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="jane@demo.aura" /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Role">
              <select className={inputCls} value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
                {(db.roles ?? []).map((r) => <option key={String(r.id)}>{String(r.name)}</option>)}
              </select>
            </Field>
            <Field label="Group">
              <select className={inputCls} value={form.group} onChange={(e) => setForm({ ...form, group: e.target.value })}>
                {(db.groups ?? []).map((g) => <option key={String(g.id)}>{String(g.name)}</option>)}
              </select>
            </Field>
          </div>
          <div className="flex justify-end gap-2 pt-1">
            <Btn tone="ghost" onClick={() => setOpen(false)}>Cancel</Btn>
            <Btn tone="primary" onClick={() => {
              if (form.name.trim().length < 2) { toast("Validation: name needs at least 2 characters.", "warn"); return; }
              if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email)) { toast("Validation: enter a valid email address.", "warn"); return; }
              create("users", { ...form, status: "Active", verified: "no" });
              toast(`User “${form.name}” created.`);
              setForm({ name: "", email: "", role: "Viewer", group: "Support" });
              setOpen(false);
            }}>Create</Btn>
          </div>
        </div>
      </Dialog>
    </div>
  );
}

/* ══════════════════════════════════ ROLES ═════════════════════════════════ */

const MATRIX_ACTIONS = ["view", "create", "edit", "delete", "export", "approve"];

export function RolesPanel() {
  const { db, create, toast, auditAdd } = useAdminOS();
  const [cells, setCells] = useState<Record<string, boolean>>(() => {
    const init: Record<string, boolean> = {};
    Object.keys(MODULES).forEach((m) => MATRIX_ACTIONS.forEach((a) => { init[`${m}.${a}`] = a !== "delete"; }));
    return init;
  });

  const columns: Column<Row>[] = [
    { key: "name", label: "Role" },
    { key: "desc", label: "Description" },
    { key: "perms", label: "Permissions" },
    { key: "users", label: "Users" },
  ];

  return (
    <div className="space-y-5">
      <Card title="Roles" action={<Btn size="sm" tone="primary" onClick={() => create("roles")}><Plus className="size-3.5" /> New role</Btn>}>
        <DataTable type="roles" title="roles" rows={db.roles ?? []} columns={columns} searchKeys={["name", "desc"]} />
      </Card>

      <Card title="Permission matrix" action={<span className="text-[10.5px] text-ink-faint">click a cell to grant/revoke — every change is audited</span>}>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[620px] text-left">
            <thead>
              <tr>
                <th className="px-2 py-2 text-[11px] uppercase tracking-wider text-ink-faint">Module</th>
                {MATRIX_ACTIONS.map((a) => <th key={a} className="px-2 py-2 text-[11px] uppercase tracking-wider text-ink-faint">{a}</th>)}
              </tr>
            </thead>
            <tbody>
              {Object.entries(MODULES).map(([id, meta]) => (
                <tr key={id} className="border-t border-line">
                  <td className="px-2 py-2 text-[12px] font-semibold text-ink">{meta.label}</td>
                  {MATRIX_ACTIONS.map((a) => {
                    const key = `${id}.${a}`;
                    return (
                      <td key={a} className="px-2 py-2">
                        <button
                          role="checkbox" aria-checked={!!cells[key]} aria-label={`${meta.label} ${a}`}
                          onClick={() => {
                            const next = !cells[key];
                            setCells((c) => ({ ...c, [key]: next }));
                            auditAdd("permission.change", key, String(!next), String(next));
                            toast(`${key} ${next ? "granted" : "revoked"}.`);
                          }}
                          className={cn(
                            "size-5 rounded-md border transition-colors",
                            cells[key] ? "border-accent bg-accent text-white" : "border-line bg-bone",
                          )}
                        >
                          {cells[key] && <Check className="mx-auto size-3" aria-hidden="true" />}
                        </button>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

/* ═════════════════════════════════ SECURITY ═══════════════════════════════ */

export function SecurityPanel() {
  const { db, settings, update, create, toast, exportCsv } = useAdminOS();

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Active sessions" value={(db.sessions ?? []).filter((s) => s.status === "Active").length} />
        <Stat label="High-severity events" value={(db.securityEvents ?? []).filter((e) => e.severity === "High").length} tone="red" />
        <Stat label="Blocked IP rules" value={(db.ipRules ?? []).filter((r) => r.rule === "Blocked").length} />
        <Stat label="Failed logins (log)" value={(db.loginHistory ?? []).filter((l) => l.outcome === "Failed").length} tone="amber" />
      </div>

      <Card title="Security configuration">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          <Stat label="Password min length" value={String(settings["policy.minLength"] ?? 12)} hint="policy.minLength" />
          <Stat label="Login rate limit" value={`${settings["auth.rateLimit"] ?? 5}/min`} hint="progressive delay after limit" />
          <Stat label="Session timeout" value={`${settings["session.timeout"] ?? 12}h`} hint="idle expiry" />
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <Btn tone="ghost" onClick={() => toast("Password policy saved: min length enforced, reuse blocked (6 generations).")}><Check className="size-3.5" /> Review password policy</Btn>
          <Btn tone="ghost" onClick={() => exportCsv("loginHistory")}><Download className="size-3.5" /> Export login history</Btn>
          <Btn tone="ghost" onClick={() => { create("incidents", { title: "Manual incident record", status: "Investigating", owner: "usr-007" }); toast("Incident recorded — assign an investigator to continue."); }}><ShieldAlert className="size-3.5" /> Record incident</Btn>
          <Btn tone="danger" onClick={() => {
            if (!window.confirm("Force-logout ALL user sessions?")) return;
            (db.sessions ?? []).forEach((s) => update("sessions", String(s.id), { status: "Revoked" }));
            toast("All sessions revoked.");
          }}>Force-logout all sessions</Btn>
        </div>
      </Card>

      <Card title="Sessions">
        <DataTable
          type="sessions" title="sessions" rows={db.sessions ?? []}
          columns={[
            { key: "user", label: "User" }, { key: "device", label: "Device" }, { key: "ip", label: "IP" },
            { key: "status", label: "Status", render: (v) => <StatusPill value={v} /> },
            { key: "lastSeen", label: "Last seen", render: (v) => new Date(String(v)).toLocaleString() },
          ]}
          searchKeys={["user", "device", "ip"]}
          rowActions={(row) => (
            <Btn size="sm" tone="danger" onClick={() => { update("sessions", String(row.id), { status: "Revoked" }); toast(`Session ${row.id} revoked.`); }}>Revoke</Btn>
          )}
        />
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="Security events">
          <DataTable
            type="securityEvents" title="events" rows={db.securityEvents ?? []}
            columns={[
              { key: "kind", label: "Event" }, { key: "actor", label: "Actor" },
              { key: "severity", label: "Severity", render: (v) => <StatusPill value={v} /> },
              { key: "at", label: "When", render: (v) => new Date(String(v)).toLocaleString() },
            ]}
            searchKeys={["kind", "actor"]}
          />
        </Card>
        <Card title="Trusted devices & IP policies">
          <ul className="space-y-1.5">
            {(db.devices ?? []).map((d) => (
              <li key={String(d.id)} className="flex items-center justify-between rounded-2xl border border-line px-3.5 py-2 text-[12.5px]">
                <span className="font-semibold text-ink">{String(d.name)}</span>
                <span className="text-ink-faint">{String(d.user)} · <StatusPill value={d.trust} /></span>
              </li>
            ))}
            {(db.ipRules ?? []).map((r) => (
              <li key={String(r.id)} className="flex items-center justify-between rounded-2xl border border-line px-3.5 py-2 text-[12.5px]">
                <span className="font-mono text-ink">{String(r.cidr)}</span>
                <StatusPill value={r.rule} />
              </li>
            ))}
          </ul>
          <div className="mt-3 flex gap-2">
            <Btn size="sm" tone="ghost" onClick={() => { create("ipRules", { cidr: `198.51.100.${Math.floor(Math.random() * 250)}/32`, rule: "Blocked" }); toast("IP rule added."); }}><Plus className="size-3.5" /> Block IP</Btn>
            <Btn size="sm" tone="ghost" onClick={() => { create("recoveryTokens"); toast("Time-limited recovery token issued (demo value recorded in audit)."); }}><RotateCcw className="size-3.5" /> Issue recovery token</Btn>
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ═════════════════════════════════ RECORDS ════════════════════════════════ */

export function RecordsPanel() {
  const { db, create, update, setStatus, toast, exportCsv, importCsv, bulkPatch, settings } = useAdminOS();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ title: "", type: "Request", priority: "Medium" });
  const [view, setView] = useState("all");
  const fileRef = useRef<HTMLInputElement>(null);

  const rows = (db.records ?? []).filter((r) => {
    if (view === "all") return true;
    if (view === "high") return r.priority === "High";
    if (view === "open") return r.status !== "Archived";
    return String(r.status) === view;
  });

  return (
    <div className="space-y-5">
      <Card
        title="Universal record manager"
        action={
          <div className="flex flex-wrap items-center gap-2">
            <select value={view} onChange={(e) => setView(e.target.value)} aria-label="Saved views" className="rounded-2xl border border-line bg-bone px-2.5 py-1.5 text-[11.5px] font-semibold">
              <option value="all">All records</option>
              <option value="high">Saved view: High priority</option>
              <option value="open">Saved view: Not archived</option>
              <option value="In review">Status: In review</option>
            </select>
            <Btn size="sm" tone="ghost" onClick={() => fileRef.current?.click()}><FileUp className="size-3.5" /> Import</Btn>
            <input ref={fileRef} type="file" accept=".csv" className="hidden" onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) f.text().then((t) => {
                const res = importCsv("records", t);
                if (res.errors.length) toast(`${res.errors.length} rows skipped — error report downloaded.`, "warn");
              });
              e.target.value = "";
            }} />
            <Btn size="sm" tone="primary" onClick={() => setOpen(true)}><Plus className="size-3.5" /> New record</Btn>
          </div>
        }
      >
        <DataTable
          type="records" title="records" rows={rows}
          columns={[
            { key: "title", label: "Title" },
            { key: "type", label: "Type" },
            { key: "status", label: "Status", render: (v) => <StatusPill value={v} /> },
            { key: "priority", label: "Priority" },
            { key: "owner", label: "Owner" },
            { key: "tags", label: "Tags", render: (v) => (Array.isArray(v) ? (v as string[]).join(", ") : String(v ?? "")) },
          ]}
          searchKeys={["title", "type", "status", "owner"]}
          rowActions={(row) => (
            <>
              <Btn size="sm" tone="ghost" onClick={() => { update("records", String(row.id), { tags: ["demo", "reviewed"] }); toast("Tagged."); }}>Tag</Btn>
              <Btn size="sm" tone="ghost" onClick={() => { setStatus("records", String(row.id), "Archived"); toast(`${row.id} archived — restorable.`); }}><Archive className="size-3.5" /></Btn>
            </>
          )}
        />
      </Card>

      <div className="grid gap-5 lg:grid-cols-3">
        <Card title="Custom fields & types">
          <ul className="space-y-1.5 text-[12px]">
            {(db.fields ?? []).map((f) => (
              <li key={String(f.id)} className="flex items-center justify-between rounded-2xl border border-line px-3 py-2">
                <span className="font-semibold text-ink">{String(f.name)}</span>
                <span className="text-ink-faint">{String(f.type)} {f.required ? "· required" : ""}</span>
              </li>
            ))}
          </ul>
          <div className="mt-3 flex gap-2">
            <Btn size="sm" tone="ghost" onClick={() => create("fields")}><Plus className="size-3.5" /> Field</Btn>
            <Btn size="sm" tone="ghost" onClick={() => create("recordTypes")}><Plus className="size-3.5" /> Type</Btn>
            <Btn size="sm" tone="ghost" onClick={() => create("forms")}><Plus className="size-3.5" /> Form</Btn>
          </div>
        </Card>
        <Card title="Bulk & saved views">
          <div className="flex flex-wrap gap-2">
            <Btn size="sm" tone="ghost" onClick={() => { const n = bulkPatch("records", rows.slice(0, 4).map((r) => String(r.id)), { status: "In review" }); toast(`${n} records moved to In review.`); }}>Bulk review top 4</Btn>
            <Btn size="sm" tone="ghost" onClick={() => create("savedViews", { name: `View ${Date.now() % 100}`, dataset: "records", filter: view })}>Save current view</Btn>
            <Btn size="sm" tone="ghost" onClick={() => exportCsv("records")}><Download className="size-3.5" /> Export</Btn>
          </div>
          <ul className="mt-3 space-y-1.5">
            {(db.savedViews ?? []).map((v) => (
              <li key={String(v.id)} className="rounded-2xl border border-line px-3 py-2 text-[12px]">
                <span className="font-semibold text-ink">{String(v.name)}</span>
                <span className="text-ink-faint"> · {String(v.filter)}</span>
              </li>
            ))}
          </ul>
        </Card>
        <Card title="Retention & validation">
          <p className="text-[12px] text-ink-soft">
            Retention window: <span className="font-bold text-ink">{String(settings["retention.days"] ?? 365)} days</span> (Retention Policies sets this).
          </p>
          <p className="mt-2 text-[11.5px] leading-relaxed text-ink-faint">
            Client + store validation run before every save: required fields, enum statuses and referential checks (owner must exist). Archived rows are never silently deleted.
          </p>
          <div className="mt-3 flex gap-2">
            <Btn size="sm" tone="ghost" onClick={() => { bulkPatch("records", rows.filter((r) => r.status === "Archived").map((r) => String(r.id)), { status: "Active" }); toast("Archived records restored."); }}><RestoreIcon /> Restore archived</Btn>
          </div>
        </Card>
      </div>

      <Dialog open={open} onClose={() => setOpen(false)} title="New record">
        <div className="space-y-3">
          <Field label="Title"><input className={inputCls} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Record title" /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Type">
              <select className={inputCls} value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                {(db.recordTypes ?? []).map((t) => <option key={String(t.id)}>{String(t.name)}</option>)}
              </select>
            </Field>
            <Field label="Priority">
              <select className={inputCls} value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}>
                <option>Low</option><option>Medium</option><option>High</option>
              </select>
            </Field>
          </div>
          <div className="flex justify-end gap-2">
            <Btn tone="ghost" onClick={() => setOpen(false)}>Cancel</Btn>
            <Btn tone="primary" onClick={() => {
              if (form.title.trim().length < 3) { toast("Validation: title needs ≥ 3 characters.", "warn"); return; }
              create("records", { ...form, status: "Active", owner: "usr-001", tags: ["demo"] });
              toast(`Record “${form.title}” created.`);
              setForm({ title: "", type: "Request", priority: "Medium" });
              setOpen(false);
            }}>Create</Btn>
          </div>
        </div>
      </Dialog>
    </div>
  );
}

function RestoreIcon() {
  return <RotateCcw className="size-3.5" aria-hidden="true" />;
}

/* ════════════════════════════════ WORKFLOWS ═══════════════════════════════ */

export function WorkflowsPanel() {
  const { db, flow, create, update, toast, report } = useAdminOS();

  return (
    <div className="space-y-5">
      <Card title="Approval inbox" action={<Btn size="sm" tone="ghost" onClick={() => toast(report("workflow-status").detail)}><RefreshCw className="size-3.5" /> Monitor</Btn>}>
        <DataTable
          type="approvals" title="approvals" rows={db.approvals ?? []}
          columns={[
            { key: "id", label: "ID" },
            { key: "kind", label: "Workflow" },
            { key: "requester", label: "Requester" },
            { key: "amount", label: "Amount", render: (v) => (Number(v) ? `$${Number(v).toLocaleString()}` : "—") },
            { key: "stage", label: "Stage" },
            { key: "status", label: "Status", render: (v) => <StatusPill value={v} /> },
          ]}
          searchKeys={["id", "kind", "requester", "status"]}
          rowActions={(row) => (
            <>
              <Btn size="sm" tone="ghost" onClick={() => toast(flow("approve", String(row.id)))}><Check className="size-3.5" /></Btn>
              <Btn size="sm" tone="danger" onClick={() => toast(flow("reject", String(row.id)))}>Reject</Btn>
              <Btn size="sm" tone="ghost" onClick={() => toast(flow("escalate", String(row.id)))}>Escalate</Btn>
              <Btn size="sm" tone="ghost" onClick={() => toast(flow("comment", String(row.id)))}>Comment</Btn>
            </>
          )}
        />
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="Workflow definitions" action={<Btn size="sm" tone="primary" onClick={() => create("workflows")}><Plus className="size-3.5" /> New workflow</Btn>}>
          <DataTable
            type="workflows" title="workflows" rows={db.workflows ?? []}
            columns={[
              { key: "name", label: "Name" }, { key: "stages", label: "Stages" },
              { key: "version", label: "Version" }, { key: "status", label: "Status", render: (v) => <StatusPill value={v} /> },
              { key: "runs", label: "Runs" },
            ]}
            searchKeys={["name", "status"]}
            rowActions={(row) => (
              <>
                <Btn size="sm" tone="ghost" onClick={() => { create("workflows", { name: `${row.name} (from template)`, stages: String(row.stages), version: "v1", status: "Draft", runs: 0 }); toast("Workflow cloned from template."); }}>Template</Btn>
                <Btn size="sm" tone="ghost" onClick={() => {
                  const v = Number(String(row.version).replace("v", "")) + 1;
                  update("workflows", String(row.id), { version: `v${v}` });
                  toast(`${row.name} bumped to v${v} — running executions keep their version.`);
                }}>v+1</Btn>
              </>
            )}
          />
        </Card>
        <Card title="Tasks" action={<Btn size="sm" tone="primary" onClick={() => create("tasks")}><Plus className="size-3.5" /> Assign task</Btn>}>
          <DataTable
            type="tasks" title="tasks" rows={db.tasks ?? []}
            columns={[
              { key: "title", label: "Task" }, { key: "assignee", label: "Assignee" },
              { key: "priority", label: "Priority" }, { key: "status", label: "Status", render: (v) => <StatusPill value={v} /> },
              { key: "due", label: "Due", render: (v) => new Date(String(v)).toLocaleDateString() },
            ]}
            searchKeys={["title", "assignee", "status"]}
            rowActions={(row) => (
              <>
                <Btn size="sm" tone="ghost" onClick={() => { update("tasks", String(row.id), { status: "Done" }); toast(`${row.id} completed.`); }}>Done</Btn>
                <Btn size="sm" tone="ghost" onClick={() => { update("tasks", String(row.id), { depends: "tsk-001" }); toast(`${row.id} now depends on tsk-001 — blocked until it completes.`); }}>Link dep</Btn>
              </>
            )}
          />
        </Card>
      </div>
    </div>
  );
}

/* ═══════════════════════════════ COMMUNICATIONS ═══════════════════════════ */

export function CommsPanel() {
  const { db, notifyAdd, create, update, toast, exportCsv, report } = useAdminOS();
  const [preview, setPreview] = useState<string | null>(null);

  return (
    <div className="space-y-5">
      <Card
        title="Notification center"
        action={
          <div className="flex gap-2">
            <Btn size="sm" tone="ghost" onClick={() => { notifyAdd("Test broadcast", "Sent to all staff (approved audience)."); }}><MegaphoneIcon /> Broadcast</Btn>
            <Btn size="sm" tone="ghost" onClick={() => toast(report("delivery-status").detail)}>Delivery status</Btn>
            <Btn size="sm" tone="ghost" onClick={() => exportCsv("notifications")}><Download className="size-3.5" /> History</Btn>
          </div>
        }
      >
        <DataTable
          type="notifications" title="notifications" rows={db.notifications ?? []}
          columns={[
            { key: "title", label: "Title" },
            { key: "channel", label: "Channel" },
            { key: "status", label: "Status", render: (v) => <StatusPill value={v} /> },
            { key: "at", label: "When", render: (v) => new Date(String(v)).toLocaleString() },
            { key: "body", label: "Body" },
          ]}
          searchKeys={["title", "body", "channel"]}
          rowActions={(row) => (
            <>
              <Btn size="sm" tone="ghost" onClick={() => { update("notifications", String(row.id), { status: "Read" }); }}>Read</Btn>
              <Btn size="sm" tone="ghost" onClick={() => { update("notifications", String(row.id), { status: "Archived" }); }}>Archive</Btn>
            </>
          )}
        />
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="Templates & preview" action={<Btn size="sm" tone="primary" onClick={() => create("templates")}><Plus className="size-3.5" /> Template</Btn>}>
          <ul className="space-y-2">
            {(db.templates ?? []).map((t) => (
              <li key={String(t.id)} className="rounded-2xl border border-line px-3.5 py-2.5">
                <div className="flex items-center justify-between">
                  <p className="text-[12.5px] font-bold text-ink">{String(t.name)}</p>
                  <div className="flex gap-1.5">
                    <Btn size="sm" tone="ghost" onClick={() => setPreview(String(t.body).replace("{{name}}", "Ava").replace("{{org}}", "AURA").replace(/\{\{(\w+)\}\}/g, "[$1]"))}>Preview</Btn>
                    <Btn size="sm" tone="ghost" onClick={() => { update("templates", String(t.id), { active: !t.active }); toast(`Template ${t.active ? "deactivated" : "activated"}.`); }}>{t.active ? "Disable" : "Enable"}</Btn>
                  </div>
                </div>
                <p className="mt-1 truncate text-[11px] text-ink-faint">{String(t.channel)} · {String(t.body)}</p>
              </li>
            ))}
          </ul>
          {preview && (
            <div className="mt-3 rounded-2xl bg-ink/[0.04] p-3 text-[12px] text-ink">
              <p className="eyebrow mb-1 text-ink-faint">Rendered preview</p>
              {preview}
            </div>
          )}
        </Card>
        <Card title="Announcements & scheduled" action={<Btn size="sm" tone="primary" onClick={() => create("notifications", { title: "Scheduled announcement", body: "Queued for future delivery", channel: "in-app", status: "Scheduled" })}><Plus className="size-3.5" /> Schedule</Btn>}>
          <ul className="space-y-1.5">
            {(db.announcements ?? []).map((a) => (
              <li key={String(a.id)} className="flex items-center justify-between rounded-2xl border border-line px-3.5 py-2 text-[12.5px]">
                <span className="font-semibold text-ink">{String(a.title)}</span>
                <StatusPill value={a.status} />
              </li>
            ))}
            {(db.notifications ?? []).filter((n) => n.status === "Scheduled").map((n) => (
              <li key={String(n.id)} className="flex items-center justify-between rounded-2xl border border-dashed border-line px-3.5 py-2 text-[12.5px]">
                <span className="text-ink">{String(n.title)}</span>
                <StatusPill value="Scheduled" />
              </li>
            ))}
          </ul>
          <p className="mt-3 text-[11px] text-ink-faint">Email/SMS/push deliveries are simulated and recorded in the delivery log — no external provider is connected in this demo.</p>
        </Card>
      </div>
    </div>
  );
}

function MegaphoneIcon() {
  return <span aria-hidden="true">📣</span>;
}

/* ══════════════════════════════════ FINANCE ═══════════════════════════════ */

export function FinancePanel() {
  const { db, create, update, toast, exportCsv, report, currency, settings } = useAdminOS();
  const [open, setOpen] = useState(false);
  const [inv, setInv] = useState({ customer: "", item: "", qty: 1, unit: 100 });

  const revenue = (db.transactions ?? []).filter((t) => Number(t.amount) > 0).reduce((n, t) => n + Number(t.amount), 0);
  const expenses = (db.transactions ?? []).filter((t) => Number(t.amount) < 0).reduce((n, t) => n + Math.abs(Number(t.amount)), 0);
  const outstanding = (db.invoices ?? []).filter((i) => i.status === "Issued" || i.status === "Overdue").reduce((n, i) => n + Number(i.total ?? 0), 0);
  const taxRate = Number(settings["finance.taxRate"] ?? 8.5);

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Revenue (ledger)" value={`${currency}${revenue.toLocaleString()}`} tone="green" hint="settled income" />
        <Stat label="Expenses" value={`${currency}${expenses.toLocaleString()}`} tone="amber" hint="recorded outflow" />
        <Stat label="Outstanding" value={`${currency}${outstanding.toLocaleString()}`} hint="issued + overdue invoices" />
        <Stat label="Tax rate" value={`${taxRate}%`} hint="applies to new invoices" />
      </div>

      <Card
        title="Invoices"
        action={
          <div className="flex gap-2">
            <Btn size="sm" tone="ghost" onClick={() => toast(report("reconcile").detail)}>Reconcile</Btn>
            <Btn size="sm" tone="ghost" onClick={() => exportCsv("finance")}><Download className="size-3.5" /> Export</Btn>
            <Btn size="sm" tone="primary" onClick={() => setOpen(true)}><Plus className="size-3.5" /> New invoice</Btn>
          </div>
        }
      >
        <DataTable
          type="invoices" title="invoices" rows={db.invoices ?? []}
          columns={[
            { key: "number", label: "Number" }, { key: "customer", label: "Customer" },
            { key: "total", label: "Total", render: (v) => `${currency}${Number(v).toLocaleString()}` },
            { key: "status", label: "Status", render: (v) => <StatusPill value={v} /> },
            { key: "due", label: "Due", render: (v) => new Date(String(v)).toLocaleDateString() },
          ]}
          searchKeys={["number", "customer", "status"]}
          rowActions={(row) => (
            <>
              <Btn size="sm" tone="ghost" onClick={() => { update("invoices", String(row.id), { status: "Paid" }); create("receipts", { for: String(row.id), amount: Number(row.total), issued: new Date().toISOString() }); toast(`${row.number} marked Paid + receipt generated.`); }}>Pay + receipt</Btn>
              <Btn size="sm" tone="danger" onClick={() => { update("invoices", String(row.id), { status: "Cancelled" }); toast(`${row.number} cancelled.`); }}>Cancel</Btn>
            </>
          )}
        />
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="Transactions">
          <DataTable
            type="transactions" title="transactions" rows={db.transactions ?? []}
            columns={[
              { key: "kind", label: "Kind" }, { key: "party", label: "Party" },
              { key: "amount", label: "Amount", render: (v) => <span className={cn("font-semibold", Number(v) < 0 ? "text-red-500" : "text-emerald-600")}>{currency}{Number(v).toLocaleString()}</span> },
              { key: "status", label: "Status", render: (v) => <StatusPill value={v} /> },
            ]}
            searchKeys={["kind", "party", "status"]}
            pageSize={6}
            rowActions={(row) => (
              <Btn size="sm" tone="ghost" onClick={() => { create("refunds", { for: String(row.id), amount: Math.abs(Number(row.amount)) / 4, status: "Pending approval" }); toast("Refund created — requires finance.approve."); }}>Refund</Btn>
            )}
          />
        </Card>
        <Card title="Expenses & budgets">
          <DataTable
            type="expenses" title="expenses" rows={db.expenses ?? []}
            columns={[
              { key: "title", label: "Expense" }, { key: "category", label: "Category" },
              { key: "amount", label: "Amount", render: (v) => `${currency}${Number(v).toLocaleString()}` },
              { key: "status", label: "Status", render: (v) => <StatusPill value={v} /> },
            ]}
            searchKeys={["title", "category"]}
            pageSize={5}
            rowActions={(row) => (
              <Btn size="sm" tone="ghost" onClick={() => { update("expenses", String(row.id), { status: "Approved" }); toast("Expense approved (recorded in financial audit trail)."); }}>Approve</Btn>
            )}
          />
          <ul className="mt-4 space-y-2">
            {(db.budgets ?? []).map((b) => {
              const pct = Math.round((Number(b.spent) / Math.max(1, Number(b.allocated))) * 100);
              return (
                <li key={String(b.id)}>
                  <div className="flex justify-between text-[11.5px] font-semibold text-ink">
                    <span>{String(b.name)}</span>
                    <span className="text-ink-faint">{currency}{Number(b.spent).toLocaleString()} / {currency}{Number(b.allocated).toLocaleString()} ({pct}%)</span>
                  </div>
                  <div className="mt-1 h-1.5 rounded-full bg-ink/[0.07]">
                    <div className={cn("h-full rounded-full", pct > 90 ? "bg-red-500" : "bg-accent")} style={{ width: `${Math.min(100, pct)}%` }} />
                  </div>
                </li>
              );
            })}
          </ul>
          <div className="mt-3 flex gap-2">
            <Btn size="sm" tone="ghost" onClick={() => create("budgets", { name: "New budget line", allocated: 5000, spent: 0 })}><Plus className="size-3.5" /> Budget</Btn>
            <Btn size="sm" tone="ghost" onClick={() => toast(report("finance").detail)}><History className="size-3.5" /> Financial report</Btn>
          </div>
        </Card>
      </div>

      <Dialog open={open} onClose={() => setOpen(false)} title="Create invoice">
        <div className="space-y-3">
          <Field label="Customer"><input className={inputCls} value={inv.customer} onChange={(e) => setInv({ ...inv, customer: e.target.value })} placeholder="Acme Corp" /></Field>
          <Field label="Line item"><input className={inputCls} value={inv.item} onChange={(e) => setInv({ ...inv, item: e.target.value })} placeholder="Professional services" /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Quantity"><input type="number" min={1} className={inputCls} value={inv.qty} onChange={(e) => setInv({ ...inv, qty: Math.max(1, Number(e.target.value)) })} /></Field>
            <Field label="Unit price"><input type="number" min={0} className={inputCls} value={inv.unit} onChange={(e) => setInv({ ...inv, unit: Math.max(0, Number(e.target.value)) })} /></Field>
          </div>
          <div className="rounded-2xl bg-ink/[0.04] px-4 py-3 text-[12.5px] text-ink">
            Subtotal: <b>{currency}{(inv.qty * inv.unit).toLocaleString()}</b> · Tax ({taxRate}%): <b>{currency}{Math.round(inv.qty * inv.unit * taxRate) / 100}</b> ·{" "}
            Total: <b>{currency}{(inv.qty * inv.unit * (1 + taxRate / 100)).toLocaleString()}</b>
          </div>
          <div className="flex justify-end gap-2">
            <Btn tone="ghost" onClick={() => setOpen(false)}>Cancel</Btn>
            <Btn tone="primary" onClick={() => {
              if (inv.customer.trim().length < 2) { toast("Validation: customer is required.", "warn"); return; }
              const total = Math.round(inv.qty * inv.unit * (1 + taxRate / 100));
              create("invoices", { number: `INV-2026-${Math.floor(100 + Math.random() * 900)}`, customer: inv.customer, total, status: "Draft", due: new Date(Date.now() + 14 * 864e5).toISOString(), tax: taxRate });
              toast(`Invoice created (tax ${taxRate}% applied).`);
              setInv({ customer: "", item: "", qty: 1, unit: 100 });
              setOpen(false);
            }}>Create invoice</Btn>
          </div>
        </div>
      </Dialog>
    </div>
  );
}

/* ═════════════════════════════════ ANALYTICS ══════════════════════════════ */

export function AnalyticsPanel({ navigate }: { navigate: (p: string) => void }) {
  const { db, report, exportCsv, create, toast } = useAdminOS();
  const [dataset, setDataset] = useState("users");
  const reports = db.reports ?? [];

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Reports generated" value={reports.length} />
        <Stat label="Scheduled" value={(db.schedules ?? []).length} />
        <Stat label="Data freshness" value="live" hint="store-backed, recomputed per request" tone="green" />
        <Stat label="RBAC filter" value="on" hint="reports respect viewer scope" />
      </div>

      <Card title="Report builder">
        <div className="flex flex-wrap items-center gap-2">
          <select value={dataset} onChange={(e) => setDataset(e.target.value)} aria-label="Dataset" className="rounded-2xl border border-line bg-bone px-3 py-2 text-[12.5px] font-semibold">
            <option value="users">Users</option>
            <option value="records">Records</option>
            <option value="invoices">Invoices</option>
            <option value="transactions">Transactions</option>
            <option value="audit">Audit events</option>
          </select>
          <Btn tone="primary" onClick={() => { const r = report("prebuilt"); toast(`Prebuilt report: ${r.detail}`); }}><Play className="size-3.5" /> Prebuilt</Btn>
          <Btn tone="ghost" onClick={() => { const r = report("compare"); toast(String(r.detail)); }}>Compare periods</Btn>
          <Btn tone="ghost" onClick={() => { const r = report("trend"); toast(String(r.detail)); }}>Trend analysis</Btn>
          <Btn tone="ghost" onClick={() => { const r = report("anomalies"); toast(String(r.detail)); }}><AlertTriangle className="size-3.5" /> Anomalies</Btn>
          <Btn tone="ghost" onClick={() => exportCsv("report")}><Download className="size-3.5" /> Export CSV</Btn>
          <Btn tone="ghost" onClick={() => create("schedules", { report: "Weekly digest", cadence: "weekly" })}>Schedule</Btn>
          <Btn tone="ghost" onClick={() => create("reportTemplates", { name: `Template ${Date.now() % 100}`, dataset })}>Save template</Btn>
        </div>
        <p className="mt-3 text-[11px] text-ink-faint">
          CSV is the native export (opens in Excel); PDF via your converter. Export actions download real aggregates from the store.
        </p>
      </Card>

      <Card title="Interactive charts">
        <div className="grid gap-5 lg:grid-cols-2">
          <div>
            <p className="mb-2 text-[11.5px] font-semibold text-ink-faint">Invoice statuses (click bars to drill down)</p>
            <div className="flex h-36 items-end gap-2">
              {["Draft", "Issued", "Overdue", "Paid", "Cancelled"].map((s) => {
                const n = (db.invoices ?? []).filter((i) => i.status === s).length;
                return (
                  <button key={s} onClick={() => { toast(`Drill-down: ${n} invoices in “${s}”.`); navigate("finance"); }} className="flex-1 group">
                    <div className="rounded-t-lg bg-accent/75 transition-all group-hover:bg-accent" style={{ height: `${Math.max(6, n * 28)}px` }} />
                    <span className="mt-1 block text-[9.5px] font-semibold text-ink-faint">{s}</span>
                  </button>
                );
              })}
            </div>
          </div>
          <div>
            <p className="mb-2 text-[11.5px] font-semibold text-ink-faint">User statuses</p>
            <div className="flex h-36 items-end gap-2">
              {["Active", "Suspended", "Inactive", "Pending"].map((s) => {
                const n = (db.users ?? []).filter((u) => u.status === s).length;
                return (
                  <button key={s} onClick={() => { toast(`Drill-down: ${n} users “${s}”.`); navigate("users"); }} className="flex-1 group">
                    <div className="rounded-t-lg bg-ink/70 transition-all group-hover:bg-ink" style={{ height: `${Math.max(6, n * 22)}px` }} />
                    <span className="mt-1 block text-[9.5px] font-semibold text-ink-faint">{s}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </Card>

      <Card title="Generated reports">
        <ul className="space-y-1.5">
          {reports.slice(0, 10).map((r) => (
            <li key={String(r.id)} className="rounded-2xl border border-line px-3.5 py-2.5 text-[12px]">
              <div className="flex items-center justify-between">
                <span className="font-bold text-ink">{String(r.kind)}</span>
                <span className="text-[10.5px] text-ink-faint">{new Date(String(r.at)).toLocaleString()} · freshness: live</span>
              </div>
              <p className="mt-0.5 text-ink-soft">{String(r.detail)}</p>
            </li>
          ))}
          {reports.length === 0 && <p className="text-[12px] text-ink-faint">No reports yet — generate one above.</p>}
        </ul>
      </Card>
    </div>
  );
}

/* ═════════════════════════════════ DOCUMENTS ══════════════════════════════ */

export function DocumentsPanel() {
  const { db, create, update, toast, exportCsv, report } = useAdminOS();
  const fileRef = useRef<HTMLInputElement>(null);

  return (
    <div className="space-y-5">
      <Card
        title="Document library"
        action={
          <div className="flex gap-2">
            <Btn size="sm" tone="ghost" onClick={() => toast(report("doc-expiry").detail)}>Expiry scan</Btn>
            <Btn size="sm" tone="ghost" onClick={() => exportCsv("documents")}><Download className="size-3.5" /> Export</Btn>
            <Btn size="sm" tone="primary" onClick={() => fileRef.current?.click()}><Upload className="size-3.5" /> Upload</Btn>
            <input
              ref={fileRef} type="file" className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (!f) return;
                const okType = /\.(pdf|docx?|xlsx?|csv|png|jpe?g|txt|md)$/i.test(f.name);
                const okSize = f.size <= 10 * 1024 * 1024;
                if (!okType) toast("Upload rejected: unsupported file type.", "warn");
                else if (!okSize) toast("Upload rejected: exceeds 10 MB.", "warn");
                else {
                  create("documents", { title: f.name, type: "Upload", status: "Draft", size: f.size, version: 1 });
                  toast(`“${f.name}” validated and stored (metadata + demo blob).`);
                }
                e.target.value = "";
              }}
            />
          </div>
        }
      >
        <DataTable
          type="documents" title="documents" rows={db.documents ?? []}
          columns={[
            { key: "title", label: "Title" }, { key: "type", label: "Type" },
            { key: "status", label: "Status", render: (v) => <StatusPill value={v} /> },
            { key: "version", label: "Ver" },
            { key: "size", label: "Size", render: (v) => `${(Number(v) / 1024).toFixed(0)} KB` },
            { key: "expires", label: "Expires", render: (v) => new Date(String(v)).toLocaleDateString() },
          ]}
          searchKeys={["title", "type", "status"]}
          rowActions={(row) => (
            <>
              <Btn size="sm" tone="ghost" onClick={() => { update("documents", String(row.id), { version: Number(row.version ?? 1) + 1 }); toast(`${row.title} → v${Number(row.version ?? 1) + 1} (prior version preserved).`); }}>v+1</Btn>
              <Btn size="sm" tone="ghost" onClick={() => { update("documents", String(row.id), { shared: "Yes" }); toast("Share link issued to authorized group."); }}>Share</Btn>
            </>
          )}
        />
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="Folders" action={<Btn size="sm" tone="primary" onClick={() => create("folders")}><Plus className="size-3.5" /> Folder</Btn>}>
          <ul className="space-y-1.5">
            {(db.folders ?? [{ id: "fld-root", name: "Root", parent: "—" }]).map((f) => (
              <li key={String(f.id)} className="rounded-2xl border border-line px-3.5 py-2 text-[12.5px]">
                <span className="font-semibold text-ink">📁 {String(f.name)}</span>
                <span className="text-ink-faint"> · parent {String(f.parent ?? "root")}</span>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-[11px] text-ink-faint">Folder ops: create, rename, move and archive — all recorded in the document audit history.</p>
        </Card>
        <Card title="Content pages" action={<Btn size="sm" tone="primary" onClick={() => create("pages")}><Plus className="size-3.5" /> Page</Btn>}>
          <DataTable
            type="pages" title="pages" rows={db.pages ?? []}
            columns={[
              { key: "title", label: "Title" }, { key: "status", label: "Status", render: (v) => <StatusPill value={v} /> },
              { key: "revisions", label: "Revisions" },
            ]}
            searchKeys={["title", "status"]}
            pageSize={5}
            rowActions={(row) => (
              <>
                <Btn size="sm" tone="ghost" onClick={() => { update("pages", String(row.id), { status: "Published" }); toast("Page published."); }}>Publish</Btn>
                <Btn size="sm" tone="ghost" onClick={() => { update("pages", String(row.id), { revisions: Math.max(1, Number(row.revisions ?? 1) - 1) }); toast("Restored previous revision."); }}>Revert</Btn>
              </>
            )}
          />
        </Card>
      </div>
    </div>
  );
}

/* ═══════════════════════════════ INTEGRATIONS ═════════════════════════════ */

export function IntegrationsPanel() {
  const { db, create, update, toast, report, jobEnqueue, jobRun, settings } = useAdminOS();

  return (
    <div className="space-y-5">
      <Card title="Integration directory" action={<span className="text-[10.5px] text-amber-600">simulated providers labeled below</span>}>
        <DataTable
          type="integrations" title="integrations" rows={db.integrations ?? []}
          columns={[
            { key: "name", label: "Integration" }, { key: "kind", label: "Kind" },
            { key: "status", label: "Status", render: (v) => <StatusPill value={v} /> },
            { key: "mode", label: "Mode", render: (v) => <StatusPill value={v === "simulated" ? "Simulated" : "External"} /> },
            { key: "lastSync", label: "Last sync", render: (v) => new Date(String(v)).toLocaleString() },
          ]}
          searchKeys={["name", "kind", "status"]}
          onCreate={() => create("integrations")}
          rowActions={(row) => (
            <>
              <Btn size="sm" tone="ghost" onClick={() => { update("integrations", String(row.id), { status: "Connected", mode: row.mode }); toast(`${row.name} configuration saved (simulated credentials).`); }}>Config</Btn>
              <Btn size="sm" tone="ghost" onClick={() => { update("integrations", String(row.id), { mode: "simulated", rotated: "yes" }); toast(`Credential rotated for ${row.name} — secret not exposed.`); }}>Rotate</Btn>
            </>
          )}
        />
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="Webhooks" action={<Btn size="sm" tone="primary" onClick={() => create("webhooks")}><Plus className="size-3.5" /> Webhook</Btn>}>
          <DataTable
            type="webhooks" title="webhooks" rows={db.webhooks ?? []}
            columns={[
              { key: "name", label: "Name" }, { key: "events", label: "Events" },
              { key: "status", label: "Status", render: (v) => <StatusPill value={v} /> },
              { key: "failures", label: "Failures" },
            ]}
            searchKeys={["name", "events"]}
            pageSize={5}
            rowActions={(row) => (
              <>
                <Btn size="sm" tone="ghost" onClick={() => {
                  update("webhooks", String(row.id), { deliveries: Number(row.deliveries ?? 0) + 1 });
                  const j = jobEnqueue(`webhook-test:${row.name}`);
                  window.setTimeout(() => jobRun(String(j.id)), 400);
                  toast(`Test delivery queued to ${row.url} (simulated endpoint).`);
                }}>Test</Btn>
                <Btn size="sm" tone="ghost" onClick={() => { update("webhooks", String(row.id), { status: row.status === "Paused" ? "Active" : "Paused" }); }}>{row.status === "Paused" ? "Resume" : "Pause"}</Btn>
              </>
            )}
          />
          <p className="mt-3 text-[11px] text-ink-faint">Delivery log: {(db.jobs ?? []).filter((j) => String(j.type).startsWith("webhook")).length} webhook job(s) recorded · rate limit {String(settings["api.rateLimit"])} req/min.</p>
        </Card>
        <Card title="API credentials & documentation">
          <DataTable
            type="apiKeys" title="API keys" rows={db.apiKeys ?? []}
            columns={[
              { key: "name", label: "Name" }, { key: "scopes", label: "Scopes" },
              { key: "fingerprint", label: "Fingerprint" }, { key: "status", label: "Status", render: (v) => <StatusPill value={v} /> },
            ]}
            searchKeys={["name", "scopes"]}
            pageSize={5}
            rowActions={(row) => (
              <Btn size="sm" tone="ghost" onClick={() => { update("apiKeys", String(row.id), { fingerprint: `sk_live_••••${Math.floor(1000 + Math.random() * 9000)}`, status: "Active" }); toast("Key rotated — previous secret revoked."); }}>Rotate</Btn>
            )}
          />
          <div className="mt-3 rounded-2xl bg-ink/[0.04] p-3 font-mono text-[10.5px] leading-relaxed text-ink-soft">
            <p className="font-sans text-[11px] font-bold text-ink">API surface (authenticated, scoped):</p>
            GET /api/v1/users · POST /api/v1/users · GET /api/v1/records · POST /api/v1/invoices ·
            GET /api/v1/reports/&#123;kind&#125; · POST /api/v1/webhooks/test · GET /api/v1/audit
            <p className="mt-1 font-sans text-[10.5px] text-ink-faint">
              Every endpoint: auth required · permission checked · validated input · structured errors · pagination via <code>?page</code> · audit on writes. Usage: <button className="underline" onClick={() => toast(report("api-usage").detail)}>run usage report</button>.
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ═════════════════════════════════ AUTOMATION ═════════════════════════════ */

export function AutomationPanel() {
  const { db, create, update, toast, jobEnqueue, jobRun, report } = useAdminOS();

  return (
    <div className="space-y-5">
      <Card title="Automation rules" action={<Btn size="sm" tone="primary" onClick={() => create("automations")}><Plus className="size-3.5" /> New rule</Btn>}>
        <DataTable
          type="automations" title="automations" rows={db.automations ?? []}
          columns={[
            { key: "name", label: "Rule" }, { key: "trigger", label: "Trigger" },
            { key: "status", label: "Status", render: (v) => <StatusPill value={v} /> },
            { key: "runs", label: "Runs" },
            { key: "lastRun", label: "Last run", render: (v) => new Date(String(v)).toLocaleString() },
          ]}
          searchKeys={["name", "trigger", "status"]}
          rowActions={(row) => (
            <>
              <Btn size="sm" tone="ghost" onClick={() => { update("automations", String(row.id), { status: row.status === "Paused" ? "Active" : "Paused", runs: Number(row.runs ?? 0) + 1 }); toast(`${row.name} ${row.status === "Paused" ? "resumed" : "paused"}; test run counted.`); }}>{row.status === "Paused" ? "Resume" : "Pause"}</Btn>
              <Btn size="sm" tone="ghost" onClick={() => { update("automations", String(row.id), { condition: "status != Closed" }); toast("Conditional rule updated."); }}>Condition</Btn>
            </>
          )}
        />
      </Card>

      <Card
        title="Background job queue"
        action={
          <div className="flex gap-2">
            <Btn size="sm" tone="ghost" onClick={() => { const j = jobEnqueue("maintenance"); window.setTimeout(() => jobRun(String(j.id)), 500); }}><Play className="size-3.5" /> Run job</Btn>
            <Btn size="sm" tone="danger" onClick={() => {
              const j = jobEnqueue("failure-drill", true);
              window.setTimeout(() => {
                jobRun(String(j.id));
                toast("Failure-alert drill: job failed intentionally — alert dispatched to admins.", "warn");
              }, 500);
            }}>Failure drill</Btn>
            <Btn size="sm" tone="ghost" onClick={() => toast(report("rule-violations").detail)}>Validation scan</Btn>
          </div>
        }
      >
        <DataTable
          type="jobs" title="jobs" rows={db.jobs ?? []}
          columns={[
            { key: "type", label: "Job" }, { key: "status", label: "Status", render: (v) => <StatusPill value={v} /> },
            { key: "retries", label: "Retries" },
            { key: "enqueued", label: "Enqueued", render: (v) => new Date(String(v)).toLocaleString() },
          ]}
          searchKeys={["type", "status"]}
          rowActions={(row) => (
            <>
              <Btn size="sm" tone="ghost" onClick={() => jobRun(String(row.id))}><Play className="size-3.5" /> Run now</Btn>
              <Btn size="sm" tone="ghost" onClick={() => { update("jobs", String(row.id), { status: "Queued", retries: Number(row.retries ?? 0) + 1 }); toast("Retried with backoff."); }}><RotateCcw className="size-3.5" /></Btn>
            </>
          )}
        />
      </Card>
    </div>
  );
}

/* ═══════════════════════════════════ SYSTEM ═══════════════════════════════ */

export function SystemPanel() {
  const { db, flags, settings, backup, toast, exportCsv } = useAdminOS();
  const [errors, setErrors] = useState<string[]>([]);
  const errorHook = useRef(false);

  if (!errorHook.current) {
    errorHook.current = true;
    window.setTimeout(() => {
      window.addEventListener("error", (e) => {
        setErrors((prev) => [`${new Date().toLocaleTimeString()} ${e.message}`, ...prev].slice(0, 20));
      });
    }, 0);
  }

  const failed = (db.jobs ?? []).filter((j) => j.status === "Failed");
  const size = new Blob([JSON.stringify(db)]).size;

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="App health" value={failed.length ? "DEGRADED" : "HEALTHY"} tone={failed.length ? "amber" : "green"} hint={`${failed.length} failed jobs`} />
        <Stat label="Store size" value={`${(size / 1024).toFixed(0)} KB`} hint="browser local store" />
        <Stat label="Migrations" value={(db.migrations ?? []).filter((m) => m.status === "Pending").length} hint="pending" />
        <Stat label="Maintenance" value={flags["system.maintenance"] ? "ON" : "OFF"} tone={flags["system.maintenance"] ? "amber" : "green"} />
      </div>

      <Card title="Backups & recovery" action={
        <div className="flex gap-2">
          <Btn size="sm" tone="primary" onClick={backup}>Run backup</Btn>
          <Btn size="sm" tone="ghost" onClick={() => document.getElementById("restore-input")?.click()}>Restore from file</Btn>
          <input id="restore-input" type="file" accept=".json" className="hidden" onChange={(e) => {
            const f = e.target.files?.[0];
            if (!f) return;
            f.text().then((t) => {
              try {
                const parsed = JSON.parse(t) as { db?: Record<string, Row[]> };
                if (!parsed.db) { toast("Invalid backup: missing store payload. Current data untouched.", "warn"); return; }
                if (window.confirm("Replace the current store with this backup?")) {
                  localStorage.setItem("adminos-db", JSON.stringify(parsed.db));
                  toast("Backup restored — reload to apply.");
                }
              } catch {
                toast("Invalid backup file. Current data untouched.", "warn");
              }
            });
            e.target.value = "";
          }} />
        </div>
      }>
        <DataTable
          type="backups" title="backups" rows={db.backups ?? []}
          columns={[
            { key: "name", label: "Snapshot" }, { key: "size", label: "Size" },
            { key: "status", label: "Status", render: (v) => <StatusPill value={v} /> },
            { key: "at", label: "When", render: (v) => new Date(String(v)).toLocaleString() },
          ]}
          searchKeys={["name", "status"]}
          pageSize={5}
        />
        <p className="mt-3 text-[11px] text-ink-faint">
          DR configuration: RTO 4h · RPO 1h · owner Platform team · quarterly restore drills documented in the runbook (Knowledge Base).
        </p>
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="Migrations & scheduler">
          <ul className="space-y-1.5">
            {(db.migrations ?? []).map((m) => (
              <li key={String(m.id)} className="flex items-center justify-between rounded-2xl border border-line px-3.5 py-2 text-[12px]">
                <span className="font-mono text-ink">{String(m.name)}</span>
                <StatusPill value={m.status} />
              </li>
            ))}
          </ul>
          <p className="mt-3 text-[11px] text-ink-faint">
            Scheduled jobs: {(db.automations ?? []).filter((a) => a.trigger === "schedule").length} schedule-driven automations · next runs computed from cadence + {String(settings["session.timeout"])}h ops window.
          </p>
          <div className="mt-2 flex gap-2">
            <Btn size="sm" tone="ghost" onClick={() => { document.getElementById("env-btn")?.scrollIntoView({ behavior: "smooth" }); }}>Environment</Btn>
            <Btn size="sm" tone="ghost" onClick={() => exportCsv("audit")}>Export diagnostics</Btn>
          </div>
        </Card>
        <Card title="Error monitoring & environment" >
          <ul className="max-h-32 space-y-1 overflow-y-auto">
            {errors.length === 0 && <li className="text-[12px] text-ink-faint">No client errors captured since load.</li>}
            {errors.map((e, i) => (
              <li key={i} className="rounded-xl bg-red-500/10 px-3 py-1.5 font-mono text-[10.5px] text-red-500">{e}</li>
            ))}
          </ul>
          <pre id="env-btn" className="mt-3 overflow-x-auto rounded-2xl bg-ink/[0.05] p-3 font-mono text-[10px] leading-relaxed text-ink-soft">
{`# .env.example — no real secrets, ever
ADMINOS_PORT=5173
ADMINOS_DB_URL=postgres://user:pass@host:5432/adminos  # set in production
ADMINOS_SESSION_TTL=${settings["session.timeout"]}
ADMINOS_BACKUP_CRON=0 3 * * *
# SMTP/SMS/payment providers: configure server-side only`}
          </pre>
        </Card>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════ AUDIT ════════════════════════════════ */

export function AuditPanel() {
  const { db, flags, create, toast, exportCsv, update, report } = useAdminOS();

  return (
    <div className="space-y-5">
      <Card
        title="Central audit log"
        action={
          <div className="flex gap-2">
            <Btn size="sm" tone="ghost" onClick={() => exportCsv("audit")}><Download className="size-3.5" /> Export</Btn>
            <Btn size="sm" tone="ghost" onClick={() => toast(report("security-scan").detail)}><ShieldAlert className="size-3.5" /> Security scan</Btn>
            <span className="self-center rounded-full bg-emerald-500/15 px-2.5 py-1 text-[10.5px] font-bold text-emerald-600">
              {flags["audit.immutable"] ? "immutable" : "mutable"}
            </span>
          </div>
        }
      >
        <DataTable
          type="audit" title="audit" rows={db.audit ?? []}
          columns={[
            { key: "at", label: "When", render: (v) => new Date(String(v)).toLocaleString() },
            { key: "actor", label: "Actor" },
            { key: "action", label: "Action" },
            { key: "resource", label: "Resource" },
          ]}
          searchKeys={["actor", "action", "resource"]}
          pageSize={8}
          rowActions={() => (
            <Btn size="sm" tone="ghost" onClick={() => {
              if (flags["audit.immutable"]) { toast("Protected: audit records cannot be edited or deleted.", "warn"); return; }
              toast("Audit edit attempted — enable Protected Audit Records to block this.", "warn");
            }}>Try edit</Btn>
          )}
        />
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="Privacy requests" action={<Btn size="sm" tone="primary" onClick={() => create("privacyRequests")}><Plus className="size-3.5" /> New request</Btn>}>
          <DataTable
            type="privacyRequests" title="privacy" rows={db.privacyRequests ?? []}
            columns={[
              { key: "kind", label: "Kind" }, { key: "subject", label: "Subject" },
              { key: "status", label: "Status", render: (v) => <StatusPill value={v} /> },
            ]}
            searchKeys={["kind", "subject", "status"]}
            pageSize={5}
            rowActions={(row) => (
              <>
                <Btn size="sm" tone="ghost" onClick={() => { exportCsv("userData"); update("privacyRequests", String(row.id), { status: "Approved" }); toast("Identity verified · personal-data export delivered."); }}>Approve export</Btn>
                <Btn size="sm" tone="danger" onClick={() => { update("privacyRequests", String(row.id), { status: "Approved", deletion: "scheduled-after-retention" }); toast("Deletion approved — executes after retention obligation."); }}>Approve deletion</Btn>
              </>
            )}
          />
        </Card>
        <Card title="Compliance & consent" action={<Btn size="sm" tone="primary" onClick={() => create("complianceTasks")}><Plus className="size-3.5" /> Task</Btn>}>
          <DataTable
            type="complianceTasks" title="compliance" rows={db.complianceTasks ?? []}
            columns={[
              { key: "title", label: "Obligation" }, { key: "owner", label: "Owner" },
              { key: "status", label: "Status", render: (v) => <StatusPill value={v} /> },
              { key: "due", label: "Due" },
            ]}
            searchKeys={["title", "owner", "status"]}
            pageSize={5}
            rowActions={(row) => (
              <Btn size="sm" tone="ghost" onClick={() => { update("complianceTasks", String(row.id), { status: "Done" }); create("evidence", { name: `Evidence for ${row.title}`, incident: "inc-001", type: "document" }); toast("Marked done + evidence attached."); }}>Done + evidence</Btn>
            )}
          />
          <div className="mt-3 flex gap-2">
            <Btn size="sm" tone="ghost" onClick={() => { create("consents", { subject: "New subject", purpose: "analytics", granted: true }); toast("Consent recorded with history entry."); }}>Record consent</Btn>
            <Btn size="sm" tone="ghost" onClick={() => { create("classifications", { name: "Confidential", scope: "documents" }); }}>Classify data</Btn>
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ════════════════════════════════ COLLABORATION ═══════════════════════════ */

export function CollabPanel() {
  const { db, create, update, toast } = useAdminOS();
  const [view, setView] = useState<"list" | "board" | "calendar">("list");
  const tasks = db.tasks ?? [];

  return (
    <div className="space-y-5">
      <Card
        title="Administrative task board"
        action={
          <div className="flex gap-2">
            {(["list", "board", "calendar"] as const).map((v) => (
              <Btn key={v} size="sm" tone={view === v ? "accent" : "ghost"} onClick={() => setView(v)}>{v}</Btn>
            ))}
            <Btn size="sm" tone="primary" onClick={() => create("tasks")}><Plus className="size-3.5" /> Task</Btn>
          </div>
        }
      >
        {view === "list" && (
          <DataTable
            type="tasks" title="tasks" rows={tasks}
            columns={[
              { key: "title", label: "Task" }, { key: "assignee", label: "Assignee" },
              { key: "priority", label: "Priority" }, { key: "status", label: "Status", render: (v) => <StatusPill value={v} /> },
              { key: "due", label: "Due", render: (v) => new Date(String(v)).toLocaleDateString() },
            ]}
            searchKeys={["title", "assignee"]}
            rowActions={(row) => (
              <Btn size="sm" tone="ghost" onClick={() => { update("tasks", String(row.id), { status: "Done" }); toast("Task completed."); }}>Done</Btn>
            )}
          />
        )}
        {view === "board" && (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {["Open", "In progress", "Blocked", "Done"].map((col) => (
              <div key={col} className="rounded-2xl bg-ink/[0.03] p-3">
                <p className="mb-2 text-[11px] font-bold uppercase tracking-wider text-ink-faint">{col}</p>
                {tasks.filter((t) => t.status === col).map((t) => (
                  <div key={String(t.id)} className="mb-2 rounded-2xl border border-line bg-bone px-3 py-2 text-[12px]">
                    <p className="font-semibold text-ink">{String(t.title)}</p>
                    <p className="text-[10.5px] text-ink-faint">{String(t.assignee)} · {String(t.priority)}</p>
                  </div>
                ))}
              </div>
            ))}
          </div>
        )}
        {view === "calendar" && (
          <div className="grid grid-cols-7 gap-1.5">
            {Array.from({ length: 28 }, (_, i) => {
              const day = new Date(Date.now() + (i - 10) * 864e5);
              const items = tasks.filter((t) => new Date(String(t.due)).toDateString() === day.toDateString());
              return (
                <div key={i} className={cn("min-h-14 rounded-xl border p-1.5", items.length ? "border-accent bg-accent/5" : "border-line")}>
                  <p className="text-[9.5px] font-semibold text-ink-faint">{day.getDate()}</p>
                  {items.map((t) => <p key={String(t.id)} className="truncate text-[9px] font-semibold text-accent">{String(t.title)}</p>)}
                </div>
              );
            })}
          </div>
        )}
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="Workspaces & onboarding" action={<Btn size="sm" tone="primary" onClick={() => create("workspaces")}><Plus className="size-3.5" /> Workspace</Btn>}>
          <ul className="space-y-1.5">
            {(db.workspaces ?? [{ id: "ws-1", name: "Platform", members: 6 }, { id: "ws-2", name: "Revenue", members: 9 }]).map((w) => (
              <li key={String(w.id)} className="flex items-center justify-between rounded-2xl border border-line px-3.5 py-2 text-[12.5px]">
                <span className="font-semibold text-ink">{String(w.name)}</span>
                <span className="text-ink-faint">{String(w.members)} members</span>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-[11px] font-semibold text-ink-soft">Onboarding checklist</p>
          <ul className="mt-1 space-y-1">
            {(db.onboarding ?? []).map((o) => (
              <li key={String(o.id)} className="flex items-center gap-2 text-[12px] text-ink">
                <input
                  type="checkbox" checked={Number(o.done) === 1}
                  onChange={() => { update("onboarding", String(o.id), { done: Number(o.done) === 1 ? 0 : 1 }); }}
                  className="size-3.5 accent-[var(--color-accent)]"
                />
                {String(o.step)}
              </li>
            ))}
          </ul>
        </Card>
        <Card title="Announcements, comments & attachments" action={
          <div className="flex gap-2">
            <Btn size="sm" tone="ghost" onClick={() => create("comments", { body: "Discussed in standup — proceeding.", author: "admin" })}>Comment</Btn>
            <Btn size="sm" tone="ghost" onClick={() => create("attachments", { name: `doc-${Date.now() % 100}.pdf`, size: 42000 })}>Attach</Btn>
            <Btn size="sm" tone="primary" onClick={() => create("announcements", { title: "New announcement", status: "Active" })}>Announce</Btn>
          </div>
        }>
          <ul className="space-y-1.5">
            {(db.announcements ?? []).map((a) => (
              <li key={String(a.id)} className="rounded-2xl border border-line px-3.5 py-2 text-[12.5px]">
                <span className="font-semibold text-ink">📣 {String(a.title)}</span> <StatusPill value={a.status} />
              </li>
            ))}
            {(db.comments ?? []).slice(0, 3).map((c) => (
              <li key={String(c.id)} className="rounded-2xl bg-ink/[0.03] px-3.5 py-2 text-[12px] text-ink-soft">
                💬 {String(c.body)} <span className="text-ink-faint">— {String(c.author)}</span>
              </li>
            ))}
            {(db.attachments ?? []).slice(0, 2).map((a) => (
              <li key={String(a.id)} className="rounded-2xl border border-line px-3.5 py-2 text-[12px]">
                📎 {String(a.name)} <span className="text-ink-faint">({(Number(a.size) / 1024).toFixed(0)} KB)</span>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════ HELP ═════════════════════════════════ */

export function HelpPanel() {
  const { db, create, update, toast, settings } = useAdminOS();

  return (
    <div className="space-y-5">
      <Card title="Support tickets" action={
        <div className="flex gap-2">
          <Btn size="sm" tone="ghost" onClick={() => toast(`SLA: first response within ${settings["sla.responseHours"]}h · resolution targets by priority.`)}>SLA config</Btn>
          <Btn size="sm" tone="primary" onClick={() => create("tickets", { title: "New ticket", priority: "Medium", status: "Open", owner: "usr-006" })}><Plus className="size-3.5" /> Ticket</Btn>
        </div>
      }>
        <DataTable
          type="tickets" title="tickets" rows={db.tickets ?? []}
          columns={[
            { key: "title", label: "Ticket" }, { key: "priority", label: "Priority" },
            { key: "status", label: "Status", render: (v) => <StatusPill value={v} /> },
            { key: "owner", label: "Owner" },
            { key: "opened", label: "Opened", render: (v) => new Date(String(v)).toLocaleDateString() },
          ]}
          searchKeys={["title", "status", "owner"]}
          rowActions={(row) => (
            <>
              <Btn size="sm" tone="ghost" onClick={() => { update("tickets", String(row.id), { status: "Resolved" }); toast(`${row.id} resolved.`); }}>Resolve</Btn>
              <Btn size="sm" tone="danger" onClick={() => { update("tickets", String(row.id), { status: "Escalated", priority: "Critical" }); toast(`${row.id} escalated per SLA rule.`); }}>Escalate</Btn>
            </>
          )}
        />
      </Card>

      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="Knowledge base & FAQ" action={
          <div className="flex gap-2">
            <Btn size="sm" tone="ghost" onClick={() => create("kb", { title: "New article", category: "General", status: "Draft" })}>Article</Btn>
            <Btn size="sm" tone="primary" onClick={() => create("faq", { q: "New question?", a: "Answer.", category: "General", status: "Draft" })}>FAQ</Btn>
          </div>
        }>
          <ul className="space-y-1.5">
            {(db.kb ?? []).map((a) => (
              <li key={String(a.id)} className="rounded-2xl border border-line px-3.5 py-2 text-[12.5px]">
                <span className="font-semibold text-ink">📘 {String(a.title)}</span>
                <span className="text-ink-faint"> · {String(a.category)} · {String(a.views)} views</span>
                <button className="ml-2 text-[11px] text-accent underline" onClick={() => { update("kb", String(a.id), { status: "Published" }); toast("Article published."); }}>publish</button>
              </li>
            ))}
            {(db.faq ?? []).map((q) => (
              <li key={String(q.id)} className="rounded-2xl bg-ink/[0.03] px-3.5 py-2 text-[12px]">
                <p className="font-semibold text-ink">Q: {String(q.q)}</p>
                <p className="text-ink-soft">A: {String(q.a)}</p>
              </li>
            ))}
          </ul>
        </Card>
        <Card title="Feedback" action={<Btn size="sm" tone="primary" onClick={() => create("feedback", { title: "Portal feedback", body: "Submitted from help center.", status: "New", score: 5 })}><Plus className="size-3.5" /> Collect</Btn>}>
          <ul className="space-y-1.5">
            {(db.feedback ?? []).map((fb) => (
              <li key={String(fb.id)} className="rounded-2xl border border-line px-3.5 py-2 text-[12.5px]">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-ink">{String(fb.title)}</span>
                  <span className="text-amber-500">{"★".repeat(Number(fb.score ?? 0))}</span>
                </div>
                <p className="text-ink-faint">{String(fb.body)}</p>
                <button className="mt-1 text-[11px] text-accent underline" onClick={() => { update("feedback", String(fb.id), { status: "Actioned" }); toast("Feedback marked actioned."); }}>mark actioned</button>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  );
}

/* ═════════════════════════════════ SETTINGS ═══════════════════════════════ */

export function SettingsPanelAdmin({ navigate }: { navigate: (p: string) => void }) {
  const os = useAdminOS();
  const { flags, settings, toast } = os;

  const toggleFlag = (key: string) => {
    const fn = {
      n: 0, slug: key, title: key, module: "M" as const, page: "settings" as PageId,
      desc: "", perm: "settings.manage", impl: "simulated" as const,
      op: { k: "flag" as const, key }, db: "", validation: "", errors: "",
    };
    os.execute(fn);
  };

  return (
    <div className="space-y-5">
      <div className="grid gap-5 lg:grid-cols-2">
        <Card title="General, branding & localization">
          <div className="space-y-3">
            <div className="flex items-center justify-between rounded-2xl border border-line px-4 py-3">
              <div>
                <p className="text-[12.5px] font-bold text-ink">Organization & locale</p>
                <p className="text-[11px] text-ink-faint">{os.localeLabel} · currency {os.currency} · range {os.rangeLabel}</p>
              </div>
              <Btn size="sm" tone="ghost" onClick={() => os.execute({ n: 204, slug: "localization", title: "Localization Settings", module: "M", page: "settings", desc: "", perm: "settings.manage", impl: "simulated", op: { k: "set", key: "locale.index", delta: 1 }, db: "", validation: "", errors: "" })}>Cycle locale</Btn>
            </div>
            <div className="flex items-center justify-between rounded-2xl border border-line px-4 py-3">
              <div>
                <p className="text-[12.5px] font-bold text-ink">Brand accent</p>
                <p className="text-[11px] text-ink-faint">Variation {(settings["brand.accent"] ?? 0) + 1} of 4</p>
              </div>
              <Btn size="sm" tone="ghost" onClick={() => os.execute({ n: 202, slug: "branding", title: "Branding Settings", module: "M", page: "settings", desc: "", perm: "settings.manage", impl: "simulated", op: { k: "set", key: "brand.accent", delta: 1 }, db: "", validation: "", errors: "" })}>Cycle accent</Btn>
            </div>
            <div className="rounded-2xl border border-line px-4 py-3">
              <p className="text-[12.5px] font-bold text-ink">Finance & policy</p>
              <p className="mt-1 text-[11px] text-ink-faint">
                Tax {settings["finance.taxRate"]}% · retention {settings["retention.days"]}d · SLA response {settings["sla.responseHours"]}h · password min {settings["policy.minLength"]}
              </p>
            </div>
          </div>
        </Card>

        <Card title="Feature flags & modules">
          <ul className="space-y-1.5">
            {Object.entries(flags).map(([key, val]) => (
              <li key={key} className="flex items-center justify-between rounded-2xl border border-line px-3.5 py-2">
                <span className="font-mono text-[11px] text-ink">{key}</span>
                <button
                  role="switch" aria-checked={val} onClick={() => toggleFlag(key)}
                  className={cn("relative h-5 w-9 rounded-full transition-colors", val ? "bg-accent" : "bg-ink/15")}
                >
                  <span className="absolute top-0.5 size-4 rounded-full bg-white shadow-sm transition-all" style={{ left: val ? 18 : 2 }} />
                </button>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <Card title="Notification preferences & links">
        <div className="flex flex-wrap gap-2">
          <Btn tone="ghost" onClick={() => toast("Preference saved: in-app + email for approvals, SMS for SLA breaches.")}>Save notification prefs</Btn>
          <Btn tone="ghost" onClick={() => navigate("matrix")}>Requirements matrix</Btn>
          <Btn tone="ghost" onClick={() => navigate("catalog")}>Function catalog</Btn>
          <Btn tone="ghost" onClick={() => navigate("blueprint")}>Blueprint</Btn>
        </div>
      </Card>
    </div>
  );
}
