import { useMemo, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowDown, ArrowUp, ChevronLeft, ChevronRight, Download, Plus, Search, X } from "lucide-react";
import { useAdminOS } from "../../context/AdminOS";
import type { Row } from "../../data/adminos-seed";
import { cn } from "../../utils/cn";

const spring = { type: "spring", stiffness: 380, damping: 34, mass: 0.85 } as const;

export function Card({ title, action, children, className }: { title?: ReactNode; action?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={cn("rounded-3xl border border-line bg-bone", className)}>
      {(title || action) && (
        <header className="flex items-center justify-between gap-3 border-b border-line px-5 py-3.5">
          <h3 className="text-[14px] font-bold text-ink">{title}</h3>
          {action}
        </header>
      )}
      <div className="p-5">{children}</div>
    </section>
  );
}

export function Stat({ label, value, hint, tone = "ink" }: { label: string; value: ReactNode; hint?: string; tone?: "ink" | "accent" | "green" | "amber" | "red" }) {
  const tones = { ink: "text-ink", accent: "text-accent", green: "text-emerald-600", amber: "text-amber-600", red: "text-red-500" };
  return (
    <div className="rounded-3xl border border-line bg-bone px-4 py-3.5">
      <p className="eyebrow text-ink-faint">{label}</p>
      <p className={cn("mt-1 text-[22px] font-bold leading-none", tones[tone])}>{value}</p>
      {hint && <p className="mt-1 text-[11px] text-ink-faint">{hint}</p>}
    </div>
  );
}

export function Btn({ children, onClick, tone = "default", size = "md", disabled, title }: {
  children: ReactNode; onClick?: () => void; tone?: "default" | "primary" | "danger" | "ghost" | "accent";
  size?: "sm" | "md"; disabled?: boolean; title?: string;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      title={title}
      className={cn(
        "inline-flex items-center justify-center gap-1.5 rounded-2xl font-bold transition-colors disabled:opacity-50",
        size === "sm" ? "px-2.5 py-1.5 text-[11.5px]" : "px-3.5 py-2.5 text-[12.5px]",
        tone === "primary" && "bg-ink text-bone hover:bg-accent hover:text-white",
        tone === "accent" && "bg-accent text-white hover:bg-accent-deep",
        tone === "danger" && "border border-red-200 text-red-500 hover:bg-red-500/10",
        tone === "ghost" && "border border-line text-ink-soft hover:border-ink hover:text-ink",
        tone === "default" && "border border-line text-ink hover:bg-ink/[0.05]",
      )}
    >
      {children}
    </button>
  );
}

export function Dialog({ open, onClose, title, children, wide }: { open: boolean; onClose: () => void; title: string; children: ReactNode; wide?: boolean }) {
  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.button
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={onClose} aria-hidden="true" tabIndex={-1}
            className="fixed inset-0 z-[120] bg-ink/50 backdrop-blur-sm"
          />
          <motion.div
            role="dialog" aria-modal="true" aria-label={title}
            initial={{ opacity: 0, y: 20, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 12, scale: 0.97 }}
            transition={spring}
            className={cn("fixed left-1/2 top-1/2 z-[121] max-h-[85vh] w-[92vw] -translate-x-1/2 -translate-y-1/2 overflow-y-auto rounded-3xl border border-line bg-bone p-6 shadow-2xl", wide ? "max-w-3xl" : "max-w-lg")}
          >
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-[17px] font-bold text-ink">{title}</h2>
              <button onClick={onClose} aria-label="Close dialog" className="grid size-8 place-items-center rounded-full hover:bg-ink/5">
                <X className="size-4" aria-hidden="true" />
              </button>
            </div>
            {children}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

export interface Column<T extends Row> {
  key: string;
  label: string;
  sortable?: boolean;
  render?: (value: unknown, row: T) => ReactNode;
}

export function DataTable<T extends Row>({
  type, rows, columns, searchKeys, onCreate, createLabel, extraActions, rowActions, pageSize = 8, title,
}: {
  type: string;
  rows: T[];
  columns: Column<T>[];
  searchKeys: string[];
  onCreate?: () => void;
  createLabel?: string;
  extraActions?: ReactNode;
  rowActions?: (row: T) => ReactNode;
  pageSize?: number;
  title?: string;
}) {
  const { exportCsv, bulkPatch, toast, update } = useAdminOS();
  const [q, setQ] = useState("");
  const [status, setStatusFilter] = useState("all");
  const [sortKey, setSortKey] = useState<string | null>(null);
  const [sortDir, setSortDir] = useState<1 | -1>(1);
  const [page, setPage] = useState(0);
  const [selected, setSelected] = useState<string[]>([]);
  const [detail, setDetail] = useState<T | null>(null);

  const statuses = useMemo(() => {
    const set = new Set<string>();
    rows.forEach((r) => { if (r.status) set.add(String(r.status)); });
    return [...set].sort();
  }, [rows]);

  const filtered = useMemo(() => {
    let out = rows;
    if (status !== "all") out = out.filter((r) => String(r.status) === status);
    const needle = q.trim().toLowerCase();
    if (needle) {
      out = out.filter((r) => searchKeys.some((k) => String(r[k] ?? "").toLowerCase().includes(needle)));
    }
    if (sortKey) {
      out = [...out].sort((a, b) => {
        const av = a[sortKey]; const bv = b[sortKey];
        const an = Number(av); const bn = Number(bv);
        if (!Number.isNaN(an) && !Number.isNaN(bn)) return (an - bn) * sortDir;
        return String(av ?? "").localeCompare(String(bv ?? "")) * sortDir;
      });
    }
    return out;
  }, [rows, q, status, sortKey, sortDir, searchKeys]);

  const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const view = filtered.slice(page * pageSize, page * pageSize + pageSize);
  const allChecked = view.length > 0 && view.every((r) => selected.includes(String(r.id)));

  return (
    <div>
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative min-w-[180px] flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-[15px] -translate-y-1/2 text-ink-faint" aria-hidden="true" />
          <input
            value={q} onChange={(e) => { setQ(e.target.value); setPage(0); }}
            placeholder={`Search ${title ?? type}…`} aria-label={`Search ${title ?? type}`}
            className="w-full rounded-2xl border border-line bg-bone py-2 pl-9 pr-3 text-[12.5px] outline-none focus:ring-2 focus:ring-ink"
          />
        </div>
        {statuses.length > 0 && (
          <select
            value={status} onChange={(e) => { setStatusFilter(e.target.value); setPage(0); }}
            aria-label="Filter by status"
            className="rounded-2xl border border-line bg-bone px-3 py-2 text-[12px] font-semibold text-ink"
          >
            <option value="all">All statuses</option>
            {statuses.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        )}
        <Btn size="sm" tone="ghost" onClick={() => { const n = exportCsv(type); if (!n) return; }}>
          <Download className="size-3.5" aria-hidden="true" /> Export
        </Btn>
        {onCreate && (
          <Btn size="sm" tone="primary" onClick={onCreate}>
            <Plus className="size-3.5" aria-hidden="true" /> {createLabel ?? "Create"}
          </Btn>
        )}
        {extraActions}
      </div>

      {selected.length > 0 && (
        <div className="mt-3 flex flex-wrap items-center gap-2 rounded-2xl bg-ink/[0.04] px-3 py-2">
          <span className="text-[11.5px] font-semibold text-ink-soft">{selected.length} selected</span>
          <Btn size="sm" tone="ghost" onClick={() => { bulkPatch(type, selected, { status: "Active" }); setSelected([]); toast(`${selected.length} rows set Active.`); }}>Set Active</Btn>
          <Btn size="sm" tone="ghost" onClick={() => { bulkPatch(type, selected, { status: "Archived" }); setSelected([]); toast(`${selected.length} rows archived (recoverable).`); }}>Archive</Btn>
          <Btn size="sm" tone="danger" onClick={() => { if (window.confirm(`Permanently delete ${selected.length} rows? Retention rules apply.`)) { selected.forEach((id) => update(type, id, { deleted: "pending-purge" })); bulkPatch(type, selected, { status: "Deleted" }); setSelected([]); toast("Deletion recorded — purge honors retention."); } }}>
            Delete
          </Btn>
        </div>
      )}

      <div className="mt-3 overflow-x-auto rounded-2xl border border-line">
        <table className="w-full min-w-[560px] text-left">
          <thead>
            <tr className="border-b border-line bg-ink/[0.02]">
              <th className="px-3 py-2.5">
                <input
                  type="checkbox" checked={allChecked} aria-label="Select all rows"
                  onChange={(e) => setSelected(e.target.checked ? view.map((r) => String(r.id)) : [])}
                  className="size-3.5 accent-[var(--color-accent)]"
                />
              </th>
              {columns.map((c) => (
                <th key={c.key} className="px-3 py-2.5 text-[11px] font-semibold uppercase tracking-wider text-ink-faint">
                  {c.sortable === false ? c.label : (
                    <button
                      className="inline-flex items-center gap-1 hover:text-ink"
                      onClick={() => {
                        if (sortKey === c.key) setSortDir((d) => (d === 1 ? -1 : 1));
                        else { setSortKey(c.key); setSortDir(1); }
                      }}
                    >
                      {c.label}
                      {sortKey === c.key && (sortDir === 1 ? <ArrowUp className="size-3" /> : <ArrowDown className="size-3" />)}
                    </button>
                  )}
                </th>
              ))}
              {rowActions && <th className="px-3 py-2.5 text-[11px] font-semibold uppercase tracking-wider text-ink-faint">Actions</th>}
            </tr>
          </thead>
          <tbody>
            {view.map((row) => (
              <tr key={String(row.id)} className="border-b border-line last:border-b-0 hover:bg-ink/[0.02]">
                <td className="px-3 py-2.5">
                  <input
                    type="checkbox" checked={selected.includes(String(row.id))} aria-label={`Select ${row.id}`}
                    onChange={(e) => setSelected((s) => e.target.checked ? [...s, String(row.id)] : s.filter((x) => x !== String(row.id)))}
                    className="size-3.5 accent-[var(--color-accent)]"
                  />
                </td>
                {columns.map((c) => (
                  <td key={c.key} className="max-w-[220px] truncate px-3 py-2.5 text-[12.5px] text-ink">
                    {c.render ? c.render(row[c.key], row) : String(row[c.key] ?? "—")}
                  </td>
                ))}
                {rowActions && <td className="px-3 py-2.5"><div className="flex items-center gap-1.5">{rowActions(row)}</div></td>}
              </tr>
            ))}
            {view.length === 0 && (
              <tr>
                <td colSpan={columns.length + 2} className="px-4 py-10 text-center">
                  <p className="text-[13px] font-semibold text-ink">No results</p>
                  <p className="mt-1 text-[12px] text-ink-faint">Adjust the search or filter — or create the first record.</p>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="mt-3 flex items-center justify-between">
        <p className="text-[11.5px] text-ink-faint">
          {filtered.length} row{filtered.length === 1 ? "" : "s"} · page {Math.min(page + 1, pages)}/{pages}
        </p>
        <div className="flex items-center gap-1.5">
          <Btn size="sm" tone="ghost" disabled={page === 0} onClick={() => setPage((p) => Math.max(0, p - 1))}>
            <ChevronLeft className="size-3.5" aria-hidden="true" />
          </Btn>
          <Btn size="sm" tone="ghost" disabled={page >= pages - 1} onClick={() => setPage((p) => Math.min(pages - 1, p + 1))}>
            <ChevronRight className="size-3.5" aria-hidden="true" />
          </Btn>
        </div>
      </div>

      <Dialog open={!!detail} onClose={() => setDetail(null)} title={`Record detail · ${String(detail?.id ?? "")}`}>
        {detail && (
          <dl className="space-y-1.5">
            {Object.entries(detail).map(([k, v]) => (
              <div key={k} className="flex gap-3 rounded-xl bg-ink/[0.03] px-3 py-2">
                <dt className="w-28 shrink-0 text-[11px] font-semibold uppercase tracking-wider text-ink-faint">{k}</dt>
                <dd className="min-w-0 flex-1 break-words text-[12.5px] text-ink">{typeof v === "object" ? JSON.stringify(v) : String(v)}</dd>
              </div>
            ))}
            <div className="pt-2">
              <Btn size="sm" tone="ghost" onClick={() => { if (detail) setDetail({ ...detail } as T); toast("Detail view re-rendered from live store."); }}>
                Refresh from store
              </Btn>
            </div>
          </dl>
        )}
      </Dialog>

      {/* detail dialog above */}
    </div>
  );
}

export function StatusPill({ value }: { value: unknown }) {
  const s = String(value ?? "");
  const tone =
    /active|published|paid|settled|connected|approved|done|completed|verified|trusted|generated/i.test(s) ? "bg-emerald-500/15 text-emerald-600" :
    /pending|review|issued|scheduled|running|expiring|degraded|new|draft|progress|escalated/i.test(s) ? "bg-amber-500/15 text-amber-600" :
    /reject|fail|suspended|inactive|blocked|overdue|cancel|archived|revoked|closed/i.test(s) ? "bg-red-500/15 text-red-500" :
    "bg-ink/[0.06] text-ink-soft";
  return <span className={cn("rounded-full px-2 py-0.5 text-[10.5px] font-bold", tone)}>{s || "—"}</span>;
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-[11px] font-semibold uppercase tracking-[0.1em] text-ink-faint">{label}</span>
      {children}
    </label>
  );
}

export const inputCls = "w-full rounded-2xl border border-line bg-bone px-3.5 py-2.5 text-[13px] outline-none focus:ring-2 focus:ring-ink";
