import { useEffect, useMemo } from "react";
import * as THREE from "three";
import "@react-three/fiber";
import type { Finish } from "../../data/products";
import { makeScreenTexture } from "../../three/screenTexture";

/* ------------------------------------------------------------------ */
/*  Geometry helpers                                                   */
/* ------------------------------------------------------------------ */

function roundedRectShape(w: number, h: number, r: number) {
  const s = new THREE.Shape();
  const x = -w / 2;
  const y = -h / 2;
  s.moveTo(x + r, y);
  s.lineTo(x + w - r, y);
  s.absarc(x + w - r, y + r, r, -Math.PI / 2, 0, false);
  s.lineTo(x + w, y + h - r);
  s.absarc(x + w - r, y + h - r, r, 0, Math.PI / 2, false);
  s.lineTo(x + r, y + h);
  s.absarc(x + r, y + h - r, r, Math.PI / 2, Math.PI, false);
  s.lineTo(x, y + r);
  s.absarc(x + r, y + r, r, Math.PI, Math.PI * 1.5, false);
  return s;
}

function makePlate(w: number, h: number, r: number, depth: number, bevel = 0.012, hole?: { w: number; h: number; r: number }) {
  const shape = roundedRectShape(w, h, r);
  if (hole) {
    const path = new THREE.Path();
    const hw = hole.w;
    const hh = hole.h;
    const hr = hole.r;
    const x = -hw / 2;
    const y = -hh / 2;
    path.moveTo(x + hr, y);
    path.lineTo(x + hw - hr, y);
    path.absarc(x + hw - hr, y + hr, hr, -Math.PI / 2, 0, false);
    path.lineTo(x + hw, y + hh - hr);
    path.absarc(x + hw - hr, y + hh - hr, hr, 0, Math.PI / 2, false);
    path.lineTo(x + hr, y + hh);
    path.absarc(x + hr, y + hh - hr, hr, Math.PI / 2, Math.PI, false);
    path.lineTo(x, y + hr);
    path.absarc(x + hr, y + hr, hr, Math.PI, Math.PI * 1.5, false);
    shape.holes.push(path);
  }
  const geo = new THREE.ExtrudeGeometry(shape, {
    depth,
    bevelEnabled: bevel > 0,
    bevelThickness: bevel,
    bevelSize: bevel,
    bevelSegments: 3,
    curveSegments: 28,
  });
  geo.center();
  return geo;
}

/* Phone proportions — 6.9″ class device */
const W = 1.62;
const H = 3.42;
const D = 0.17;
const R = 0.26;

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */

export function IPhone({ finish }: { finish: Finish }) {
  const geos = useMemo(
    () => ({
      frame: makePlate(W, H, R, D, 0.014, { w: W - 0.1, h: H - 0.11, r: R - 0.05 }),
      screen: makePlate(W - 0.052, H - 0.062, R - 0.034, 0.005, 0.002),
      back: makePlate(W - 0.048, H - 0.058, R - 0.033, 0.007, 0.003),
      plateau: makePlate(W, 1.26, 0.24, 0.045, 0.008),
      island: makePlate(0.31, 0.088, 0.044, 0.004, 0.002),
    }),
    [],
  );

  useEffect(() => {
    return () => {
      Object.values(geos).forEach((g) => g.dispose());
    };
  }, [geos]);

  const screenTex = useMemo(() => {
    const tex = makeScreenTexture();
    // ExtrudeGeometry emits world-space UVs — normalize them so the home
    // screen maps 1:1 across the entire display plate edge to edge.
    tex.repeat.set(1 / (W - 0.052), 1 / (H - 0.062));
    tex.offset.set(0.5, 0.5);
    return tex;
  }, []);
  useEffect(() => () => screenTex.dispose(), [screenTex]);

  const mats = useMemo(
    () => ({
      frame: new THREE.MeshStandardMaterial({
        color: finish.frame,
        metalness: 0.96,
        roughness: 0.34,
        envMapIntensity: 1.25,
      }),
      back: new THREE.MeshPhysicalMaterial({
        color: finish.back,
        metalness: 0.18,
        roughness: 0.42,
        clearcoat: 0.55,
        clearcoatRoughness: 0.32,
        envMapIntensity: 0.9,
      }),
      plateau: new THREE.MeshStandardMaterial({
        color: finish.plateau,
        metalness: 0.9,
        roughness: 0.38,
        envMapIntensity: 1.1,
      }),
      screen: new THREE.MeshPhysicalMaterial({
        color: "#0b0b0e",
        roughness: 0.18,
        metalness: 0.1,
        clearcoat: 1,
        clearcoatRoughness: 0.06,
        emissive: new THREE.Color("#ffffff"),
        emissiveMap: screenTex,
        emissiveIntensity: 0.92,
        map: screenTex,
        envMapIntensity: 0.7,
      }),
      darkMetal: new THREE.MeshStandardMaterial({ color: "#0b0b0e", metalness: 0.7, roughness: 0.35 }),
      lensRing: new THREE.MeshStandardMaterial({
        color: new THREE.Color(finish.plateau).multiplyScalar(0.75),
        metalness: 1,
        roughness: 0.24,
        envMapIntensity: 1.35,
      }),
      lensGlass: new THREE.MeshPhysicalMaterial({
        color: "#0a0d16",
        metalness: 0.2,
        roughness: 0.06,
        clearcoat: 1,
        clearcoatRoughness: 0.04,
        envMapIntensity: 1.6,
      }),
      flash: new THREE.MeshStandardMaterial({
        color: "#f3ead0",
        emissive: "#ffedb8",
        emissiveIntensity: 0.9,
        roughness: 0.5,
      }),
    }),
    [finish, screenTex],
  );

  useEffect(() => {
    return () => {
      Object.values(mats).forEach((m) => m.dispose());
    };
  }, [mats]);

  // iPhone 17 Pro camera plateau — full-width raised bar across the top
  const pcy = H / 2 - 0.63;
  const pz = -D / 2 - 0.02;

  const lensRingGeo = useMemo(() => new THREE.CylinderGeometry(0.152, 0.158, 0.06, 48), []);
  const lensGlassGeo = useMemo(() => new THREE.CylinderGeometry(0.112, 0.112, 0.068, 48), []);
  const lensPupilGeo = useMemo(() => new THREE.CylinderGeometry(0.07, 0.07, 0.072, 32), []);

  // Lens triangle on the left half of the plateau
  const cx = -0.3;
  const cy = 1.145;
  const lensPositions: [number, number][] = [
    [cx - 0.15, cy + 0.21],
    [cx - 0.15, cy - 0.21],
    [cx + 0.17, cy],
  ];

  return (
    <group>
      {/* Unibody frame */}
      <mesh geometry={geos.frame} material={mats.frame} />

      {/* Inner core — blocks see-through at glancing angles */}
      <mesh material={mats.darkMetal}>
        <boxGeometry args={[W - 0.07, H - 0.08, D * 0.62]} />
      </mesh>

      {/* Front OLED display */}
      <mesh geometry={geos.screen} material={mats.screen} position={[0, 0, D / 2 + 0.005]} />

      {/* Back glass */}
      <mesh geometry={geos.back} material={mats.back} position={[0, 0, -D / 2 - 0.004]} />

      {/* Camera plateau — full-width bar (iPhone 17 Pro) */}
      <mesh geometry={geos.plateau} material={mats.plateau} position={[0, pcy, pz]} />

      {/* Lenses */}
      {lensPositions.map(([x, y], i) => (
        <group key={i} position={[x, y, 0]}>
          <mesh geometry={lensRingGeo} material={mats.lensRing} position={[0, 0, pz - 0.045]} rotation={[-Math.PI / 2, 0, 0]} />
          <mesh geometry={lensGlassGeo} material={mats.lensGlass} position={[0, 0, pz - 0.05]} rotation={[-Math.PI / 2, 0, 0]} />
          <mesh geometry={lensPupilGeo} material={mats.darkMetal} position={[0, 0, pz - 0.055]} rotation={[-Math.PI / 2, 0, 0]} />
        </group>
      ))}

      {/* Flash (top-right) + LiDAR (below) + rear mic on the plateau */}
      <mesh position={[0.45, 1.355, pz - 0.026]} rotation={[-Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.06, 0.06, 0.02, 24]} />
        <primitive object={mats.flash} attach="material" />
      </mesh>
      <mesh position={[0.45, 0.85, pz - 0.026]} rotation={[-Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.068, 0.068, 0.02, 24]} />
        <primitive object={mats.darkMetal} attach="material" />
      </mesh>
      <mesh position={[0.17, 0.92, pz - 0.026]} rotation={[-Math.PI / 2, 0, 0]}>
        <cylinderGeometry args={[0.016, 0.016, 0.02, 12]} />
        <primitive object={mats.darkMetal} attach="material" />
      </mesh>

      {/* Dynamic Island */}
      <mesh geometry={geos.island} material={mats.darkMetal} position={[0, H / 2 - 0.2, D / 2 + 0.007]} />

      {/* Side buttons — left rail */}
      <mesh material={mats.frame} position={[-W / 2 - 0.008, H / 2 - 0.58, 0]}>
        <boxGeometry args={[0.024, 0.08, 0.05]} />
      </mesh>
      <mesh material={mats.frame} position={[-W / 2 - 0.009, H / 2 - 0.84, 0]}>
        <boxGeometry args={[0.024, 0.135, 0.05]} />
      </mesh>
      <mesh material={mats.frame} position={[-W / 2 - 0.009, H / 2 - 1.12, 0]}>
        <boxGeometry args={[0.024, 0.135, 0.05]} />
      </mesh>

      {/* Right rail — power + capture */}
      <mesh material={mats.frame} position={[W / 2 + 0.009, H / 2 - 0.92, 0]}>
        <boxGeometry args={[0.024, 0.2, 0.05]} />
      </mesh>
      <mesh material={mats.darkMetal} position={[W / 2 + 0.006, H / 2 - 1.52, 0]}>
        <boxGeometry args={[0.014, 0.15, 0.035]} />
      </mesh>

      {/* Bottom — USB-C + speaker perforations */}
      <mesh material={mats.darkMetal} position={[0, -H / 2 - 0.003, 0]}>
        <boxGeometry args={[0.17, 0.045, D * 0.72]} />
      </mesh>
      {[-0.46, -0.39, -0.32, 0.32, 0.39, 0.46].map((x) => (
        <mesh key={x} material={mats.darkMetal} position={[x, -H / 2 - 0.004, 0.02]}>
          <cylinderGeometry args={[0.012, 0.012, 0.03, 12]} />
        </mesh>
      ))}
    </group>
  );
}
