import { forwardRef, useEffect, useImperativeHandle, useRef } from "react";
import * as THREE from "three";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { ContactShadows, Environment, Float, Lightformer, OrbitControls } from "@react-three/drei";
import type { OrbitControls as OrbitControlsImpl } from "three-stdlib";
import type { Finish } from "../../data/products";
import { IPhone } from "./IPhone";

export type StageView = "auto" | "free" | "front" | "rear" | "profile";

export interface StageHandle {
  zoomBy: (delta: number) => void;
}

interface StageProps {
  finish: Finish;
  view?: StageView;
  onUserInteract?: () => void;
  enableZoom?: boolean;
  autoRotate?: boolean;
  float?: boolean;
  shadowTone?: "light" | "dark";
  className?: string;
  label: string;
}

const PRESETS: Record<string, { pos: [number, number, number]; target: [number, number, number] }> = {
  front: { pos: [0, 0.12, 5.1], target: [0, 0.05, 0] },
  rear: { pos: [0.9, 0.85, -3.05], target: [-0.3, 0.78, 0] },
  profile: { pos: [4.9, -0.05, 0.5], target: [0, 0, 0] },
};

const easeInOutCubic = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

function CameraRig({
  view,
  controls,
}: {
  view: StageView;
  controls: React.RefObject<OrbitControlsImpl | null>;
}) {
  const camera = useThree((s) => s.camera);
  const anim = useRef<{
    fromP: THREE.Vector3;
    toP: THREE.Vector3;
    fromT: THREE.Vector3;
    toT: THREE.Vector3;
    t: number;
    active: boolean;
  } | null>(null);

  useEffect(() => {
    const preset = PRESETS[view];
    const c = controls.current;
    if (!preset || !c) {
      if (anim.current) anim.current.active = false;
      return;
    }
    anim.current = {
      fromP: camera.position.clone(),
      toP: new THREE.Vector3(...preset.pos),
      fromT: c.target.clone(),
      toT: new THREE.Vector3(...preset.target),
      t: 0,
      active: true,
    };
  }, [view, camera, controls]);

  useFrame((_, dt) => {
    const a = anim.current;
    const c = controls.current;
    if (!a?.active || !c) return;
    a.t = Math.min(1, a.t + dt / 1.05);
    const k = easeInOutCubic(a.t);
    camera.position.lerpVectors(a.fromP, a.toP, k);
    c.target.lerpVectors(a.fromT, a.toT, k);
    c.update();
    if (a.t >= 1) a.active = false;
  });

  return null;
}

function Lights() {
  return (
    <>
      <ambientLight intensity={0.32} />
      <directionalLight position={[4, 6, 6]} intensity={1.05} />
      <directionalLight position={[-5, 2, -4]} intensity={0.5} color="#ffd9b8" />
      <Environment resolution={256} frames={1}>
        <color attach="background" args={["#141419"]} />
        <Lightformer intensity={3} position={[0, 4, 7]} scale={[8, 5, 1]} color="#ffffff" />
        <Lightformer
          intensity={1.7}
          position={[-6, 1, 2]}
          rotation-y={Math.PI / 2}
          scale={[6, 1.4, 1]}
          color="#ffddbe"
        />
        <Lightformer
          intensity={2}
          position={[6, 0.6, 1.2]}
          rotation-y={-Math.PI / 2}
          scale={[6, 1.6, 1]}
          color="#d5e3ff"
        />
        <Lightformer
          intensity={0.9}
          position={[0, -5, 2]}
          rotation-x={Math.PI / 2}
          scale={[7, 2, 1]}
          color="#ffffff"
        />
      </Environment>
    </>
  );
}

export const Stage = forwardRef<StageHandle, StageProps>(function Stage(
  {
    finish,
    view = "auto",
    onUserInteract,
    enableZoom = true,
    autoRotate = true,
    float = false,
    shadowTone = "light",
    className,
    label,
  },
  ref,
) {
  const controlsRef = useRef<OrbitControlsImpl | null>(null);

  useImperativeHandle(ref, () => ({
    zoomBy(delta: number) {
      const c = controlsRef.current;
      if (!c) return;
      const cam = c.object;
      const dir = cam.position.clone().sub(c.target);
      const dist = dir.length();
      const next = THREE.MathUtils.clamp(dist + delta, 2.4, 8.4);
      dir.setLength(next);
      cam.position.copy(c.target.clone().add(dir));
      c.update();
    },
  }));

  const phone = <IPhone finish={finish} />;

  return (
    <div
      className={className}
      role="img"
      aria-label={label}
      onPointerDown={() => onUserInteract?.()}
      onWheel={() => onUserInteract?.()}
    >
      <Canvas
        dpr={[1, 2]}
        gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}
        camera={{ position: [0.7, 0.25, 5.7], fov: 33 }}
      >
        <Lights />
        <group position={[0, 0.05, 0]}>
          {float ? (
            <Float speed={1.6} rotationIntensity={0.28} floatIntensity={0.9} floatingRange={[-0.06, 0.08]}>
              {phone}
            </Float>
          ) : (
            phone
          )}
        </group>
        <ContactShadows
          position={[0, -2.15, 0]}
          opacity={shadowTone === "dark" ? 0.62 : 0.32}
          scale={11}
          blur={2.6}
          far={3.4}
          color={shadowTone === "dark" ? "#000000" : "#40342a"}
        />
        <OrbitControls
          ref={controlsRef}
          makeDefault
          enablePan={false}
          enableZoom={enableZoom}
          enableDamping
          dampingFactor={0.08}
          rotateSpeed={0.75}
          minDistance={2.4}
          maxDistance={8.4}
          minPolarAngle={Math.PI * 0.18}
          maxPolarAngle={Math.PI * 0.82}
          autoRotate={autoRotate && view === "auto"}
          autoRotateSpeed={0.85}
          onStart={() => onUserInteract?.()}
        />
        <CameraRig view={view} controls={controlsRef} />
      </Canvas>
    </div>
  );
});
