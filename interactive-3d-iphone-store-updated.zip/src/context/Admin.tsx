import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { ADMIN_CREDENTIALS, ADMIN_FUNCTIONS, formatValue, type AdminFunction } from "../data/admin";

export interface AdminSession {
  username: string;
  at: string;
  expiresAt: number;
}

export interface AdminLogEntry {
  id: string;
  fnId: string;
  label: string;
  detail: string;
  category: string;
  at: string;
}

/** A signed-in admin session lasts 12 hours */
const SESSION_MS = 12 * 60 * 60 * 1000;
const LS_SESSION = "aura-admin-session";
const LS_STATE = "aura-admin-state";

interface PersistedState {
  flags: Record<string, boolean>;
  values: Record<string, number>;
  runs: Record<string, number>;
  log: AdminLogEntry[];
}

const EMPTY: PersistedState = { flags: {}, values: {}, runs: {}, log: [] };

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage unavailable — session only */
  }
}

function seedDefaults(): PersistedState {
  const flags: Record<string, boolean> = {};
  const values: Record<string, number> = {};
  for (const fn of ADMIN_FUNCTIONS) {
    if (fn.kind === "toggle") flags[fn.id] = fn.start ?? false;
    if (fn.kind === "value") values[fn.id] = fn.value?.start ?? 0;
  }
  return { flags, values, runs: {}, log: [] };
}

interface AdminApi {
  session: AdminSession | null;
  portalOpen: boolean;
  flags: Record<string, boolean>;
  values: Record<string, number>;
  runs: Record<string, number>;
  log: AdminLogEntry[];
  totalRuns: number;
  signIn: (username: string, password: string) => string | null;
  signOut: () => void;
  openPortal: () => void;
  closePortal: () => void;
  run: (fn: AdminFunction, direction?: 1 | -1) => string;
  resetState: () => void;
}

const AdminContext = createContext<AdminApi | null>(null);

export function AdminProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<AdminSession | null>(null);
  const [portalOpen, setPortalOpen] = useState(false);
  const [state, setState] = useState<PersistedState>(EMPTY);

  // Restore session + admin state; expire stale sessions
  useEffect(() => {
    const stored = read<AdminSession | null>(LS_SESSION, null);
    if (stored && stored.expiresAt > Date.now()) {
      setSession(stored);
    } else if (stored) {
      write(LS_SESSION, null);
    }
    const persisted = read<PersistedState | null>(LS_STATE, null);
    setState(persisted ?? seedDefaults());
  }, []);

  const signIn = useCallback(
    (username: string, password: string): string | null => {
      const user = username.trim().toLowerCase();
      const okUser = user === ADMIN_CREDENTIALS.username || user === ADMIN_CREDENTIALS.alias;
      if (!username.trim()) return "Enter your admin username.";
      if (!okUser) return "Unknown admin account — access denied.";
      if (!password) return "Enter your admin password.";
      if (password !== ADMIN_CREDENTIALS.password) return "Incorrect password — access denied.";
      const next: AdminSession = {
        username: ADMIN_CREDENTIALS.username,
        at: new Date().toISOString(),
        expiresAt: Date.now() + SESSION_MS,
      };
      setSession(next);
      write(LS_SESSION, next);
      return null;
    },
    [],
  );

  const signOut = useCallback(() => {
    setSession(null);
    write(LS_SESSION, null);
  }, []);

  const run = useCallback(
    (fn: AdminFunction, direction: 1 | -1 = 1): string => {
      let detail = fn.result ?? "Completed";
      setState((prev) => {
        const next: PersistedState = {
          flags: { ...prev.flags },
          values: { ...prev.values },
          runs: { ...prev.runs },
          log: [...prev.log],
        };
        if (fn.kind === "toggle") {
          const on = !next.flags[fn.id];
          next.flags[fn.id] = on;
          detail = `${fn.label} ${on ? "enabled" : "disabled"}`;
        } else if (fn.kind === "value") {
          const spec = fn.value;
          const current = next.values[fn.id] ?? spec?.start ?? 0;
          const step = spec?.step ?? 1;
          const min = spec?.min ?? 0;
          const max = spec?.max ?? current + step;
          const raw = direction === -1 ? current - step : current + step;
          const nextVal = raw > max ? min : raw < min ? max : raw;
          next.values[fn.id] = nextVal;
          detail = `${fn.label} set to ${formatValue(fn, nextVal)}`;
        } else {
          next.runs[fn.id] = (next.runs[fn.id] ?? 0) + 1;
        }
        next.log = [
          {
            id: `${Date.now()}-${fn.id}`,
            fnId: fn.id,
            label: fn.label,
            detail,
            category: fn.category,
            at: new Date().toISOString(),
          },
          ...next.log,
        ].slice(0, 60);
        write(LS_STATE, next);
        return next;
      });
      return detail;
    },
    [],
  );

  const resetState = useCallback(() => {
    const seeded = seedDefaults();
    setState(seeded);
    write(LS_STATE, seeded);
  }, []);

  const api = useMemo<AdminApi>(
    () => ({
      session,
      portalOpen,
      flags: state.flags,
      values: state.values,
      runs: state.runs,
      log: state.log,
      totalRuns: Object.values(state.runs).reduce((n, v) => n + v, 0),
      signIn,
      signOut,
      openPortal: () => setPortalOpen(true),
      closePortal: () => setPortalOpen(false),
      run,
      resetState,
    }),
    [session, portalOpen, state, signIn, signOut, run, resetState],
  );

  return <AdminContext.Provider value={api}>{children}</AdminContext.Provider>;
}

export function useAdmin() {
  const ctx = useContext(AdminContext);
  if (!ctx) throw new Error("useAdmin must be used within AdminProvider");
  return ctx;
}

export { ADMIN_FUNCTIONS };
