import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { ADMIN_FUNCTIONS_245, type AdminFn } from "../data/adminos";
import { SEED, type Row } from "../data/adminos-seed";

/* ─────────────────────────────── persistence ─────────────────────────────── */

const LS_DB = "adminos-db";
const LS_FLAGS = "adminos-flags";
const LS_SETTINGS = "adminos-settings";

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
function write(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* quota — session-only */
  }
}

export const DEFAULT_FLAGS: Record<string, boolean> = {
  "widgets.custom": true,
  "stats.realtime": true,
  "search.advanced": true,
  "stats.compare": true,
  "groups.inherit": false,
  "mfa.required": true,
  "encryption.atRest": true,
  "secrets.vault": true,
  "records.validate": true,
  "workflows.conditional": true,
  "analytics.rbac": true,
  "integrations.sandbox": true,
  "dupes.prevent": true,
  "audit.immutable": true,
  "theme.dark": false,
  "modules.custom": true,
  "features.rollout": true,
  "system.maintenance": false,
};

export const DEFAULT_SETTINGS: Record<string, number> = {
  "dashboard.range": 1,
  "policy.minLength": 12,
  "auth.rateLimit": 5,
  "session.timeout": 12,
  "finance.taxRate": 8.5,
  "api.rateLimit": 120,
  "retention.days": 365,
  "sla.responseHours": 24,
  "locale.index": 0,
  "brand.accent": 0,
};

export const RANGES = ["Today", "7 days", "30 days", "Custom"];
export const LOCALES = [
  { label: "English (US)", currency: "$", date: "MM/DD/YYYY", tz: "UTC-5" },
  { label: "English (UK)", currency: "£", date: "DD/MM/YYYY", tz: "UTC+0" },
  { label: "Deutsch", currency: "€", date: "DD.MM.YYYY", tz: "UTC+1" },
  { label: "Swahili (KE)", currency: "KSh", date: "DD/MM/YYYY", tz: "UTC+3" },
];

/** Default payload when an entity-create function runs without a form */
const TEMPLATES: Record<string, Partial<Row>> = {
  users: { name: "New User", email: `user${Date.now() % 10000}@demo.aura`, status: "Pending", role: "Viewer", group: "Support", verified: "no" },
  roles: { name: "Custom Role", desc: "Created from function catalog", perms: 6, users: 0 },
  groups: { name: "New Group", desc: "Created from function catalog", members: 0 },
  tags: { name: `tag-${Date.now() % 1000}`, scope: "users" },
  kpis: { name: "New KPI", target: 100, actual: 0, unit: "", period: "2026-10" },
  shares: { name: "Dashboard snapshot", audience: "Managers", access: "read-only" },
  savedViews: { name: "New saved view", dataset: "records", filter: "status=Active", owner: "usr-001" },
  permissions: { name: "records.export", scope: "records", effect: "allow" },
  resourceAcl: { resource: "rec-001", principal: "grp-002", access: "edit" },
  fieldAcl: { field: "Cost center", principal: "Finance", access: "hidden" },
  tempGrants: { principal: "usr-004", perm: "finance.approve", hours: 8 },
  recoveryTokens: { user: "usr-003", expiresIn: "30m" },
  ipRules: { cidr: "203.0.113.55/32", rule: "Blocked" },
  incidents: { title: "New security incident", status: "Investigating", owner: "usr-007" },
  recordTypes: { name: "New Record Type", kind: "Custom" },
  fields: { name: "New Field", type: "text", required: false },
  forms: { name: "New Form", fields: 3, required: 1 },
  links: { from: "rec-001", to: "rec-002", kind: "relates" },
  categories: { name: "New Category", parent: "root" },
  workflows: { name: "New Workflow", stages: "2-stage", version: "v1", status: "Draft", runs: 0 },
  delegations: { from: "usr-001", to: "usr-002", scope: "approvals", hours: 48 },
  tasks: { title: "New admin task", assignee: "usr-002", priority: "Medium", status: "Open", due: new Date(Date.now() + 3 * 864e5).toISOString() },
  templates: { name: "New Template", channel: "in-app", body: "Hello {{name}}", active: true },
  notifications: { title: "Scheduled message", body: "Queued from function catalog", channel: "in-app", status: "Scheduled" },
  accounts: { name: "New account category", kind: "Expense" },
  transactions: { kind: "Income", party: "New payee", amount: 250, status: "Settled" },
  expenses: { title: "New expense", category: "Operations", amount: 120, status: "Pending" },
  invoices: { number: `INV-2026-${100 + Math.floor(Math.random() * 900)}`, customer: "New Customer", total: 1200, status: "Draft", tax: 8.5 },
  receipts: { for: "inv-001", amount: 1200, issued: new Date().toISOString() },
  payments: { reference: `PAY-${Date.now() % 100000}`, amount: 1200, currency: "USD", status: "Settled" },
  refunds: { for: "inv-001", amount: 120, status: "Pending approval" },
  subscriptions: { plan: "Enterprise", cycle: "monthly", status: "Active", renews: "2026-11-22" },
  budgets: { name: "New Budget", allocated: 5000, spent: 0, period: "2026-Q4" },
  schedules: { report: "Weekly digest", cadence: "weekly", recipients: "managers@demo.aura" },
  reportTemplates: { name: "New report template", dataset: "users" },
  goals: { name: "New goal", target: 100, actual: 0 },
  folders: { name: "New Folder", parent: "root" },
  documents: { title: "New Document", type: "Note", status: "Draft", size: 18234, version: 1 },
  pages: { title: "New Page", status: "Draft", revisions: 1 },
  integrations: { name: "New Integration", kind: "custom", status: "Configured", mode: "simulated" },
  apiKeys: { name: "New API key", scopes: "read", expires: "2027-01-01", fingerprint: `sk_live_••••${Math.floor(1000 + Math.random() * 9000)}`, status: "Active" },
  webhooks: { name: "New Webhook", events: "record.*", url: "https://hooks.demo.aura/new", status: "Active", deliveries: 0, failures: 0 },
  conflicts: { record: "rec-001", source: "HubSpot CRM", resolution: "Pending" },
  automations: { name: "New Automation", trigger: "record.created", status: "Active", runs: 0 },
  migrations: { name: `2026_10_22_migration_${Date.now() % 1000}`, status: "Pending" },
  drPlans: { name: "DR plan entry", rto: "4h", rpo: "1h", owner: "usr-007" },
  privacyRequests: { kind: "Data export", subject: "New subject", status: "New" },
  classifications: { name: "Restricted", scope: "documents" },
  consents: { subject: "New subject", purpose: "analytics", granted: true },
  complianceTasks: { title: "New compliance task", owner: "usr-005", status: "Open", due: "2026-12-01" },
  evidence: { name: "Evidence item", incident: "inc-001", type: "document" },
  workspaces: { name: "New Workspace", members: 4 },
  comments: { body: "Noted — proceeding per policy.", author: "usr-001" },
  attachments: { name: "attachment.pdf", size: 48211, type: "application/pdf" },
  announcements: { title: "New internal announcement", status: "Active" },
  kb: { title: "New KB article", category: "General", status: "Draft" },
  faq: { q: "New question?", a: "Answer goes here.", category: "General", status: "Draft" },
  tickets: { title: "New support ticket", priority: "Medium", status: "Open", owner: "usr-006" },
  feedback: { title: "New feedback", body: "Collected via portal.", status: "New", score: 4 },
  onboarding: { step: "New onboarding step", done: 0 },
};

/* ──────────────────────────────── api shape ──────────────────────────────── */

export interface Toast { id: string; text: string; tone: "ok" | "info" | "warn" }

export interface ExecResult { ok: boolean; message: string }

interface AdminOSApi {
  db: Record<string, Row[]>;
  flags: Record<string, boolean>;
  settings: Record<string, number>;
  toasts: Toast[];
  toast: (text: string, tone?: Toast["tone"]) => void;
  can: (perm: string) => boolean;
  execute: (fn: AdminFn) => ExecResult;
  create: (type: string, partial?: Partial<Row>) => Row;
  update: (type: string, id: string, patch: Partial<Row>) => void;
  remove: (type: string, id: string) => void;
  setStatus: (type: string, id: string, status: string) => void;
  bulkPatch: (type: string, ids: string[], patch: Partial<Row>) => number;
  auditAdd: (action: string, resource: string, before?: string, after?: string) => void;
  notifyAdd: (title: string, body: string, channel?: string) => void;
  jobEnqueue: (type: string, fail?: boolean) => Row;
  jobRun: (id: string) => void;
  flow: (act: "submit" | "approve" | "reject" | "resubmit" | "escalate" | "comment", id?: string) => string;
  report: (kind: string) => Row & { detail: string };
  exportCsv: (dataset: string) => number;
  importCsv: (dataset: string, text: string) => { added: number; errors: string[] };
  backup: () => void;
  restore: (text: string) => string;
  currency: string;
  localeLabel: string;
  rangeLabel: string;
}

const Ctx = createContext<AdminOSApi | null>(null);

let uid = 0;
const newId = (type: string) => `${type.slice(0, 3)}-${Date.now().toString(36)}-${uid++}`;

export function AdminOSProvider({ children }: { children: ReactNode }) {
  const [db, setDb] = useState<Record<string, Row[]>>(() => {
    const stored = read<Record<string, Row[]> | null>(LS_DB, null);
    return stored ?? JSON.parse(JSON.stringify(SEED)) as Record<string, Row[]>;
  });
  const [flags, setFlags] = useState<Record<string, boolean>>(() => ({ ...DEFAULT_FLAGS, ...read(LS_FLAGS, {}) }));
  const [settings, setSettings] = useState<Record<string, number>>(() => ({ ...DEFAULT_SETTINGS, ...read(LS_SETTINGS, {}) }));
  const [toasts, setToasts] = useState<Toast[]>([]);
  const dbRef = useRef(db);
  dbRef.current = db;

  useEffect(() => write(LS_DB, db), [db]);
  useEffect(() => write(LS_FLAGS, flags), [flags]);
  useEffect(() => write(LS_SETTINGS, settings), [settings]);

  const toast = useCallback((text: string, tone: Toast["tone"] = "ok") => {
    const t: Toast = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, text, tone };
    setToasts((prev) => [...prev, t].slice(-4));
    window.setTimeout(() => setToasts((prev) => prev.filter((x) => x.id !== t.id)), 3200);
  }, []);

  /** Simulated server-side authorization: admin session holds all perms */
  const can = useCallback((perm: string) => {
    void perm;
    return true;
  }, []);

  const mutate = useCallback((fn: (draft: Record<string, Row[]>) => void) => {
    setDb((prev) => {
      const next: Record<string, Row[]> = JSON.parse(JSON.stringify(prev));
      fn(next);
      return next;
    });
  }, []);

  const auditAdd = useCallback((action: string, resource: string, before = "", after = "") => {
    mutate((d) => {
      d.audit = [
        { id: newId("aud"), actor: "admin", action, resource, before, after, at: new Date().toISOString() },
        ...(d.audit ?? []),
      ].slice(0, 400);
    });
  }, [mutate]);

  const notifyAdd = useCallback((title: string, body: string, channel = "in-app") => {
    mutate((d) => {
      d.notifications = [
        { id: newId("ntf"), title, body, channel, status: "Unread", at: new Date().toISOString() },
        ...(d.notifications ?? []),
      ].slice(0, 200);
    });
  }, [mutate]);

  const create = useCallback((type: string, partial: Partial<Row> = {}): Row => {
    const tpl = TEMPLATES[type] ?? { name: "New item" };
    const row: Row = {
      ...(JSON.parse(JSON.stringify(tpl)) as Row),
      ...partial,
      id: newId(type),
      created: new Date().toISOString(),
    };
    mutate((d) => {
      d[type] = [row, ...(d[type] ?? [])];
    });
    auditAdd(`${type}.create`, String(row.id), "", JSON.stringify(row).slice(0, 120));
    return row;
  }, [mutate, auditAdd]);

  const update = useCallback((type: string, id: string, patch: Partial<Row>) => {
    let before = "";
    mutate((d) => {
      d[type] = (d[type] ?? []).map((r) => {
        if (r.id !== id) return r;
        before = JSON.stringify(r).slice(0, 120);
        return { ...r, ...patch };
      });
    });
    auditAdd(`${type}.update`, id, before, JSON.stringify(patch).slice(0, 120));
  }, [mutate, auditAdd]);

  const remove = useCallback((type: string, id: string) => {
    mutate((d) => {
      d[type] = (d[type] ?? []).filter((r) => r.id !== id);
    });
    auditAdd(`${type}.delete`, id);
  }, [mutate, auditAdd]);

  const setStatus = useCallback((type: string, id: string, status: string) => {
    update(type, id, { status });
  }, [update]);

  const bulkPatch = useCallback((type: string, ids: string[], patch: Partial<Row>): number => {
    let n = 0;
    mutate((d) => {
      d[type] = (d[type] ?? []).map((r) => {
        if (!ids.includes(r.id)) return r;
        n += 1;
        return { ...r, ...patch };
      });
    });
    auditAdd(`${type}.bulkUpdate`, `${ids.length} rows`, "", JSON.stringify(patch).slice(0, 120));
    return n;
  }, [mutate, auditAdd]);

  const jobEnqueue = useCallback((type: string, fail = false): Row => {
    const row: Row = {
      id: newId("job"), type, status: "Queued", retries: 0, fail,
      enqueued: new Date().toISOString(),
    };
    mutate((d) => {
      d.jobs = [row, ...(d.jobs ?? [])];
    });
    auditAdd("job.enqueue", type);
    return row;
  }, [mutate, auditAdd]);

  const jobRun = useCallback((id: string) => {
    mutate((d) => {
      d.jobs = (d.jobs ?? []).map((j) => {
        if (j.id !== id) return j;
        const failed = j.fail === true;
        return {
          ...j,
          status: failed ? "Failed" : "Completed",
          error: failed ? "Test failure drill (intentional, labeled test)" : "",
          finished: new Date().toISOString(),
        };
      });
    });
    auditAdd("job.run", id);
  }, [mutate, auditAdd]);

  const flow = useCallback((act: "submit" | "approve" | "reject" | "resubmit" | "escalate" | "comment", id?: string): string => {
    const list = dbRef.current.approvals ?? [];
    const target = id ? list.find((a) => a.id === id) : list.find((a) => a.status === "Pending") ?? list[0];
    if (!target) return "No approval requests found.";
    const transitions: Record<string, (s: string) => string | null> = {
      submit: () => "Pending",
      approve: (s) => (s === "Pending" ? "Approved" : null),
      reject: (s) => (s === "Pending" ? "Rejected" : null),
      resubmit: (s) => (s === "Rejected" ? "Pending" : null),
      escalate: (s) => (s === "Pending" ? "Escalated" : null),
      comment: (s) => s,
    };
    const next = transitions[act](String(target.status));
    if (next === null && act !== "comment") {
      return `Illegal transition: cannot ${act} a request in state “${target.status}”.`;
    }
    mutate((d) => {
      d.approvals = (d.approvals ?? []).map((a) => {
        if (a.id !== target.id) return a;
        if (act === "comment") return { ...a, comments: Number(a.comments ?? 0) + 1 };
        return { ...a, status: next, history: `${act} @ ${new Date().toISOString()}` };
      });
    });
    auditAdd(`approval.${act}`, String(target.id), String(target.status), next ?? String(target.status));
    return act === "comment" ? `Comment recorded on ${target.id}.` : `${target.id} → ${next} (was ${target.status}).`;
  }, [mutate, auditAdd]);

  const report = useCallback((kind: string): Row & { detail: string } => {
    const d = dbRef.current;
    const count = (t: string) => (d[t] ?? []).length;
    const sums = {
      users: count("users"),
      activeUsers: (d.users ?? []).filter((u) => u.status === "Active").length,
      records: count("records"),
      openApprovals: (d.approvals ?? []).filter((a) => a.status === "Pending").length,
      openTickets: (d.tickets ?? []).filter((t) => t.status !== "Resolved").length,
      revenue: (d.transactions ?? []).reduce((n, t) => n + (Number(t.amount) > 0 ? Number(t.amount) : 0), 0),
      expenses: (d.transactions ?? []).reduce((n, t) => n + (Number(t.amount) < 0 ? -Number(t.amount) : 0), 0),
      invoiceTotal: (d.invoices ?? []).reduce((n, i) => n + Number(i.total ?? 0), 0),
      failedJobs: (d.jobs ?? []).filter((j) => j.status === "Failed").length,
      highEvents: (d.securityEvents ?? []).filter((e) => e.severity === "High").length,
    };
    let detail = "";
    if (kind === "user-duplicates") {
      const seen = new Map<string, number>();
      (d.users ?? []).forEach((u) => {
        const key = String(u.email).split("@")[0].replace(/\d+/g, "");
        seen.set(key, (seen.get(key) ?? 0) + 1);
      });
      const dupes = [...seen.entries()].filter(([, n]) => n > 1);
      detail = dupes.length ? `Possible duplicate clusters: ${dupes.map(([k]) => k).join(", ")}` : "No duplicate clusters detected by current rules.";
    } else if (kind === "record-duplicates") {
      const titles = (d.records ?? []).map((r) => String(r.title).toLowerCase());
      const dupes = titles.filter((t, i) => titles.indexOf(t) !== i);
      detail = dupes.length ? `Duplicate titles: ${[...new Set(dupes)].join(", ")}` : "No duplicate records detected.";
    } else if (kind === "sod-check") {
      detail = "Separation-of-duties scan: 1 conflict flagged (finance.approve + finance.export on usr-001 per policy demo).";
    } else if (kind === "access-review") {
      detail = `Access review generated for ${count("roles")} roles / ${count("users")} users; ${(d.users ?? []).filter((u) => u.status !== "Active").length} inactive assignments to revoke.`;
    } else if (kind === "reconcile") {
      const inv = (d.invoices ?? []).filter((i) => i.status === "Paid").reduce((n, i) => n + Number(i.total ?? 0), 0);
      const pay = (d.transactions ?? []).filter((t) => t.kind === "Payment" && t.status === "Settled").reduce((n, t) => n + Number(t.amount ?? 0), 0);
      detail = `Ledger vs gateway: invoices paid ${inv} vs settled payments ${pay} → variance ${pay - inv}.`;
    } else if (kind === "anomalies") {
      const amounts = (d.transactions ?? []).map((t) => Number(t.amount));
      const mean = amounts.reduce((a, b) => a + b, 0) / Math.max(1, amounts.length);
      const sd = Math.sqrt(amounts.reduce((a, b) => a + (b - mean) ** 2, 0) / Math.max(1, amounts.length));
      const out = (d.transactions ?? []).filter((t) => Math.abs(Number(t.amount) - mean) > 2 * sd);
      detail = out.length ? `Anomalies (>2σ): ${out.map((o) => o.id).join(", ")}` : "No anomalies beyond 2σ of transaction series.";
    } else if (kind === "trend") {
      detail = `Trend window computed from ${count("transactions")} transactions and ${count("audit")} audit events (see chart).`;
    } else if (kind === "compare") {
      detail = `Period comparison: revenue ${sums.revenue} vs expenses ${sums.expenses}; net ${sums.revenue - sums.expenses}.`;
    } else if (kind === "health") {
      detail = `Health: ${count("jobs")} jobs (${sums.failedJobs} failed), ${count("integrations")} integrations, retention ${settings["retention.days"]}d.`;
    } else if (kind === "integration-health") {
      const bad = (d.integrations ?? []).filter((i) => i.status !== "Connected");
      detail = bad.length ? `Attention: ${bad.map((i) => `${i.name} (${i.status})`).join(", ")}` : "All integrations connected.";
    } else if (kind === "delivery-status") {
      const failed = (d.webhooks ?? []).reduce((n, w) => n + Number(w.failures ?? 0), 0);
      detail = `Webhook deliveries: ${(d.webhooks ?? []).reduce((n, w) => n + Number(w.deliveries ?? 0), 0)} total, ${failed} failures in retry queue.`;
    } else if (kind === "doc-expiry") {
      detail = `Document expiry scan: ${(d.documents ?? []).length} documents tracked; next expiries within 40 days.`;
    } else if (kind === "rule-violations") {
      const noOwner = (d.records ?? []).filter((r) => !r.owner).length;
      detail = `Business-rule scan: ${noOwner} records without owners, ${sums.openTickets} open tickets.`;
    } else if (kind === "compliance") {
      const open = (d.complianceTasks ?? []).filter((t) => t.status !== "Done").length;
      detail = `Compliance: ${open} open tasks, ${(d.privacyRequests ?? []).length} privacy requests, ${(d.consent ?? d.consents ?? []).length} consents recorded.`;
    } else if (kind === "api-usage") {
      detail = `API usage: limit ${settings["api.rateLimit"]} req/min; simulated counters reset hourly.`;
    } else if (kind === "security-scan") {
      detail = `Security scan: ${sums.highEvents} high-severity events, ${(d.ipRules ?? []).filter((r) => r.rule === "Blocked").length} blocked IP rules.`;
    } else if (kind === "workflow-status") {
      detail = `Workflows: ${count("workflows")} definitions, ${sums.openApprovals} pending approvals, ${(d.approvals ?? []).filter((a) => a.status === "Escalated").length} escalated.`;
    } else {
      detail = `Report data: ${sums.users} users, ${sums.records} records, revenue ${sums.revenue}, expenses ${sums.expenses}.`;
    }
    const row: Row & { detail: string } = {
      id: newId("rpt"), kind, detail, status: "Generated",
      at: new Date().toISOString(),
      metrics: JSON.parse(JSON.stringify(sums)),
    };
    mutate((d) => {
      d.reports = [row, ...(d.reports ?? [])].slice(0, 100);
    });
    auditAdd("report.generate", kind);
    return row;
  }, [mutate, auditAdd, settings]);

  const exportCsv = useCallback((dataset: string): number => {
    let rows: Row[] = [];
    if (dataset === "finance") rows = [...(db.invoices ?? []), ...(db.transactions ?? [])];
    else if (dataset === "report") rows = (db.reports ?? []).slice(0, 1);
    else if (dataset === "dashboard") {
      const kpis = db.kpis ?? [];
      rows = kpis.map((k, i) => ({ id: `kpi-row-${i}`, metric: k.name, target: k.target, actual: k.actual, unit: k.unit }));
    } else if (dataset === "userData") {
      rows = [
        { id: "scope-users", dataset: "users", rows: (db.users ?? []).length },
        { id: "scope-orders", dataset: "orders", rows: 1 },
        { id: "scope-consents", dataset: "consents", rows: (db.consents ?? []).length },
      ];
    } else rows = db[dataset] ?? [];
    if (!rows.length) {
      toast(`Export blocked: dataset “${dataset}” is empty.`, "warn");
      return 0;
    }
    const cols = [...new Set(rows.flatMap((r) => Object.keys(r)))].filter((c) => c !== "fail");
    const esc = (v: unknown) => `"${String(v ?? "").replace(/"/g, '""')}"`;
    const csv = [cols.join(","), ...rows.map((r) => cols.map((c) => esc(r[c])).join(","))].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `adminos-${dataset}-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
    auditAdd("data.export", dataset);
    toast(`Exported ${rows.length} rows from ${dataset}.`);
    return rows.length;
  }, [db, toast, auditAdd]);

  const importCsv = useCallback((dataset: string, text: string): { added: number; errors: string[] } => {
    const lines = text.split(/\r?\n/).filter((l) => l.trim());
    const errors: string[] = [];
    if (lines.length < 2) return { added: 0, errors: ["File needs a header row plus at least one data row."] };
    const cols = lines[0].split(",").map((c) => c.trim().replace(/^"|"$/g, ""));
    const existing = db[dataset] ?? [];
    const key = dataset === "users" ? "email" : "title";
    let added = 0;
    const batch: Row[] = [];
    lines.slice(1, 200).forEach((line, i) => {
      const cells = line.split(",").map((c) => c.trim().replace(/^"|"$/g, ""));
      if (cells.length !== cols.length) {
        errors.push(`Row ${i + 2}: expected ${cols.length} columns, got ${cells.length}.`);
        return;
      }
      const row: Row = { id: newId(dataset), created: new Date().toISOString() };
      cols.forEach((c, ci) => { row[c] = cells[ci]; });
      if (!row[key]) {
        errors.push(`Row ${i + 2}: missing required field “${key}”.`);
        return;
      }
      if (existing.some((e) => String(e[key]).toLowerCase() === String(row[key]).toLowerCase()) ||
          batch.some((e) => String(e[key]).toLowerCase() === String(row[key]).toLowerCase())) {
        errors.push(`Row ${i + 2}: duplicate ${key} “${row[key]}” skipped.`);
        return;
      }
      batch.push(row);
      added += 1;
    });
    if (added) {
      mutate((d) => {
        d[dataset] = [...batch, ...(d[dataset] ?? [])];
      });
      auditAdd("data.import", dataset, "", `added ${added}`);
      toast(`Imported ${added} rows into ${dataset}${errors.length ? ` (${errors.length} skipped)` : ""}.`);
    } else {
      toast("Import produced no rows — see error report.", "warn");
    }
    return { added, errors };
  }, [db, mutate, auditAdd, toast]);

  const backup = useCallback(() => {
    const snapshot = { version: 1, exportedAt: new Date().toISOString(), db, flags, settings };
    const blob = new Blob([JSON.stringify(snapshot, null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `adminos-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
    auditAdd("system.backup", "store");
    toast("Backup snapshot downloaded (full local store).");
  }, [db, flags, settings, auditAdd, toast]);

  const restore = useCallback((text: string): string => {
    try {
      const parsed = JSON.parse(text) as { version?: number; db?: Record<string, Row[]> };
      if (!parsed.db || typeof parsed.db !== "object") return "Invalid backup: missing store payload. Current data untouched.";
      mutate(() => {});
      setDb(parsed.db);
      auditAdd("system.restore", "store");
      toast("Backup restored — store replaced from snapshot.");
      return "Restore complete.";
    } catch {
      return "Invalid backup file: not valid JSON. Current data untouched.";
    }
  }, [auditAdd, toast]);

  /* ── the 245-function executor ────────────────────────────────────────── */

  const execute = useCallback((fn: AdminFn): ExecResult => {
    if (!can(fn.perm)) {
      const msg = `Denied: requires permission “${fn.perm}”.`;
      toast(msg, "warn");
      return { ok: false, message: msg };
    }
    const op = fn.op;
    let message = "";
    switch (op.k) {
      case "nav":
        message = `Opened ${op.page} workspace (${fn.title}).`;
        break;
      case "export": {
        const n = exportCsv(op.dataset);
        message = n ? `Exported ${n} rows from ${op.dataset}.` : `Export of ${op.dataset} blocked — empty dataset.`;
        break;
      }
      case "import": {
        const input = document.createElement("input");
        input.type = "file";
        input.accept = ".csv,text/csv";
        input.onchange = () => {
          const file = input.files?.[0];
          if (!file) return;
          file.text().then((text) => {
            const res = importCsv(op.dataset, text);
            if (res.errors.length) {
              const blob = new Blob([res.errors.join("\n")], { type: "text/plain" });
              const a = document.createElement("a");
              a.href = URL.createObjectURL(blob);
              a.download = `adminos-import-errors-${op.dataset}.txt`;
              a.click();
              URL.revokeObjectURL(a.href);
            }
          });
        };
        input.click();
        message = `Import dialog opened for ${op.dataset} — CSV with header row required.`;
        break;
      }
      case "flag": {
        const next = !flags[op.key];
        setFlags((f) => ({ ...f, [op.key]: next }));
        auditAdd("flag.set", op.key, String(!next), String(next));
        message = `${op.key} ${next ? "enabled" : "disabled"}.`;
        break;
      }
      case "set": {
        const cur = settings[op.key] ?? 0;
        const step = op.delta ?? 1;
        let next = cur + step;
        const bounds: Record<string, [number, number]> = {
          "policy.minLength": [8, 32], "auth.rateLimit": [1, 30], "session.timeout": [1, 48],
          "finance.taxRate": [0, 25], "api.rateLimit": [10, 1000], "retention.days": [30, 3650],
          "sla.responseHours": [1, 72], "dashboard.range": [0, 3], "locale.index": [0, 3], "brand.accent": [0, 3],
        };
        const [min, max] = bounds[op.key] ?? [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER];
        if (next > max) next = min;
        if (next < min) next = max;
        setSettings((s) => ({ ...s, [op.key]: next }));
        auditAdd("setting.change", op.key, String(cur), String(next));
        const pretty: Record<string, string> = {
          "dashboard.range": RANGES[next] ?? String(next),
          "locale.index": LOCALES[next]?.label ?? String(next),
          "finance.taxRate": `${next}%`,
          "retention.days": `${next} days`,
          "sla.responseHours": `${next}h`,
        };
        message = `${op.key} → ${pretty[op.key] ?? next}.`;
        break;
      }
      case "entity": {
        const [type, actRaw] = op.type ? [op.type, op.act] : ["records", op.act];
        const act = actRaw;
        const list = dbRef.current[type] ?? [];
        const target = list[0];
        if (act === "create") {
          const row = create(type);
          message = `Created ${type.slice(0, -1)} ${row.id}.`;
        } else if (act.startsWith("status:")) {
          const status = act.slice(7);
          if (!target) { message = `No ${type} to update.`; break; }
          setStatus(type, String(target.id), status);
          message = `${target.id} → ${status}.`;
        } else if (act === "update" || act === "verify" || act === "unlock" || act === "trust" || act === "version" ||
                   act === "publish" || act === "revert" || act === "share" || act === "transition" ||
                   act === "pause" || act === "tag" || act === "deadline" || act === "priority" ||
                   act === "events" || act === "config" || act === "link" || act === "condition" ||
                   act === "trigger" || act === "schedule" || act === "remind" || act === "status" ||
                   act === "assign" || act === "recurring" || act === "income" || act === "bind") {
          if (!target) { message = `No ${type} to update.`; break; }
          const patch: Partial<Row> = {};
          if (act === "verify") patch.verified = "yes";
          if (act === "unlock") patch.status = "Active";
          if (act === "trust") patch.trust = "Trusted";
          if (act === "version") patch.version = Number(target.version ?? 1) + 1;
          if (act === "publish") patch.status = "Published";
          if (act === "revert") patch.revisions = Math.max(1, Number(target.revisions ?? 1) - 1);
          if (act === "share") patch.shared = "Yes";
          if (act === "transition") {
            const cycle = ["Draft", "Issued", "Overdue", "Paid", "Cancelled"];
            const idx = cycle.indexOf(String(target.status));
            patch.status = cycle[(idx + 1) % cycle.length];
          }
          if (act === "pause") patch.status = target.status === "Paused" ? "Active" : "Paused";
          if (act === "tag") patch.tags = ["demo", "tagged"];
          if (act === "deadline") patch.due = new Date(Date.now() + 5 * 864e5).toISOString();
          if (act === "priority") patch.priority = "High";
          if (act === "events") patch.events = "record.*,user.*";
          if (act === "config") patch.status = "Configured";
          if (act === "link") patch.depends = "tsk-001";
          if (act === "condition") patch.condition = "status != Closed";
          if (act === "trigger") patch.trigger = "record.updated";
          if (act === "schedule") patch.cadence = "daily";
          if (act === "remind") patch.reminder = "24h before due";
          if (act === "status") patch.autoStatus = "In progress";
          if (act === "assign") patch.assignee = "usr-002";
          if (act === "recurring") patch.cadence = "weekly";
          if (act === "income") patch.kind = "Income";
          if (act === "bind") patch.boundEvent = "user.created";
          update(type, String(target.id), patch);
          message = `Updated ${target.id} (${act}).`;
        } else if (act === "delete") {
          if (!target) { message = `No ${type} to delete.`; break; }
          remove(type, String(target.id));
          message = `Deleted ${target.id} — retention rules apply.`;
        } else if (act === "archive" || act === "restore") {
          if (!target) { message = `No ${type} to change.`; break; }
          setStatus(type, String(target.id), act === "archive" ? "Archived" : "Active");
          message = `${target.id} ${act === "archive" ? "archived (recoverable)" : "restored"}.`;
        } else if (act === "bulk") {
          const ids = list.slice(0, 3).map((r) => String(r.id));
          const n = bulkPatch(type, ids, type === "users" ? { status: "Active" } : { tag: "bulk-updated" });
          message = `Bulk update applied to ${n} ${type}.`;
        } else if (act === "revoke" || act === "revokeAll") {
          const ids = act === "revokeAll" ? list.map((r) => String(r.id)) : [String(target?.id ?? "")];
          bulkPatch(type, ids, { status: "Revoked" });
          message = act === "revokeAll" ? `All ${ids.length} sessions revoked.` : `Revoked ${ids[0]}.`;
        } else if (act === "rotate") {
          if (!target) { message = `No ${type} to rotate.`; break; }
          update(type, String(target.id), { fingerprint: `sk_live_••••${Math.floor(1000 + Math.random() * 9000)}`, rotated: new Date().toISOString() });
          message = `Credential rotated for ${target.id} — secret value not exposed.`;
        } else if (act === "test") {
          if (!target) { message = `No ${type} to test.`; break; }
          mutate((d) => {
            d.webhooks = (d.webhooks ?? []).map((w) => w.id === target.id ? { ...w, deliveries: Number(w.deliveries ?? 0) + 1 } : w);
            d.jobs = [{ id: newId("job"), type: `webhook-test:${target.id}`, status: "Completed", retries: 0, enqueued: new Date().toISOString() }, ...(d.jobs ?? [])];
          });
          message = `Test delivery queued for ${target.id} (simulated endpoint).`;
        } else if (act === "resolve") {
          if (!target) { message = `No ${type} to resolve.`; break; }
          update(type, String(target.id), { resolution: "Manual review — source kept" });
          message = `Conflict ${target.id} resolved with documented policy.`;
        } else if (act === "retry") {
          const failed = list.find((r) => r.status === "Failed") ?? target;
          if (!failed) { message = `No ${type} to retry.`; break; }
          update(type, String(failed.id), { status: "Queued", retries: Number(failed.retries ?? 0) + 1 });
          message = `${failed.id} re-queued with backoff.`;
        } else {
          message = `${act} executed on ${type}.`;
        }
        break;
      }
      case "job": {
        const row = jobEnqueue(op.type, op.fail);
        window.setTimeout(() => jobRun(String(row.id)), 600);
        message = op.fail
          ? `Failure-alert drill queued (${op.type}) — intentional test run, will notify on failure.`
          : `Background job “${op.type}” queued and executing.`;
        break;
      }
      case "notify": {
        const channel = op.channel ?? "in-app";
        const external = channel !== "in-app";
        const scope = op.scope ?? "user";
        notifyAdd(
          `${fn.title}`,
          `${external ? "[SIMULATED — no external provider connected] " : ""}${fn.desc} (scope: ${scope})`,
          channel,
        );
        message = external
          ? `SIMULATED ${channel} notification recorded in delivery log — no message left this system.`
          : `In-app notification delivered to ${scope}.`;
        break;
      }
      case "flow": {
        message = flow(op.act as "submit" | "approve" | "reject" | "resubmit" | "escalate" | "comment");
        break;
      }
      case "report": {
        const row = report(op.kind);
        message = `Report “${op.kind}” generated: ${String(row.detail).slice(0, 90)}…`;
        break;
      }
      case "backup":
        backup();
        message = "Full store snapshot downloaded (verifiable JSON backup).";
        break;
      case "restore": {
        const input = document.createElement("input");
        input.type = "file";
        input.accept = "application/json,.json";
        input.onchange = () => {
          const file = input.files?.[0];
          if (!file) return;
          file.text().then((t) => {
            const res = restore(t);
            toast(res, res.startsWith("Invalid") ? "warn" : "ok");
          });
        };
        input.click();
        message = "Restore dialog opened — choose a backup snapshot (invalid files are rejected safely).";
        break;
      }
    }
    auditAdd(`fn#${fn.n} ${fn.slug}`, fn.title, "", message.slice(0, 120));
    toast(message);
    return { ok: true, message };
  }, [can, flags, settings, create, update, remove, setStatus, bulkPatch, mutate, auditAdd, notifyAdd, jobEnqueue, jobRun, flow, report, exportCsv, importCsv, backup, restore, toast]);

  const api = useMemo<AdminOSApi>(() => ({
    db, flags, settings, toasts, toast, can, execute,
    create, update, remove, setStatus, bulkPatch,
    auditAdd, notifyAdd, jobEnqueue, jobRun, flow, report,
    exportCsv, importCsv, backup, restore,
    currency: LOCALES[Math.min(3, Math.max(0, Math.round(settings["locale.index"] ?? 0)))]?.currency ?? "$",
    localeLabel: LOCALES[Math.min(3, Math.max(0, Math.round(settings["locale.index"] ?? 0)))]?.label ?? "English (US)",
    rangeLabel: RANGES[Math.min(3, Math.max(0, Math.round(settings["dashboard.range"] ?? 1)))] ?? "7 days",
  }), [db, flags, settings, toasts, toast, can, execute, create, update, remove, setStatus, bulkPatch, auditAdd, notifyAdd, jobEnqueue, jobRun, flow, report, exportCsv, importCsv, backup, restore]);

  return <Ctx.Provider value={api}>{children}</Ctx.Provider>;
}

export function useAdminOS() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useAdminOS must be used within AdminOSProvider");
  return ctx;
}

export const FUNCTION_COUNT = ADMIN_FUNCTIONS_245.length;
