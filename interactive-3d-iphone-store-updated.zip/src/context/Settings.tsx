import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";

export type ThemePref = "light" | "dark" | "system";

export interface Settings {
  theme: ThemePref;
  reduceMotion: boolean;
  autoRotate3D: boolean;
  smoothScroll: boolean;
}

const DEFAULTS: Settings = {
  theme: "system",
  reduceMotion: false,
  autoRotate3D: true,
  smoothScroll: true,
};

const LS_KEY = "aura-settings";

interface SettingsApi extends Settings {
  /** Theme actually applied right now */
  resolvedTheme: "light" | "dark";
  settingsOpen: boolean;
  openSettings: () => void;
  closeSettings: () => void;
  setTheme: (t: ThemePref) => void;
  toggle: (k: "reduceMotion" | "autoRotate3D" | "smoothScroll") => void;
  reset: () => void;
}

const SettingsContext = createContext<SettingsApi | null>(null);

function load(): Settings {
  try {
    const raw = localStorage.getItem(LS_KEY);
    return raw ? { ...DEFAULTS, ...(JSON.parse(raw) as Partial<Settings>) } : DEFAULTS;
  } catch {
    return DEFAULTS;
  }
}

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<Settings>(DEFAULTS);
  const [systemDark, setSystemDark] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  // Hydrate from storage + watch the OS preference
  useEffect(() => {
    setSettings(load());
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    setSystemDark(mq.matches);
    const onChange = (e: MediaQueryListEvent) => setSystemDark(e.matches);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);

  const resolvedTheme: "light" | "dark" =
    settings.theme === "system" ? (systemDark ? "dark" : "light") : settings.theme;

  // Apply theme + motion classes to <html>
  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("dark", resolvedTheme === "dark");
    root.classList.toggle("reduce-motion", settings.reduceMotion);
    root.style.colorScheme = resolvedTheme;
  }, [resolvedTheme, settings.reduceMotion]);

  // Crossfade the palette when the theme flips: `theme-anim` (see index.css)
  // fades colours on every element at once for the duration of the switch.
  // Skipped on first paint and for reduced motion — those switch instantly.
  const prevTheme = useRef(resolvedTheme);
  const animTimer = useRef<number>(0);
  useEffect(() => {
    const root = document.documentElement;
    const changed = prevTheme.current !== resolvedTheme;
    prevTheme.current = resolvedTheme;
    if (!changed) return;

    const calm =
      settings.reduceMotion ||
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (calm) return;

    window.clearTimeout(animTimer.current);
    root.classList.add("theme-anim");
    animTimer.current = window.setTimeout(() => {
      root.classList.remove("theme-anim");
    }, 340); // slightly past the 0.28s CSS fade
    return () => {
      window.clearTimeout(animTimer.current);
      root.classList.remove("theme-anim");
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- settings are read fresh at each theme change
  }, [resolvedTheme]);

  const persist = useCallback((next: Settings) => {
    setSettings(next);
    try {
      localStorage.setItem(LS_KEY, JSON.stringify(next));
    } catch {
      /* storage unavailable */
    }
  }, []);

  const api = useMemo<SettingsApi>(
    () => ({
      ...settings,
      resolvedTheme,
      settingsOpen,
      openSettings: () => setSettingsOpen(true),
      closeSettings: () => setSettingsOpen(false),
      setTheme: (t) => persist({ ...settings, theme: t }),
      toggle: (k) => persist({ ...settings, [k]: !settings[k] }),
      reset: () => persist(DEFAULTS),
    }),
    [settings, resolvedTheme, settingsOpen, persist],
  );

  return <SettingsContext.Provider value={api}>{children}</SettingsContext.Provider>;
}

export function useSettings() {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error("useSettings must be used within SettingsProvider");
  return ctx;
}

/** True when the user (or their OS) wants less motion. */
export function usePrefersCalm() {
  const { reduceMotion } = useSettings();
  const [osReduce, setOsReduce] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setOsReduce(mq.matches);
    const on = (e: MediaQueryListEvent) => setOsReduce(e.matches);
    mq.addEventListener("change", on);
    return () => mq.removeEventListener("change", on);
  }, []);
  return reduceMotion || osReduce;
}
