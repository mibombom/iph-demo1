import { createContext, useCallback, useContext, useMemo, useReducer, type ReactNode } from "react";
import { findFinish, findModel, findStorage, priceFor, CARE_PLUS_PRICE } from "../data/products";
import type { ReceiptData } from "../utils/receipt";

export interface CartItem {
  key: string;
  title: string;
  meta: string;
  unitPrice: number;
  qty: number;
  tintA: string;
  tintB: string;
}

export type DrawerStep = "bag" | "checkout" | "done";

interface State {
  modelId: string;
  finishId: string;
  storageId: string;
  carePlus: boolean;
  /** Catalog product awaiting quick-configuration in the Buy section */
  productId: string | null;
  bag: CartItem[];
  drawerOpen: boolean;
  drawerStep: DrawerStep;
  orderId: string | null;
  /** Receipt snapshot of the most recent completed order (bag is cleared after) */
  lastOrder: ReceiptData | null;
}

type Action =
  | { type: "SET_MODEL"; modelId: string }
  | { type: "SET_FINISH"; finishId: string }
  | { type: "SET_STORAGE"; storageId: string }
  | { type: "TOGGLE_CARE" }
  | { type: "CONFIGURE_PRODUCT"; productId: string | null }
  | { type: "ADD_ITEM"; item: Omit<CartItem, "qty"> }
  | { type: "ADD_CONFIGURED" }
  | { type: "UPDATE_QTY"; key: string; qty: number }
  | { type: "REMOVE_ITEM"; key: string }
  | { type: "OPEN_DRAWER" }
  | { type: "CLOSE_DRAWER" }
  | { type: "SET_STEP"; step: DrawerStep }
  | { type: "PLACE_ORDER"; orderId: string; receipt: ReceiptData }
  | { type: "RESET_ORDER" };

const initial: State = {
  modelId: "17-pro-max",
  finishId: "cosmic-orange",
  storageId: "256",
  carePlus: false,
  productId: null,
  bag: [],
  drawerOpen: false,
  drawerStep: "bag",
  orderId: null,
  lastOrder: null,
};

function upsert(bag: CartItem[], item: Omit<CartItem, "qty">): CartItem[] {
  const existing = bag.find((i) => i.key === item.key);
  return existing
    ? bag.map((i) => (i.key === item.key ? { ...i, qty: Math.min(9, i.qty + 1) } : i))
    : [...bag, { ...item, qty: 1 }];
}

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case "SET_MODEL": {
      const model = findModel(action.modelId);
      return {
        ...state,
        modelId: model.id,
        finishId: model.finishes[0].id,
        storageId: model.storage[0].id,
        productId: null,
      };
    }
    case "CONFIGURE_PRODUCT":
      return { ...state, productId: action.productId };
    case "SET_FINISH":
      return { ...state, finishId: action.finishId };
    case "SET_STORAGE":
      return { ...state, storageId: action.storageId };
    case "TOGGLE_CARE":
      return { ...state, carePlus: !state.carePlus };
    case "ADD_ITEM":
      return { ...state, bag: upsert(state.bag, action.item), drawerOpen: true, drawerStep: "bag" };
    case "ADD_CONFIGURED": {
      const model = findModel(state.modelId);
      const finish = findFinish(state.modelId, state.finishId);
      const storage = findStorage(state.modelId, state.storageId);
      const item: Omit<CartItem, "qty"> = {
        key: `${state.modelId}|${state.finishId}|${state.storageId}|${state.carePlus}`,
        title: model.name,
        meta: `${finish.name} · ${storage.label}${state.carePlus ? " · AURA Care+" : ""}`,
        unitPrice: priceFor(state.modelId, state.storageId) + (state.carePlus ? CARE_PLUS_PRICE : 0),
        tintA: finish.back,
        tintB: finish.plateau,
      };
      return { ...state, bag: upsert(state.bag, item), drawerOpen: true, drawerStep: "bag" };
    }
    case "UPDATE_QTY":
      return {
        ...state,
        bag: state.bag.map((i) => (i.key === action.key ? { ...i, qty: Math.max(1, Math.min(9, action.qty)) } : i)),
      };
    case "REMOVE_ITEM":
      return { ...state, bag: state.bag.filter((i) => i.key !== action.key) };
    case "OPEN_DRAWER":
      return { ...state, drawerOpen: true, drawerStep: "bag" };
    case "CLOSE_DRAWER":
      return { ...state, drawerOpen: false };
    case "SET_STEP":
      return { ...state, drawerStep: action.step };
    case "PLACE_ORDER":
      return {
        ...state,
        orderId: action.orderId,
        drawerStep: "done",
        bag: [],
        lastOrder: action.receipt,
      };
    case "RESET_ORDER":
      return { ...state, orderId: null, drawerStep: "bag", lastOrder: null };
    default:
      return state;
  }
}

interface StoreApi {
  state: State;
  setModel: (id: string) => void;
  setFinish: (id: string) => void;
  setStorage: (id: string) => void;
  toggleCare: () => void;
  addToBag: () => void;
  configureProduct: (id: string | null) => void;
  addCustomItem: (item: Omit<CartItem, "qty">) => void;
  updateQty: (key: string, qty: number) => void;
  removeItem: (key: string) => void;
  openDrawer: () => void;
  closeDrawer: () => void;
  setStep: (s: DrawerStep) => void;
  placeOrder: (receipt: ReceiptData) => void;
  resetOrder: () => void;
  bagCount: number;
  bagTotal: number;
  lastOrder: ReceiptData | null;
}

const StoreContext = createContext<StoreApi | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initial);

  const api = useMemo<StoreApi>(() => {
    const bagCount = state.bag.reduce((n, i) => n + i.qty, 0);
    const bagTotal = state.bag.reduce((n, i) => n + i.unitPrice * i.qty, 0);
    return {
      state,
      setModel: (id) => dispatch({ type: "SET_MODEL", modelId: id }),
      setFinish: (id) => dispatch({ type: "SET_FINISH", finishId: id }),
      setStorage: (id) => dispatch({ type: "SET_STORAGE", storageId: id }),
      toggleCare: () => dispatch({ type: "TOGGLE_CARE" }),
      addToBag: () => dispatch({ type: "ADD_CONFIGURED" }),
      configureProduct: (id) => dispatch({ type: "CONFIGURE_PRODUCT", productId: id }),
      addCustomItem: (item) => dispatch({ type: "ADD_ITEM", item }),
      updateQty: (key, qty) => dispatch({ type: "UPDATE_QTY", key, qty }),
      removeItem: (key) => dispatch({ type: "REMOVE_ITEM", key }),
      openDrawer: () => dispatch({ type: "OPEN_DRAWER" }),
      closeDrawer: () => dispatch({ type: "CLOSE_DRAWER" }),
      setStep: (s) => dispatch({ type: "SET_STEP", step: s }),
      placeOrder: (receipt) => dispatch({ type: "PLACE_ORDER", orderId: receipt.id, receipt }),
      resetOrder: () => dispatch({ type: "RESET_ORDER" }),
      bagCount,
      bagTotal,
      lastOrder: state.lastOrder,
    };
  }, [state]);

  return <StoreContext.Provider value={api}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
}

/** Convenience selector for the current configurator price */
export function useConfiguredPrice() {
  const { state } = useStore();
  return useCallback(
    () => priceFor(state.modelId, state.storageId) + (state.carePlus ? CARE_PLUS_PRICE : 0),
    [state.modelId, state.storageId, state.carePlus],
  )();
}
