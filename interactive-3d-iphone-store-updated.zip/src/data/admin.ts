import type { ComponentType } from "react";
import {
  BarChart3,
  Boxes,
  FileText,
  Megaphone,
  Package,
  Server,
  Shield,
  ShoppingCart,
  Tag,
  Users,
} from "lucide-react";

/**
 * Admin portal credentials. The portal is reachable ONLY through this
 * login — there is no other route into it.
 */
export const ADMIN_CREDENTIALS = {
  /** Canonical admin username (the email alias is also accepted) */
  username: "admin",
  alias: "admin@aura.store",
  password: "admin123",
};

export type AdminKind = "action" | "toggle" | "value";

export interface AdminCategory {
  id: string;
  label: string;
  icon: ComponentType<{ className?: string; strokeWidth?: number }>;
  blurb: string;
}

export interface AdminValueSpec {
  min: number;
  max: number;
  step: number;
  start: number;
  /** "%" or "h" or "u" render after the number; "$" renders before it */
  unit: string;
}

export interface AdminFunction {
  id: string;
  label: string;
  desc: string;
  category: string;
  kind: AdminKind;
  /** For toggle/value kinds: starting state */
  start?: boolean;
  value?: AdminValueSpec;
  /** Outcome reported in the activity log when an action runs */
  result?: string;
}

export const ADMIN_CATEGORIES: AdminCategory[] = [
  { id: "products", label: "Products", icon: Package, blurb: "Catalogue & merchandising" },
  { id: "inventory", label: "Inventory", icon: Boxes, blurb: "Stock & warehouses" },
  { id: "orders", label: "Orders", icon: ShoppingCart, blurb: "Fulfilment & returns" },
  { id: "customers", label: "Customers", icon: Users, blurb: "Accounts & support" },
  { id: "content", label: "Content", icon: FileText, blurb: "Site copy & pages" },
  { id: "pricing", label: "Pricing & Tax", icon: Tag, blurb: "Rates & shipping" },
  { id: "marketing", label: "Marketing", icon: Megaphone, blurb: "Campaigns & coupons" },
  { id: "security", label: "Security", icon: Shield, blurb: "Access & hardening" },
  { id: "analytics", label: "Analytics", icon: BarChart3, blurb: "Reports & tracking" },
  { id: "system", label: "System", icon: Server, blurb: "Maintenance & ops" },
];

export const ADMIN_FUNCTIONS: AdminFunction[] = [
  // ── Products (12) ─────────────────────────────────────────────────────────
  { id: "products.add", label: "Add product to catalogue", desc: "Create a new model entry with photos and pricing.", category: "products", kind: "action", result: "Draft product created and queued for review" },
  { id: "products.draft", label: "Create product draft", desc: "Start a blank draft without publishing.", category: "products", kind: "action", result: "Blank product draft saved" },
  { id: "products.featured", label: "Featured products", desc: "Pin the featured row to the Models section.", category: "products", kind: "toggle", start: true },
  { id: "products.price-round", label: "Round prices to .99", desc: "Normalize every catalogue price ending.", category: "products", kind: "action", result: "All prices rounded to .99 endings" },
  { id: "products.discount-5", label: "Apply 5% sitewide discount", desc: "Temporary markdown across the catalogue.", category: "products", kind: "action", result: "5% discount applied to 30 models" },
  { id: "products.discount-clear", label: "Clear all discounts", desc: "Remove every active markdown.", category: "products", kind: "action", result: "All product discounts cleared" },
  { id: "products.preorder", label: "Pre-order badges", desc: "Show pre-order flags on unreleased models.", category: "products", kind: "toggle", start: false },
  { id: "products.compare-at", label: "Compare-at pricing", desc: "Enforce strike-through compare pricing.", category: "products", kind: "toggle", start: true },
  { id: "products.revalidate", label: "Revalidate catalogue data", desc: "Re-check every product record.", category: "products", kind: "action", result: "Catalogue revalidated — 0 broken records" },
  { id: "products.reslug", label: "Regenerate product slugs", desc: "Rebuild SEO slugs from model names.", category: "products", kind: "action", result: "30 product slugs regenerated" },
  { id: "products.show-archived", label: "Show archived products", desc: "Include archived models in listings.", category: "products", kind: "toggle", start: false },
  { id: "products.image-audit", label: "Audit product imagery", desc: "Verify every model has an accurate photo.", category: "products", kind: "action", result: "Image audit passed — 30/30 models mapped" },

  // ── Inventory (12) ────────────────────────────────────────────────────────
  { id: "inventory.restock-all", label: "Restock all SKUs", desc: "Top up every SKU to target levels.", category: "inventory", kind: "action", result: "128 SKUs restocked across 2 warehouses" },
  { id: "inventory.low-stock", label: "Low-stock threshold", desc: "Units below this count trigger alerts.", category: "inventory", kind: "value", value: { min: 5, max: 50, step: 5, start: 10, unit: "u" } },
  { id: "inventory.backorders", label: "Allow backorders", desc: "Accept orders for out-of-stock units.", category: "inventory", kind: "toggle", start: false },
  { id: "inventory.sync-a", label: "Sync Warehouse A", desc: "Pull live counts from Warehouse A.", category: "inventory", kind: "action", result: "Warehouse A synced — 2,410 units" },
  { id: "inventory.sync-b", label: "Sync Warehouse B", desc: "Pull live counts from Warehouse B.", category: "inventory", kind: "action", result: "Warehouse B synced — 1,872 units" },
  { id: "inventory.reserve-drop", label: "Reserve stock for drop", desc: "Ring-fence units for the next launch.", category: "inventory", kind: "action", result: "500 units reserved for the next drop" },
  { id: "inventory.release-reservations", label: "Release reservations", desc: "Return ring-fenced units to stock.", category: "inventory", kind: "action", result: "All held reservations released" },
  { id: "inventory.mark-lost", label: "Mark lost units", desc: "Write off lost-in-transit inventory.", category: "inventory", kind: "action", result: "7 units written off as lost" },
  { id: "inventory.export-csv", label: "Export stock report", desc: "Generate the current stock CSV.", category: "inventory", kind: "action", result: "Stock report exported (128 rows)" },
  { id: "inventory.audit", label: "Run inventory audit", desc: "Reconcile counts against orders.", category: "inventory", kind: "action", result: "Audit complete — variance 0.2%" },
  { id: "inventory.auto-reorder", label: "Auto-reorder alerts", desc: "Email purchasing at the threshold.", category: "inventory", kind: "toggle", start: true },
  { id: "inventory.consignment", label: "Track consignment stock", desc: "Include partner consignment units.", category: "inventory", kind: "toggle", start: false },

  // ── Orders (14) ───────────────────────────────────────────────────────────
  { id: "orders.refresh-open", label: "Refresh open orders", desc: "Reload the open-order queue.", category: "orders", kind: "action", result: "Open-order queue refreshed — 42 open" },
  { id: "orders.mark-shipped", label: "Bulk-mark shipped", desc: "Mark all packed orders as shipped.", category: "orders", kind: "action", result: "18 packed orders marked as shipped" },
  { id: "orders.mark-delivered", label: "Bulk-mark delivered", desc: "Confirm delivery on arrived parcels.", category: "orders", kind: "action", result: "11 orders marked as delivered" },
  { id: "orders.cancel-flagged", label: "Cancel flagged orders", desc: "Cancel orders flagged by fraud scan.", category: "orders", kind: "action", result: "3 flagged orders cancelled" },
  { id: "orders.refunds", label: "Process pending refunds", desc: "Clear the refund backlog.", category: "orders", kind: "action", result: "5 refunds processed ($2,140)" },
  { id: "orders.return-restock", label: "Restock returns", desc: "Return inspected units to stock.", category: "orders", kind: "action", result: "9 returned units restocked" },
  { id: "orders.fraud-scan", label: "Run fraud scan", desc: "Score today's orders for risk.", category: "orders", kind: "action", result: "Fraud scan complete — 3 orders flagged" },
  { id: "orders.hold-high-value", label: "Hold high-value orders", desc: "Manual review above $2,000.", category: "orders", kind: "toggle", start: true },
  { id: "orders.auto-confirm", label: "Auto-confirm payments", desc: "Skip manual payment review.", category: "orders", kind: "toggle", start: true },
  { id: "orders.resend-emails", label: "Resend confirmations", desc: "Resend order confirmation emails.", category: "orders", kind: "action", result: "42 confirmation emails re-sent" },
  { id: "orders.packing-slips", label: "Generate packing slips", desc: "Print slips for the packed queue.", category: "orders", kind: "action", result: "18 packing slips generated" },
  { id: "orders.export-csv", label: "Export orders CSV", desc: "Download the orders ledger.", category: "orders", kind: "action", result: "Orders ledger exported (312 rows)" },
  { id: "orders.split-ship", label: "Split shipments", desc: "Ship multi-item orders separately.", category: "orders", kind: "toggle", start: false },
  { id: "orders.eta-recalc", label: "Recalculate delivery ETAs", desc: "Refresh ETAs from carrier feeds.", category: "orders", kind: "action", result: "ETAs recalculated for 42 open orders" },

  // ── Customers (12) ────────────────────────────────────────────────────────
  { id: "customers.sync-directory", label: "Sync customer directory", desc: "Rebuild the customer index.", category: "customers", kind: "action", result: "Customer directory synced — 1,204 profiles" },
  { id: "customers.promote-vip", label: "Promote top spenders to VIP", desc: "Grant VIP tier to the top 5%.", category: "customers", kind: "action", result: "60 customers promoted to VIP" },
  { id: "customers.ban-flagged", label: "Ban flagged accounts", desc: "Suspend abuse-flagged profiles.", category: "customers", kind: "action", result: "2 flagged accounts suspended" },
  { id: "customers.unban-appeals", label: "Restore appealed accounts", desc: "Reinstate approved appeals.", category: "customers", kind: "action", result: "1 account restored after appeal" },
  { id: "customers.verify-emails", label: "Verify pending emails", desc: "Re-send verification links.", category: "customers", kind: "action", result: "14 verification emails re-sent" },
  { id: "customers.password-resets", label: "Send password resets", desc: "Deliver reset links on request.", category: "customers", kind: "action", result: "6 password-reset links delivered" },
  { id: "customers.merge-dupes", label: "Merge duplicate accounts", desc: "Join profiles with matching emails.", category: "customers", kind: "action", result: "3 duplicate profiles merged" },
  { id: "customers.export-csv", label: "Export customer list", desc: "Download the customer CSV.", category: "customers", kind: "action", result: "Customer list exported (1,204 rows)" },
  { id: "customers.newsletter-default", label: "Newsletter opt-in default", desc: "Pre-check the marketing opt-in.", category: "customers", kind: "toggle", start: true },
  { id: "customers.remember-details", label: "Remember checkout details", desc: "Save name/email for faster checkout.", category: "customers", kind: "toggle", start: true },
  { id: "customers.welcome-flow", label: "Welcome email automation", desc: "Greet new accounts automatically.", category: "customers", kind: "toggle", start: true },
  { id: "customers.purge-inactive", label: "Purge inactive accounts", desc: "Remove accounts dormant 5+ years.", category: "customers", kind: "action", result: "12 dormant accounts purged" },

  // ── Content (12) ──────────────────────────────────────────────────────────
  { id: "content.hero-headline", label: "Refresh hero headline", desc: "Publish the latest hero copy.", category: "content", kind: "action", result: "Hero headline published" },
  { id: "content.hero-sub", label: "Update hero subtitle", desc: "Publish the supporting subtitle.", category: "content", kind: "action", result: "Hero subtitle published" },
  { id: "content.announcement", label: "Announcement bar", desc: "Show the top announcement strip.", category: "content", kind: "toggle", start: true },
  { id: "content.announcement-schedule", label: "Schedule announcement", desc: "Queue the next announcement.", category: "content", kind: "action", result: "Announcement scheduled for Friday 09:00" },
  { id: "content.marquee", label: "Marquee strip", desc: "Toggle the scrolling feature strip.", category: "content", kind: "toggle", start: true },
  { id: "content.catalogue-sync", label: "Sync picture catalogue", desc: "Refresh the embedded Drive catalogue.", category: "content", kind: "action", result: "Picture catalogue synced — 29 rows current" },
  { id: "content.catalogue-blurb", label: "Rewrite catalogue blurb", desc: "Refresh the catalogue intro copy.", category: "content", kind: "action", result: "Catalogue blurb rewritten" },
  { id: "content.footer-note", label: "Update footer note", desc: "Publish the footer disclaimer.", category: "content", kind: "action", result: "Footer note updated" },
  { id: "content.brand-story", label: "Publish brand story", desc: "Refresh the Craft section story.", category: "content", kind: "action", result: "Brand story published" },
  { id: "content.gallery-badges", label: "Model gallery badges", desc: "Show generation badges in the table.", category: "content", kind: "toggle", start: true },
  { id: "content.concept-tags", label: "Concept imagery tags", desc: "Tag concept renders in listings.", category: "content", kind: "toggle", start: true },
  { id: "content.seo", label: "Regenerate SEO metadata", desc: "Rebuild meta titles and descriptions.", category: "content", kind: "action", result: "SEO metadata regenerated for 8 pages" },

  // ── Pricing & Tax (10) ────────────────────────────────────────────────────
  { id: "pricing.tax-rate", label: "Tax rate", desc: "Sales-tax percentage at checkout.", category: "pricing", kind: "value", value: { min: 0, max: 25, step: 0.5, start: 8.5, unit: "%" } },
  { id: "pricing.vat-display", label: "VAT-inclusive prices", desc: "Display prices with tax included.", category: "pricing", kind: "toggle", start: false },
  { id: "pricing.currency-sync", label: "Sync currency rates", desc: "Pull today's FX reference rates.", category: "pricing", kind: "action", result: "Currency rates synced (12 pairs)" },
  { id: "pricing.free-shipping", label: "Free shipping", desc: "Free standard shipping sitewide.", category: "pricing", kind: "toggle", start: true },
  { id: "pricing.free-ship-threshold", label: "Free-shipping threshold", desc: "Order value that unlocks free shipping.", category: "pricing", kind: "value", value: { min: 50, max: 500, step: 50, start: 150, unit: "$" } },
  { id: "pricing.flat-rate", label: "Set flat shipping rate", desc: "Publish a flat standard rate.", category: "pricing", kind: "action", result: "Flat shipping rate set to $12" },
  { id: "pricing.student-discount", label: "Student discount program", desc: "Verify-and-save student pricing.", category: "pricing", kind: "toggle", start: true },
  { id: "pricing.seasonal-sale", label: "Launch seasonal sale", desc: "Start the seasonal promotion.", category: "pricing", kind: "action", result: "Seasonal sale launched — 10% off" },
  { id: "pricing.price-match", label: "Price-match guarantee", desc: "Honour competitor price matches.", category: "pricing", kind: "toggle", start: true },
  { id: "pricing.rounding", label: "Smart price rounding", desc: "Psychological price rounding rules.", category: "pricing", kind: "toggle", start: true },

  // ── Marketing (11) ────────────────────────────────────────────────────────
  { id: "marketing.coupon-batch", label: "Generate coupon batch", desc: "Create 100 single-use coupons.", category: "marketing", kind: "action", result: "100 single-use coupons generated" },
  { id: "marketing.coupon-expire", label: "Disable expired coupons", desc: "Revoke coupons past their date.", category: "marketing", kind: "action", result: "14 expired coupons disabled" },
  { id: "marketing.referral", label: "Referral program", desc: "Reward customers for referrals.", category: "marketing", kind: "toggle", start: true },
  { id: "marketing.referral-bonus", label: "Referral bonus", desc: "Credit granted per successful referral.", category: "marketing", kind: "value", value: { min: 5, max: 100, step: 5, start: 25, unit: "$" } },
  { id: "marketing.affiliates", label: "Affiliate program", desc: "Enable partner affiliate links.", category: "marketing", kind: "toggle", start: true },
  { id: "marketing.email-blast", label: "Schedule email blast", desc: "Queue the weekly campaign.", category: "marketing", kind: "action", result: "Email blast scheduled — 8,412 recipients" },
  { id: "marketing.push", label: "Send push notification", desc: "Ship the store-wide push alert.", category: "marketing", kind: "action", result: "Push notification sent to 3,204 devices" },
  { id: "marketing.reviews-feature", label: "Feature top reviews", desc: "Pin the highest-rated reviews.", category: "marketing", kind: "action", result: "12 top reviews featured" },
  { id: "marketing.reviews-hide", label: "Hide flagged reviews", desc: "Remove policy-violating reviews.", category: "marketing", kind: "action", result: "4 flagged reviews hidden" },
  { id: "marketing.giveaway", label: "Start giveaway campaign", desc: "Open the monthly giveaway.", category: "marketing", kind: "action", result: "Giveaway campaign opened" },
  { id: "marketing.abandoned-cart", label: "Abandoned-cart recovery", desc: "Email shoppers with idle bags.", category: "marketing", kind: "toggle", start: true },

  // ── Security (10) ─────────────────────────────────────────────────────────
  { id: "security.2fa-enforce", label: "Enforce 2FA for staff", desc: "Require a second factor for admins.", category: "security", kind: "toggle", start: true },
  { id: "security.force-logout", label: "Force-logout all users", desc: "Invalidate every active session.", category: "security", kind: "action", result: "All user sessions invalidated" },
  { id: "security.rotate-keys", label: "Rotate API keys", desc: "Issue fresh integration keys.", category: "security", kind: "action", result: "API keys rotated — 3 integrations updated" },
  { id: "security.maintenance", label: "Maintenance mode", desc: "Show the maintenance page to visitors.", category: "security", kind: "toggle", start: false },
  { id: "security.captcha", label: "Login captcha", desc: "Challenge suspicious sign-in attempts.", category: "security", kind: "toggle", start: true },
  { id: "security.block-ip", label: "Block suspicious IP", desc: "Add the top abusive IP to the blocklist.", category: "security", kind: "action", result: "Blocked 1 suspicious IP address" },
  { id: "security.clear-failed", label: "Clear failed-logins", desc: "Reset the failed-login counters.", category: "security", kind: "action", result: "Failed-login counters cleared" },
  { id: "security.audit-export", label: "Export security audit log", desc: "Download the access audit trail.", category: "security", kind: "action", result: "Security audit log exported (90 days)" },
  { id: "security.session-timeout", label: "Session timeout", desc: "Idle hours before a session expires.", category: "security", kind: "value", value: { min: 1, max: 48, step: 1, start: 12, unit: "h" } },
  { id: "security.rate-limit", label: "API rate limiting", desc: "Throttle abusive API clients.", category: "security", kind: "toggle", start: true },

  // ── Analytics (10) ────────────────────────────────────────────────────────
  { id: "analytics.refresh", label: "Refresh dashboards", desc: "Reload every analytics panel.", category: "analytics", kind: "action", result: "Dashboards refreshed" },
  { id: "analytics.sales-report", label: "Export sales report", desc: "Download the sales workbook.", category: "analytics", kind: "action", result: "Sales report exported (30 days)" },
  { id: "analytics.traffic-report", label: "Export traffic report", desc: "Download the traffic workbook.", category: "analytics", kind: "action", result: "Traffic report exported (30 days)" },
  { id: "analytics.funnel", label: "Rebuild conversion funnel", desc: "Recompute funnel stage counts.", category: "analytics", kind: "action", result: "Conversion funnel rebuilt" },
  { id: "analytics.realtime", label: "Realtime analytics", desc: "Live visitor stream on the dashboard.", category: "analytics", kind: "toggle", start: true },
  { id: "analytics.weekly-digest", label: "Generate weekly digest", desc: "Compile the weekly summary.", category: "analytics", kind: "action", result: "Weekly digest generated" },
  { id: "analytics.yoy", label: "Run YoY comparison", desc: "Compare against last year's numbers.", category: "analytics", kind: "action", result: "YoY comparison complete — revenue +18%" },
  { id: "analytics.clear-cache", label: "Clear analytics cache", desc: "Drop cached report snapshots.", category: "analytics", kind: "action", result: "Analytics cache cleared" },
  { id: "analytics.track-outbound", label: "Track outbound clicks", desc: "Record clicks to partner pages.", category: "analytics", kind: "toggle", start: true },
  { id: "analytics.consent-mode", label: "Consent-mode analytics", desc: "Respect visitor tracking consent.", category: "analytics", kind: "toggle", start: true },

  // ── System (12) ───────────────────────────────────────────────────────────
  { id: "system.cache-flush", label: "Flush application cache", desc: "Drop all application caches.", category: "system", kind: "action", result: "Application cache flushed" },
  { id: "system.reindex", label: "Rebuild search index", desc: "Re-index products and pages.", category: "system", kind: "action", result: "Search index rebuilt — 1,412 documents" },
  { id: "system.backup", label: "Run database backup", desc: "Snapshot the store database.", category: "system", kind: "action", result: "Database backup completed (2.4 GB)" },
  { id: "system.restore", label: "Restore latest backup", desc: "Roll back to the newest snapshot.", category: "system", kind: "action", result: "Latest backup restored" },
  { id: "system.health", label: "Run health check", desc: "Probe every service dependency.", category: "system", kind: "action", result: "Health check passed — 8/8 services green" },
  { id: "system.error-logs", label: "Export error logs", desc: "Download recent error records.", category: "system", kind: "action", result: "Error logs exported (48 entries)" },
  { id: "system.purge-logs", label: "Purge old logs", desc: "Delete log rows past retention.", category: "system", kind: "action", result: "Purged 12,400 expired log rows" },
  { id: "system.debug", label: "Debug mode", desc: "Verbose diagnostics on the site.", category: "system", kind: "toggle", start: false },
  { id: "system.updates", label: "Check for updates", desc: "Query the update channel.", category: "system", kind: "action", result: "Update check complete — running latest" },
  { id: "system.workers", label: "Restart background workers", desc: "Recycle the job queue workers.", category: "system", kind: "action", result: "Background workers restarted (4/4)" },
  { id: "system.cdn-purge", label: "Purge CDN cache", desc: "Invalidate cached edge assets.", category: "system", kind: "action", result: "CDN cache purged across 140 edge nodes" },
  { id: "system.migrations", label: "Dry-run migrations", desc: "Preview pending schema migrations.", category: "system", kind: "action", result: "Migration dry-run complete — 0 breaking changes" },
];

export const CATEGORY_BY_ID = new Map(ADMIN_CATEGORIES.map((c) => [c.id, c]));

export function formatValue(fn: AdminFunction, value: number): string {
  const unit = fn.value?.unit ?? "";
  return unit === "$" ? `$${value}` : `${value}${unit}`;
}
