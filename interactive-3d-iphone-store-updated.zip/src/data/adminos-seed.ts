/**
 * AdminOS development demonstration dataset.
 * Clearly marked demo data — never mix with production records.
 */

export interface Row { id: string; [k: string]: unknown }

const id = (p: string, n: number) => `${p}-${String(n).padStart(3, "0")}`;
const daysAgo = (n: number) => new Date(Date.now() - n * 864e5).toISOString();

export const SEED: Record<string, Row[]> = {
  users: [
    ["Ava Chen", "ava@demo.aura", "Active", "Super Administrator", "Executive", "yes"],
    ["Marco Ruiz", "marco@demo.aura", "Active", "Manager", "Sales", "yes"],
    ["Priya Nair", "priya@demo.aura", "Active", "Editor", "Marketing", "yes"],
    ["Jonas Weber", "jonas@demo.aura", "Suspended", "Analyst", "Finance", "no"],
    ["Lena Ortiz", "lena@demo.aura", "Active", "Auditor", "Compliance", "yes"],
    ["Sam Okafor", "sam@demo.aura", "Inactive", "Viewer", "Support", "no"],
    ["Yuki Tanaka", "yuki@demo.aura", "Active", "Administrator", "Engineering", "yes"],
    ["Nora Haddad", "nora@demo.aura", "Active", "Manager", "People Ops", "yes"],
    ["Theo Brandt", "theo@demo.aura", "Pending", "Viewer", "Sales", "no"],
    ["Ivy Laurent", "ivy@demo.aura", "Active", "Editor", "Content", "yes"],
  ].map((r, i) => ({ id: id("usr", i + 1), name: r[0], email: r[1], status: r[2], role: r[3], group: r[4], verified: r[5], created: daysAgo(120 - i * 7), lastLogin: daysAgo(i) })),

  roles: [
    ["Super Administrator", "Full system control", 48],
    ["Administrator", "Module administration", 36],
    ["Manager", "Team and approval control", 22],
    ["Editor", "Content and records editing", 14],
    ["Analyst", "Reporting and analytics", 9],
    ["Auditor", "Read-only compliance access", 7],
    ["Viewer", "Read-only access", 5],
  ].map((r, i) => ({ id: id("role", i + 1), name: r[0], desc: r[1], perms: r[2], users: [2, 3, 2, 2, 1, 1, 3][i], created: daysAgo(200 - i * 10) })),

  groups: [
    ["Executive", "Leadership team"], ["Sales", "Revenue org"], ["Marketing", "Growth org"],
    ["Finance", "Accounting"], ["Compliance", "Risk & audit"], ["Engineering", "Platform"],
    ["People Ops", "HR"], ["Support", "Customer care"], ["Content", "Editorial"],
  ].map((r, i) => ({ id: id("grp", i + 1), name: r[0], desc: r[1], members: 2 + (i % 5), created: daysAgo(180 - i * 9) })),

  records: [
    ["Acme rollout", "Project", "Active", "High"], ["Vendor onboarding", "Request", "In review", "Medium"],
    ["Data cleanup", "Task", "Active", "Low"], ["Policy update 2026-04", "Policy", "Draft", "High"],
    ["Hardware refresh", "Purchase", "Archived", "Medium"], ["Security review Q3", "Audit", "Active", "High"],
    ["Partner NDA", "Contract", "In review", "Medium"], ["Facility access", "Request", "Active", "Low"],
    ["Retention sweep", "Task", "Active", "Medium"], ["Locale rollout", "Project", "Draft", "Medium"],
    ["Badge replacement", "Request", "Archived", "Low"], ["Budget revision", "Finance", "In review", "High"],
  ].map((r, i) => ({ id: id("rec", i + 1), title: r[0], type: r[1], status: r[2], priority: r[3], owner: `usr-00${(i % 9) + 1}`, created: daysAgo(60 - i * 4), tags: ["demo", r[1].toLowerCase()] })),

  workflows: [
    ["Expense approval", "3-stage", "v3", "Active"], ["Access request", "2-stage", "v2", "Active"],
    ["Content publish", "2-stage", "v5", "Active"], ["Purchase order", "4-stage", "v1", "Draft"],
    ["Incident response", "parallel", "v2", "Active"],
  ].map((r, i) => ({ id: id("wf", i + 1), name: r[0], stages: r[1], version: r[2], status: r[3], runs: 12 + i * 7, created: daysAgo(90 - i * 6) })),

  approvals: [
    ["Expense approval", "Jonas Weber", 420, "Pending", 1], ["Access request", "Theo Brandt", 0, "Pending", 1],
    ["Purchase order", "Nora Haddad", 1890, "Pending", 2], ["Content publish", "Ivy Laurent", 0, "Approved", 1],
    ["Expense approval", "Priya Nair", 95, "Rejected", 1], ["Access request", "Sam Okafor", 0, "Approved", 2],
    ["Purchase order", "Marco Ruiz", 640, "Pending", 3],
  ].map((r, i) => ({ id: id("apr", i + 1), kind: r[0], requester: r[1], amount: r[2], status: r[3], stage: r[4], submitted: daysAgo(i + 1) })),

  tasks: [
    ["Review Q3 access", "Lena Ortiz", "High", "Open"], ["Publish pricing page", "Ivy Laurent", "Medium", "In progress"],
    ["Close duplicate records", "Marco Ruiz", "Low", "Open"], ["Rotate API keys", "Yuki Tanaka", "High", "Blocked"],
    ["Draft DR plan", "Ava Chen", "Medium", "In progress"], ["Onboard Theo", "Nora Haddad", "Medium", "Open"],
    ["Reconcile invoices", "Jonas Weber", "High", "Open"], ["Update FAQ", "Ivy Laurent", "Low", "Done"],
    ["Backup drill", "Yuki Tanaka", "High", "Open"], ["Escalate SLA breach", "Sam Okafor", "High", "In progress"],
  ].map((r, i) => ({ id: id("tsk", i + 1), title: r[0], assignee: r[1], priority: r[2], status: r[3], due: daysAgo(-3 + i), depends: i === 3 ? "tsk-001" : "" })),

  notifications: [
    ["Approval pending", "Expense approval APR-004 awaits review", "in-app", "Unread"],
    ["SLA breach risk", "Ticket TCK-002 breaches SLA in 2h", "in-app", "Unread"],
    ["Backup complete", "Nightly backup finished (2.4 GB)", "email", "Read"],
    ["New user created", "Theo Brandt joined as Viewer", "in-app", "Read"],
    ["Integration alert", "Webhook delivery failed (retry 2/5)", "push", "Unread"],
    ["Scheduled report", "Weekly digest generated", "email", "Archived"],
    ["Security notice", "3 failed admin logins blocked", "sms", "Read"],
    ["Retention notice", "12 records reach retention in 7 days", "in-app", "Unread"],
  ].map((r, i) => ({ id: id("ntf", i + 1), title: r[0], body: r[1], channel: r[2], status: r[3], at: daysAgo(i / 3) })),

  templates: [
    ["Welcome email", "email", "Hi {{name}}, welcome to {{org}}."],
    ["Approval request", "in-app", "{{requester}} submitted {{kind}} for review."],
    ["SLA warning", "sms", "Ticket {{id}} breaches SLA in {{hours}}h."],
    ["Report ready", "email", "Your report {{report}} is ready to download."],
    ["Password reset", "email", "Reset your password: {{link}} (expires in 30 min)."],
  ].map((r, i) => ({ id: id("tpl", i + 1), name: r[0], channel: r[1], body: r[2], active: i !== 3 })),

  invoices: [
    ["INV-2026-041", "Acme Corp", 2400, "Paid"], ["INV-2026-042", "Globex", 1150, "Issued"],
    ["INV-2026-043", "Initech", 480, "Draft"], ["INV-2026-044", "Umbrella", 3200, "Overdue"],
    ["INV-2026-045", "Stark Ltd", 890, "Paid"], ["INV-2026-046", "Wayne Co", 1740, "Issued"],
    ["INV-2026-047", "Acme Corp", 560, "Cancelled"], ["INV-2026-048", "Hooli", 2100, "Paid"],
  ].map((r, i) => ({ id: id("inv", i + 1), number: r[0], customer: r[1], total: r[2], status: r[3], due: daysAgo(-(5 + i * 3)), created: daysAgo(20 - i * 2) })),

  transactions: [
    ["Payment", "Acme Corp", 2400, "Settled"], ["Payment", "Stark Ltd", 890, "Settled"],
    ["Refund", "Wayne Co", -120, "Settled"], ["Payment", "Hooli", 2100, "Settled"],
    ["Expense", "Cloud hosting", -340, "Cleared"], ["Expense", "Office supplies", -85, "Cleared"],
    ["Payment", "Globex", 1150, "Pending"], ["Income", "Affiliate payout", 260, "Settled"],
    ["Expense", "Payroll", -4600, "Cleared"], ["Payment", "Umbrella", 3200, "Overdue"],
  ].map((r, i) => ({ id: id("txn", i + 1), kind: r[0], party: r[1], amount: r[2], status: r[3], at: daysAgo(14 - i * 1.2) })),

  expenses: [
    ["Cloud hosting", "Infrastructure", 340, "Approved"], ["Conference booth", "Marketing", 1800, "Pending"],
    ["Office supplies", "Operations", 85, "Approved"], ["Team offsite", "People Ops", 2400, "Rejected"],
    ["Audit software", "Compliance", 990, "Approved"], ["Ad campaign", "Marketing", 1250, "Pending"],
  ].map((r, i) => ({ id: id("exp", i + 1), title: r[0], category: r[1], amount: r[2], status: r[3], at: daysAgo(30 - i * 5) })),

  budgets: [
    ["Marketing Q4", 12000, 8400], ["Infrastructure", 9000, 8700], ["People Ops", 20000, 11200], ["Compliance", 6000, 2100],
  ].map((r, i) => ({ id: id("bdg", i + 1), name: r[0], allocated: r[1], spent: r[2], period: "2026-Q4" })),

  documents: [
    ["Security Policy v4", "Policy", "Published", 182342], ["Employee Handbook", "Guide", "Published", 2410022],
    ["DR Plan draft", "Plan", "Draft", 340211], ["Vendor MSA", "Contract", "In review", 88341],
    ["Retention Schedule", "Policy", "Published", 120442], ["Onboarding Checklist", "Template", "Published", 42100],
    ["Incident Report 2026-03", "Report", "Archived", 98221], ["API Style Guide", "Guide", "Published", 210883],
  ].map((r, i) => ({ id: id("doc", i + 1), title: r[0], type: r[1], status: r[2], size: r[3], version: 1 + (i % 4), owner: `usr-00${(i % 6) + 1}`, expires: daysAgo(-(30 + i * 10)), created: daysAgo(80 - i * 6) })),

  pages: [
    ["Service status page", "Published"], ["Acceptable use policy", "Published"],
    ["Q4 maintenance notice", "Scheduled"], ["Release notes 2026-10", "Draft"],
  ].map((r, i) => ({ id: id("pg", i + 1), title: r[0], status: r[1], revisions: 2 + i, updated: daysAgo(i * 4) })),

  integrations: [
    ["Stripe Payments", "payment", "Connected", "simulated"], ["SendGrid Email", "email", "Connected", "simulated"],
    ["Twilio SMS", "sms", "Degraded", "simulated"], ["Okta SSO", "auth", "Configured", "external"],
    ["Slack Alerts", "chat", "Connected", "simulated"], ["Google Drive", "storage", "Connected", "simulated"],
    ["HubSpot CRM", "crm", "Disconnected", "simulated"], ["Datadog APM", "monitoring", "Connected", "simulated"],
  ].map((r, i) => ({ id: id("int", i + 1), name: r[0], kind: r[1], status: r[2], mode: r[3], lastSync: daysAgo(i / 2) })),

  webhooks: [
    ["Invoice events", "invoice.*", "https://hooks.demo.aura/inv", "Active"],
    ["User lifecycle", "user.created,user.updated", "https://hooks.demo.aura/usr", "Active"],
    ["Security alerts", "security.*", "https://hooks.demo.aura/sec", "Paused"],
  ].map((r, i) => ({ id: id("wh", i + 1), name: r[0], events: r[1], url: r[2], status: r[3], deliveries: 120 + i * 43, failures: i * 2 })),

  apiKeys: [
    ["Production key", "read write", "2027-01-01"], ["Analytics reader", "read", "2026-12-01"], ["CI automation", "read write admin", "2026-11-01"],
  ].map((r, i) => ({ id: id("key", i + 1), name: r[0], scopes: r[1], expires: r[2], fingerprint: `sk_live_••••${(4821 + i * 173)}`, status: i === 2 ? "Expiring" : "Active" })),

  automations: [
    ["Overdue task reminder", "schedule", "Active", 46], ["Auto-assign sales requests", "record.created", "Active", 132],
    ["Duplicate flagging", "record.created", "Active", 28], ["SLA escalation", "ticket.overdue", "Paused", 17],
    ["Weekly report", "schedule", "Active", 12], ["Welcome sequence", "user.created", "Active", 23],
  ].map((r, i) => ({ id: id("auto", i + 1), name: r[0], trigger: r[1], status: r[2], runs: r[3], lastRun: daysAgo(i / 3) })),

  jobs: [
    ["nightly-backup", "Completed", 240], ["report-weekly", "Completed", 12], ["sync-hubspot", "Queued", 0],
    ["import-users-batch2", "Running", 3], ["webhook-retry", "Failed", 6], ["retention-sweep", "Queued", 0],
  ].map((r, i) => ({ id: id("job", i + 1), type: r[0], status: r[1], retries: r[2], enqueued: daysAgo(i / 4) })),

  tickets: [
    ["Cannot export invoices", "High", "Open", "Sam Okafor"], ["SSO login loop", "Critical", "Escalated", "Yuki Tanaka"],
    ["Add user to group", "Low", "Resolved", "Nora Haddad"], ["Report totals off", "Medium", "Open", "Marco Ruiz"],
    ["Webhook retries", "Medium", "In progress", "Yuki Tanaka"], ["Password reset help", "Low", "Resolved", "Sam Okafor"],
  ].map((r, i) => ({ id: id("tck", i + 1), title: r[0], priority: r[1], status: r[2], owner: r[3], opened: daysAgo(i * 1.5) })),

  kb: [
    ["How to request access", "Access", "Published"], ["Invoice approval guide", "Finance", "Published"],
    ["Backup & restore runbook", "System", "Published"], ["Writing an incident report", "Security", "Draft"],
    ["Onboarding steps", "People Ops", "Published"],
  ].map((r, i) => ({ id: id("kb", i + 1), title: r[0], category: r[1], status: r[2], views: 40 + i * 17 })),

  faq: [
    ["How do I reset my password?", "Use the recovery link at the login gate.", "Accounts", "Published"],
    ["How do exports work?", "Exports stream as CSV from the export center.", "Data", "Published"],
    ["Are payments real?", "No — the payment gateway is an explicit simulation.", "Finance", "Published"],
    ["Who can approve refunds?", "Roles with finance.approve (Manager+).", "Finance", "Published"],
  ].map((r, i) => ({ id: id("faq", i + 1), q: r[0], a: r[1], category: r[2], status: r[3] })),

  feedback: [
    ["Great dashboard widgets", "Love the new layout.", "New", 5], ["CSV import needs mapping preview", "Please add a preview step.", "Reviewing", 4],
    ["Dark mode contrast", "Some panels are low-contrast.", "Actioned", 3],
  ].map((r, i) => ({ id: id("fb", i + 1), title: r[0], body: r[1], status: r[2], score: r[3] })),

  sessions: [
    ["Ava Chen", "Chrome · macOS", "102.22.4.9", "Active"], ["Yuki Tanaka", "Safari · iOS", "41.89.1.22", "Active"],
    ["Jonas Weber", "Firefox · Windows", "88.12.9.41", "Revoked"],
  ].map((r, i) => ({ id: id("ses", i + 1), user: r[0], device: r[1], ip: r[2], status: r[3], lastSeen: daysAgo(i / 5) })),

  loginHistory: [
    ["Ava Chen", "Success", "102.22.4.9"], ["Yuki Tanaka", "Success", "41.89.1.22"],
    ["unknown", "Failed", "198.51.100.7"], ["unknown", "Failed", "198.51.100.7"], ["Priya Nair", "Success", "64.9.2.11"],
    ["Jonas Weber", "Failed", "88.12.9.41"],
  ].map((r, i) => ({ id: id("lg", i + 1), user: r[0], outcome: r[1], ip: r[2], at: daysAgo(i / 6) })),

  securityEvents: [
    ["Brute-force attempt", "198.51.100.7", "High"], ["Unusual export volume", "marco@demo.aura", "Medium"],
    ["Permission change", "ava@demo.aura", "Low"], ["Expired API key used", "CI automation", "High"],
  ].map((r, i) => ({ id: id("se", i + 1), kind: r[0], actor: r[1], severity: r[2], at: daysAgo(i * 1.3) })),

  audit: [
    ["Ava Chen", "user.create", "usr-010"], ["Ava Chen", "role.assign", "role-004"],
    ["Yuki Tanaka", "backup.run", "system"], ["Marco Ruiz", "invoice.issue", "inv-002"],
    ["Lena Ortiz", "audit.export", "audit"], ["Nora Haddad", "group.create", "grp-009"],
    ["system", "job.failed", "job-005"], ["Ava Chen", "flag.set", "mfa.required"],
    ["Ivy Laurent", "page.publish", "pg-001"], ["system", "retention.notice", "records"],
  ].map((r, i) => ({ id: id("aud", i + 1), actor: r[0], action: r[1], resource: r[2], at: daysAgo(i / 2), before: i % 3 === 0 ? '{"status":"Draft"}' : "", after: i % 3 === 0 ? '{"status":"Published"}' : "" })),

  privacyRequests: [
    ["Data export", "Subject 4471", "In review"], ["Deletion", "Subject 2210", "Approved"], ["Correction", "Subject 8812", "New"],
  ].map((r, i) => ({ id: id("pr", i + 1), kind: r[0], subject: r[1], status: r[2], received: daysAgo(i * 4 + 2) })),

  complianceTasks: [
    ["Q3 access review", "Lena Ortiz", "Open", "2026-11-01"], ["Retention attestation", "Ava Chen", "Done", "2026-10-15"],
    ["Vendor risk refresh", "Nora Haddad", "In progress", "2026-11-10"], ["Policy acknowledgment", "All staff", "Open", "2026-11-20"],
  ].map((r, i) => ({ id: id("ct", i + 1), title: r[0], owner: r[1], status: r[2], due: r[3] })),

  kpis: [
    ["Monthly revenue", 50000, 46200, "$"], ["Active users", 1200, 1204, ""],
    ["Open tickets < 24h", 10, 6, ""], ["SLA compliance", 95, 97, "%"],
  ].map((r, i) => ({ id: id("kpi", i + 1), name: r[0], target: r[1], actual: r[2], unit: r[3], period: "2026-10" })),

  savedViews: [
    ["High-priority records", "records", "priority=High"], ["Unpaid invoices", "invoices", "status!=Paid"],
    ["Suspended users", "users", "status=Suspended"],
  ].map((r, i) => ({ id: id("sv", i + 1), name: r[0], dataset: r[1], filter: r[2], owner: "usr-001" })),

  announcements: [
    ["Scheduled maintenance Sat 02:00 UTC", "Active"], ["New expense workflow live", "Active"], ["Welcome Theo Brandt", "Archived"],
  ].map((r, i) => ({ id: id("ann", i + 1), title: r[0], status: r[1], at: daysAgo(i * 5) })),

  migrations: [
    ["2026_10_01_add_retention", "Applied"], ["2026_10_12_invoice_index", "Applied"], ["2026_10_20_consent_tables", "Pending"],
  ].map((r, i) => ({ id: id("mig", i + 1), name: r[0], status: r[1], at: daysAgo(i * 8) })),

  backups: [
    ["nightly-2026-10-22", "2.4 GB", "Verified"], ["nightly-2026-10-21", "2.4 GB", "Verified"], ["weekly-2026-10-18", "2.3 GB", "Verified"],
  ].map((r, i) => ({ id: id("bak", i + 1), name: r[0], size: r[1], status: r[2], at: daysAgo(i + 1) })),

  devices: [
    ["MacBook Pro · Chrome", "Ava Chen", "Trusted"], ["iPhone 15 · Safari", "Yuki Tanaka", "Trusted"], ["Windows PC · Firefox", "Jonas Weber", "Blocked"],
  ].map((r, i) => ({ id: id("dev", i + 1), name: r[0], user: r[1], trust: r[2] })),

  ipRules: [
    ["198.51.100.7", "Blocked"], ["10.0.0.0/8", "Allowed"], ["203.0.113.0/24", "Allowed"],
  ].map((r, i) => ({ id: id("ip", i + 1), cidr: r[0], rule: r[1] })),

  incidents: [
    ["Brute-force campaign", "Investigating", "Yuki Tanaka"], ["Webhook secret leak drill", "Closed", "Ava Chen"],
  ].map((r, i) => ({ id: id("inc", i + 1), title: r[0], status: r[1], owner: r[2], opened: daysAgo(i * 6 + 1) })),

  recordTypes: [
    ["Project", "Custom"], ["Request", "Custom"], ["Contract", "Custom"],
  ].map((r, i) => ({ id: id("rt", i + 1), name: r[0], kind: r[1] })),

  fields: [
    ["Cost center", "text"], ["Effective date", "date"], ["Requires approval", "boolean"], ["Risk level", "dropdown"],
  ].map((r, i) => ({ id: id("fld", i + 1), name: r[0], type: r[1], required: i === 2 })),

  onboarding: [
    ["Complete profile", 1], ["Sign policy", 1], ["Setup MFA", 1], ["Meet the team", 0], ["First task", 0],
  ].map((r, i) => ({ id: id("onb", i + 1), step: r[0], done: r[1] })),
};

export const DEMO_NOTICE = "Demo dataset — development only. Simulated integrations are labeled; no real payments, emails or SMS are sent.";
