export type Category = "iphone" | "watch" | "mac" | "ipad" | "accessory";
export type CameraLayout = "dual" | "diag" | "triple" | "bar";
export type TileKind =
  | "phone"
  | "watch"
  | "mac"
  | "ipad"
  | "pods"
  | "speaker"
  | "pencil"
  | "puck"
  | "tag"
  | "keyboard";

export interface CatalogProduct {
  id: string;
  name: string;
  category: Category;
  generation?: number;
  year?: number;
  price: number;
  chip: string;
  info: string;
  colors: string[];
  colorNames: string[];
  tile: TileKind;
  camera?: CameraLayout;
  condition: "New" | "Certified Renewed" | "Concept";
  /** Real product photo (shown instead of the drawn tile when present) */
  image?: string;
}

/* ---------------------------------------------------------------
   iPhone lineage — 11 through 18, every variant
---------------------------------------------------------------- */

interface GenModel {
  suffix: string;
  price: number;
  camera: CameraLayout;
  size: string;
  colors: [string, string][];
}

interface Gen {
  gen: number;
  year: number;
  chip: string;
  proChip?: string;
  condition: CatalogProduct["condition"];
  models: GenModel[];
}

const GENS: Gen[] = [
  {
    gen: 11, year: 2019, chip: "A13 Bionic", condition: "Certified Renewed",
    models: [
      { suffix: "iPhone 11", price: 279, camera: "dual", size: "6.1″", colors: [["#2b2b2f", "Black"], ["#f5f2ea", "White"], ["#cdc3d9", "Purple"], ["#b7e2cd", "Green"]] },
      { suffix: "iPhone 11 Pro", price: 359, camera: "triple", size: "5.8″", colors: [["#3a463c", "Midnight Green"], ["#53524f", "Space Gray"], ["#ebebe8", "Silver"]] },
      { suffix: "iPhone 11 Pro Max", price: 429, camera: "triple", size: "6.5″", colors: [["#53524f", "Space Gray"], ["#ebebe8", "Silver"], ["#f5dfc8", "Gold"]] },
    ],
  },
  {
    gen: 12, year: 2020, chip: "A14 Bionic", condition: "Certified Renewed",
    models: [
      { suffix: "iPhone 12 mini", price: 299, camera: "dual", size: "5.4″", colors: [["#2b2b2f", "Black"], ["#f5f2ea", "White"], ["#beb3d7", "Purple"]] },
      { suffix: "iPhone 12", price: 349, camera: "dual", size: "6.1″", colors: [["#2e4a63", "Blue"], ["#2b2b2f", "Black"], ["#f5f2ea", "White"], ["#c3313a", "PRODUCT(RED)"]] },
      { suffix: "iPhone 12 Pro", price: 439, camera: "triple", size: "6.1″", colors: [["#33495e", "Pacific Blue"], ["#44423f", "Graphite"], ["#f2dcc4", "Gold"]] },
      { suffix: "iPhone 12 Pro Max", price: 529, camera: "triple", size: "6.7″", colors: [["#33495e", "Pacific Blue"], ["#ebebe8", "Silver"], ["#44423f", "Graphite"]] },
    ],
  },
  {
    gen: 13, year: 2021, chip: "A15 Bionic", condition: "Certified Renewed",
    models: [
      { suffix: "iPhone 13 mini", price: 379, camera: "diag", size: "5.4″", colors: [["#f6ced8", "Pink"], ["#f3ede3", "Starlight"], ["#272b31", "Midnight"]] },
      { suffix: "iPhone 13", price: 429, camera: "diag", size: "6.1″", colors: [["#334e68", "Blue"], ["#f6ced8", "Pink"], ["#42584d", "Green"], ["#f3ede3", "Starlight"]] },
      { suffix: "iPhone 13 Pro", price: 549, camera: "triple", size: "6.1″", colors: [["#a7c1d9", "Sierra Blue"], ["#505f52", "Alpine Green"], ["#44423f", "Graphite"]] },
      { suffix: "iPhone 13 Pro Max", price: 649, camera: "triple", size: "6.7″", colors: [["#a7c1d9", "Sierra Blue"], ["#ebebe8", "Silver"], ["#f2dcc4", "Gold"]] },
    ],
  },
  {
    gen: 14, year: 2022, chip: "A15 Bionic", proChip: "A16 Bionic", condition: "Certified Renewed",
    models: [
      { suffix: "iPhone 14", price: 429, camera: "diag", size: "6.1″", colors: [["#a3b8cc", "Blue"], ["#c8bcd4", "Purple"], ["#f3ede3", "Starlight"], ["#272b31", "Midnight"]] },
      { suffix: "iPhone 14 Plus", price: 529, camera: "diag", size: "6.7″", colors: [["#f3e2a2", "Yellow"], ["#a3b8cc", "Blue"], ["#f3ede3", "Starlight"]] },
      { suffix: "iPhone 14 Pro", price: 629, camera: "triple", size: "6.1″", colors: [["#63506b", "Deep Purple"], ["#f2e3ce", "Gold"], ["#3f3a38", "Space Black"]] },
      { suffix: "iPhone 14 Pro Max", price: 729, camera: "triple", size: "6.7″", colors: [["#63506b", "Deep Purple"], ["#ebebe8", "Silver"], ["#3f3a38", "Space Black"]] },
    ],
  },
  {
    gen: 15, year: 2023, chip: "A16 Bionic", proChip: "A17 Pro", condition: "New",
    models: [
      { suffix: "iPhone 15", price: 599, camera: "diag", size: "6.1″", colors: [["#eccfd1", "Pink"], ["#ccd6dc", "Blue"], ["#ccdcc4", "Green"], ["#373c40", "Black"]] },
      { suffix: "iPhone 15 Plus", price: 699, camera: "diag", size: "6.7″", colors: [["#efe3ac", "Yellow"], ["#eccfd1", "Pink"], ["#373c40", "Black"]] },
      { suffix: "iPhone 15 Pro", price: 799, camera: "triple", size: "6.1″", colors: [["#8d867d", "Natural Titanium"], ["#3c4551", "Blue Titanium"], ["#e8e6e0", "White Titanium"]] },
      { suffix: "iPhone 15 Pro Max", price: 899, camera: "triple", size: "6.7″", colors: [["#8d867d", "Natural Titanium"], ["#44423f", "Black Titanium"], ["#3c4551", "Blue Titanium"]] },
    ],
  },
  {
    gen: 16, year: 2024, chip: "A18", proChip: "A18 Pro", condition: "New",
    models: [
      { suffix: "iPhone 16", price: 699, camera: "dual", size: "6.1″", colors: [["#97a4c6", "Ultramarine"], ["#aebfc6", "Teal"], ["#e8b9c3", "Pink"], ["#3e4043", "Black"]] },
      { suffix: "iPhone 16 Plus", price: 799, camera: "dual", size: "6.7″", colors: [["#97a4c6", "Ultramarine"], ["#f3f2ec", "White"], ["#e8b9c3", "Pink"]] },
      { suffix: "iPhone 16 Pro", price: 899, camera: "triple", size: "6.3″", colors: [["#bfa48f", "Desert Titanium"], ["#8d867d", "Natural Titanium"], ["#44423f", "Black Titanium"]] },
      { suffix: "iPhone 16 Pro Max", price: 999, camera: "triple", size: "6.9″", colors: [["#bfa48f", "Desert Titanium"], ["#e8e6e0", "White Titanium"], ["#8d867d", "Natural Titanium"]] },
    ],
  },
  {
    gen: 17, year: 2025, chip: "A19", proChip: "A19 Pro", condition: "New",
    models: [
      { suffix: "iPhone 17", price: 799, camera: "dual", size: "6.3″", colors: [["#c6bcd9", "Lavender"], ["#b7c4ab", "Sage"], ["#aec2d6", "Mist Blue"], ["#2e2e33", "Black"]] },
      { suffix: "iPhone Air", price: 999, camera: "bar", size: "6.5″", colors: [["#e6d8c0", "Light Gold"], ["#bcd4e8", "Sky Blue"], ["#34353b", "Space Black"]] },
      { suffix: "iPhone 17 Pro", price: 1099, camera: "triple", size: "6.3″", colors: [["#d97a3a", "Cosmic Orange"], ["#3d4b66", "Deep Blue"], ["#e3e4e8", "Silver"]] },
      { suffix: "iPhone 17 Pro Max", price: 1199, camera: "triple", size: "6.9″", colors: [["#d97a3a", "Cosmic Orange"], ["#3d4b66", "Deep Blue"], ["#e3e4e8", "Silver"]] },
    ],
  },
  {
    gen: 18, year: 2026, chip: "A20", proChip: "A20 Pro", condition: "Concept",
    models: [
      { suffix: "iPhone 18", price: 849, camera: "dual", size: "6.3″", colors: [["#f0eff4", "Aurora White"], ["#6a5fd0", "Nebula Violet"], ["#2c2c31", "Graphite"]] },
      { suffix: "iPhone 18 Pro", price: 1149, camera: "triple", size: "6.3″", colors: [["#b9713f", "Solar Copper"], ["#ece9e3", "Pearl"], ["#2e2f35", "Graphite"]] },
      { suffix: "iPhone 18 Pro Max", price: 1299, camera: "triple", size: "6.9″", colors: [["#b9713f", "Solar Copper"], ["#6a5fd0", "Nebula Violet"], ["#ece9e3", "Pearl"]] },
    ],
  },
];

/* Real product photos, one per iPhone model (public/img/catalog).
   Sourced per the iPhone Picture Catalogue model list — each photo sits
   on its own model card so the right device shows in the right slot. */
export const IPHONE_IMAGES: Record<string, string> = {
  "iphone-11": "/img/catalog/iphone-11.png",
  "iphone-11-pro": "/img/catalog/iphone-11-pro.jpg",
  "iphone-11-pro-max": "/img/catalog/iphone-11-pro-max.webp",
  "iphone-12-mini": "/img/catalog/iphone-12-mini.jpg",
  "iphone-12": "/img/catalog/iphone-12.jpg",
  "iphone-12-pro": "/img/catalog/iphone-12-pro.jpg",
  "iphone-12-pro-max": "/img/catalog/iphone-12-pro-max.webp",
  "iphone-13-mini": "/img/catalog/iphone-13-mini.jpg",
  "iphone-13": "/img/catalog/iphone-13.jpg",
  "iphone-13-pro": "/img/catalog/iphone-13-pro.webp",
  "iphone-13-pro-max": "/img/catalog/iphone-13-pro-max.png",
  "iphone-14": "/img/catalog/iphone-14.jpg",
  "iphone-14-plus": "/img/catalog/iphone-14-plus.jpg",
  "iphone-14-pro": "/img/catalog/iphone-14-pro.jpg",
  "iphone-14-pro-max": "/img/catalog/iphone-14-pro-max.jpg",
  "iphone-15": "/img/catalog/iphone-15.jpg",
  "iphone-15-plus": "/img/catalog/iphone-15-plus.jpg",
  "iphone-15-pro": "/img/catalog/iphone-15-pro.jpg",
  "iphone-15-pro-max": "/img/catalog/iphone-15-pro-max.webp",
  "iphone-16": "/img/catalog/iphone-16.png",
  "iphone-16-plus": "/img/catalog/iphone-16-plus.webp",
  "iphone-16-pro": "/img/catalog/iphone-16-pro.webp",
  "iphone-16-pro-max": "/img/catalog/iphone-16-pro-max.webp",
  "iphone-17": "/img/catalog/iphone-17.png",
  "iphone-air": "/img/catalog/iphone-air.webp",
  "iphone-17-pro": "/img/catalog/iphone-17-pro.webp",
  "iphone-17-pro-max": "/img/catalog/iphone-17-pro-max.png",
  "iphone-18": "/img/catalog/iphone-18.jpg",
  "iphone-18-pro": "/img/catalog/iphone-18-pro.png",
  "iphone-18-pro-max": "/img/catalog/iphone-18-pro-max.png",
};

export const IPHONES: CatalogProduct[] = GENS.flatMap((g) =>
  g.models.map((m) => {
    const isPro = m.suffix.includes("Pro");
    const id = m.suffix.toLowerCase().replace(/\s+/g, "-");
    return {
      id,
      name: m.suffix,
      category: "iphone" as const,
      generation: g.gen,
      year: g.year,
      price: m.price,
      chip: isPro && g.proChip ? g.proChip : g.chip,
      info: `${m.size} display`,
      colors: m.colors.map((c) => c[0]),
      colorNames: m.colors.map((c) => c[1]),
      tile: "phone" as const,
      camera: m.camera,
      condition: g.condition,
      image: IPHONE_IMAGES[id],
    };
  }),
);

/* ---------------------------------------------------------------
   Watches, Macs, iPads, accessories
---------------------------------------------------------------- */

export const GEAR: CatalogProduct[] = [
  { id: "watch-ultra-3", name: "Apple Watch Ultra 3", category: "watch", price: 799, chip: "S10 SiP", info: "49mm titanium · 42-hr battery", colors: ["#c8b89a", "#3c3b3a"], colorNames: ["Natural Titanium", "Black Titanium"], tile: "watch", condition: "New" },
  { id: "watch-series-11", name: "Apple Watch Series 11", category: "watch", price: 399, chip: "S10 SiP", info: "42 / 46mm · 5G", colors: ["#2a2b30", "#d9a58c", "#e8e6e1"], colorNames: ["Jet Black", "Rose Gold", "Silver"], tile: "watch", condition: "New" },
  { id: "watch-se-3", name: "Apple Watch SE 3", category: "watch", price: 249, chip: "S10 SiP", info: "40 / 44mm · Always-On", colors: ["#31313a", "#f2ecdd"], colorNames: ["Midnight", "Starlight"], tile: "watch", condition: "New" },
  { id: "macbook-air-13", name: "MacBook Air 13″", category: "mac", price: 999, chip: "M4", info: "16GB · 256GB · 18-hr battery", colors: ["#bcd6ea", "#2e3642", "#efe9dd", "#e3e4e6"], colorNames: ["Sky Blue", "Midnight", "Starlight", "Silver"], tile: "mac", condition: "New" },
  { id: "macbook-air-15", name: "MacBook Air 15″", category: "mac", price: 1199, chip: "M4", info: "16GB · 256GB · 18-hr battery", colors: ["#2e3642", "#bcd6ea"], colorNames: ["Midnight", "Sky Blue"], tile: "mac", condition: "New" },
  { id: "macbook-pro-14", name: "MacBook Pro 14″", category: "mac", price: 1999, chip: "M4 Pro", info: "24GB · 512GB · 120Hz XDR", colors: ["#33353a", "#e5e5e7"], colorNames: ["Space Black", "Silver"], tile: "mac", condition: "New" },
  { id: "macbook-pro-16", name: "MacBook Pro 16″", category: "mac", price: 3199, chip: "M4 Max", info: "36GB · 1TB · 120Hz XDR", colors: ["#33353a", "#e5e5e7"], colorNames: ["Space Black", "Silver"], tile: "mac", condition: "New" },
  { id: "ipad-a16", name: "iPad", category: "ipad", price: 349, chip: "A16", info: "11″ Liquid Retina · 128GB", colors: ["#a9c1e0", "#f2c8d3", "#f5e6a8", "#e5e5e7"], colorNames: ["Blue", "Pink", "Yellow", "Silver"], tile: "ipad", condition: "New" },
  { id: "ipad-mini", name: "iPad mini", category: "ipad", price: 499, chip: "A17 Pro", info: "8.3″ Liquid Retina · 128GB", colors: ["#5f5c66", "#a9c1e0", "#c6b8d9", "#f2ecdd"], colorNames: ["Space Gray", "Blue", "Purple", "Starlight"], tile: "ipad", condition: "New" },
  { id: "ipad-air-11", name: "iPad Air 11″", category: "ipad", price: 599, chip: "M3", info: "Liquid Retina · 128GB", colors: ["#5f5c66", "#a9c1e0", "#c6b8d9"], colorNames: ["Space Gray", "Blue", "Purple"], tile: "ipad", condition: "New" },
  { id: "ipad-air-13", name: "iPad Air 13″", category: "ipad", price: 799, chip: "M3", info: "Liquid Retina · 128GB", colors: ["#5f5c66", "#f2ecdd"], colorNames: ["Space Gray", "Starlight"], tile: "ipad", condition: "New" },
  { id: "ipad-pro-13", name: "iPad Pro 13″", category: "ipad", price: 1299, chip: "M4", info: "Tandem OLED · 256GB · 5.1mm", colors: ["#3a3b40", "#e5e5e7"], colorNames: ["Space Black", "Silver"], tile: "ipad", condition: "New" },
  { id: "airpods-pro-3", name: "AirPods Pro 3", category: "accessory", price: 249, chip: "H2", info: "2× ANC · heart-rate sensing", colors: ["#f4f4f6"], colorNames: ["White"], tile: "pods", condition: "New" },
  { id: "airpods-4", name: "AirPods 4", category: "accessory", price: 129, chip: "H2", info: "Personalised spatial audio", colors: ["#f4f4f6"], colorNames: ["White"], tile: "pods", condition: "New" },
  { id: "pencil-pro", name: "Apple Pencil Pro", category: "accessory", price: 129, chip: "Squeeze & haptics", info: "For iPad Pro and Air", colors: ["#f4f4f6"], colorNames: ["White"], tile: "pencil", condition: "New" },
  { id: "magic-keyboard", name: "Magic Keyboard", category: "accessory", price: 299, chip: "For iPad Pro", info: "Floating design · trackpad", colors: ["#f4f4f6", "#33353a"], colorNames: ["White", "Black"], tile: "keyboard", condition: "New" },
  { id: "magsafe-charger", name: "MagSafe Charger", category: "accessory", price: 39, chip: "25W wireless", info: "Perfectly aligned snap", colors: ["#f4f4f6"], colorNames: ["White"], tile: "puck", condition: "New" },
  { id: "homepod-mini", name: "HomePod mini", category: "accessory", price: 99, chip: "S5", info: "Room-filling 360° audio", colors: ["#f2a843", "#a9c1e0", "#31313a", "#f3f0ea"], colorNames: ["Orange", "Blue", "Midnight", "White"], tile: "speaker", condition: "New" },
  { id: "airtag", name: "AirTag", category: "accessory", price: 29, chip: "U1 & UWB", info: "Precision Finding", colors: ["#f4f4f6"], colorNames: ["White"], tile: "tag", condition: "New" },
];

export const CATALOG: CatalogProduct[] = [...IPHONES, ...GEAR];

export const CATEGORIES: { id: Category | "all"; label: string }[] = [
  { id: "all", label: "All" },
  { id: "iphone", label: "iPhone" },
  { id: "watch", label: "Watch" },
  { id: "mac", label: "Mac" },
  { id: "ipad", label: "iPad" },
  { id: "accessory", label: "Accessories" },
];

export const GENERATIONS = GENS.map((g) => ({ gen: g.gen, year: g.year })).sort((a, b) => b.gen - a.gen);

/* ---------------------------------------------------------------
   Per-product configuration tiers (storage / case size)
---------------------------------------------------------------- */

export interface OptionTier {
  label: string;
  delta: number;
}

export interface ProductOptions {
  heading: string;
  tiers: OptionTier[];
}

export function optionsFor(p: CatalogProduct): ProductOptions | null {
  switch (p.category) {
    case "iphone": {
      const g = p.generation ?? 17;
      const isPro = p.name.includes("Pro");
      const isMax = p.name.includes("Max");
      if (g <= 14)
        return {
          heading: "Storage",
          tiers: [
            { label: "128GB", delta: 0 },
            { label: "256GB", delta: 40 },
            { label: "512GB", delta: 90 },
          ],
        };
      if (g === 15 || g === 16)
        return {
          heading: "Storage",
          tiers: [
            { label: "128GB", delta: 0 },
            { label: "256GB", delta: 100 },
            { label: "512GB", delta: 200 },
            ...(isPro ? [{ label: "1TB", delta: 400 }] : []),
          ],
        };
      return {
        heading: "Storage",
        tiers: [
          { label: "256GB", delta: 0 },
          { label: "512GB", delta: 200 },
          ...(isPro ? [{ label: "1TB", delta: 400 }] : []),
          ...(isMax ? [{ label: "2TB", delta: 600 }] : []),
        ],
      };
    }
    case "ipad": {
      const isPro = p.name.includes("Pro");
      return {
        heading: "Storage",
        tiers: isPro
          ? [
              { label: "256GB", delta: 0 },
              { label: "512GB", delta: 200 },
              { label: "1TB", delta: 400 },
            ]
          : [
              { label: "128GB", delta: 0 },
              { label: "256GB", delta: 100 },
              { label: "512GB", delta: 200 },
            ],
      };
    }
    case "mac": {
      const isPro = p.name.includes("Pro");
      return {
        heading: "Storage",
        tiers: isPro
          ? [
              { label: "512GB", delta: 0 },
              { label: "1TB", delta: 200 },
              { label: "2TB", delta: 600 },
            ]
          : [
              { label: "256GB", delta: 0 },
              { label: "512GB", delta: 200 },
              { label: "1TB", delta: 400 },
            ],
      };
    }
    case "watch": {
      if (p.name.includes("Ultra")) return { heading: "Case size", tiers: [{ label: "49mm", delta: 0 }] };
      if (p.name.includes("SE"))
        return {
          heading: "Case size",
          tiers: [
            { label: "40mm", delta: 0 },
            { label: "44mm", delta: 30 },
          ],
        };
      return {
        heading: "Case size",
        tiers: [
          { label: "42mm", delta: 0 },
          { label: "46mm", delta: 30 },
        ],
      };
    }
    default:
      return null;
  }
}
