export interface Finish {
  id: string;
  name: string;
  /** Swatch shown in UI */
  swatch: string;
  /** 3D metal frame colour */
  frame: string;
  /** 3D back-glass colour */
  back: string;
  /** Camera plateau colour */
  plateau: string;
}

export interface StorageTier {
  id: string;
  label: string;
  delta: number;
}

export interface ModelSpec {
  display: string;
  chip: string;
  camera: string;
  zoom: string;
  battery: string;
  thickness: string;
  weight: string;
  connectivity: string;
}

export interface PhoneModel {
  id: string;
  name: string;
  shortName: string;
  tagline: string;
  base: number;
  monthly: number;
  chipShort: string;
  displayShort: string;
  image: string;
  imageAlt: string;
  cardTone: string;
  finishes: Finish[];
  storage: StorageTier[];
  spec: ModelSpec;
}

export const MODELS: PhoneModel[] = [
  {
    id: "17-pro-max",
    name: "iPhone 17 Pro Max",
    shortName: "17 Pro Max",
    tagline: "The ultimate iPhone. Uncompromising in every dimension.",
    base: 1199,
    monthly: 49.95,
    chipShort: "A19 Pro",
    displayShort: "6.9″ ProMotion",
    image: "/img/iphone-pro-orange.jpg",
    imageAlt:
      "iPhone 17 Pro Max in Cosmic Orange standing on a travertine pedestal, triple camera system visible",
    cardTone: "#f6e9dd",
    finishes: [
      { id: "cosmic-orange", name: "Cosmic Orange", swatch: "#d97a3a", frame: "#d1793b", back: "#dd8550", plateau: "#c06a2e" },
      { id: "deep-blue", name: "Deep Blue", swatch: "#3d4b66", frame: "#46536f", back: "#4b5976", plateau: "#39445c" },
      { id: "silver", name: "Silver", swatch: "#e3e4e8", frame: "#d9dade", back: "#e6e7ea", plateau: "#cdcfd4" },
    ],
    storage: [
      { id: "256", label: "256GB", delta: 0 },
      { id: "512", label: "512GB", delta: 200 },
      { id: "1tb", label: "1TB", delta: 400 },
      { id: "2tb", label: "2TB", delta: 600 },
    ],
    spec: {
      display: "6.9″ Super Retina XDR, 1–120Hz ProMotion",
      chip: "A19 Pro · 6-core GPU",
      camera: "48MP Pro Fusion triple system",
      zoom: "8× optical-quality telephoto",
      battery: "Up to 37 hrs video",
      thickness: "8.75 mm",
      weight: "231 g",
      connectivity: "Wi-Fi 7 · USB-C 3 (10Gb/s) · Thread",
    },
  },
  {
    id: "17-pro",
    name: "iPhone 17 Pro",
    shortName: "17 Pro",
    tagline: "All the pro power, in the hand-fitting 6.3-inch design.",
    base: 1099,
    monthly: 45.79,
    chipShort: "A19 Pro",
    displayShort: "6.3″ ProMotion",
    image: "/img/camera-macro.jpg",
    imageAlt: "Macro detail of the iPhone 17 Pro 48MP Fusion camera lenses with brushed metal rings",
    cardTone: "#e4e7ec",
    finishes: [
      { id: "cosmic-orange", name: "Cosmic Orange", swatch: "#d97a3a", frame: "#d1793b", back: "#dd8550", plateau: "#c06a2e" },
      { id: "deep-blue", name: "Deep Blue", swatch: "#3d4b66", frame: "#46536f", back: "#4b5976", plateau: "#39445c" },
      { id: "silver", name: "Silver", swatch: "#e3e4e8", frame: "#d9dade", back: "#e6e7ea", plateau: "#cdcfd4" },
    ],
    storage: [
      { id: "256", label: "256GB", delta: 0 },
      { id: "512", label: "512GB", delta: 200 },
      { id: "1tb", label: "1TB", delta: 400 },
    ],
    spec: {
      display: "6.3″ Super Retina XDR, 1–120Hz ProMotion",
      chip: "A19 Pro · 6-core GPU",
      camera: "48MP Pro Fusion triple system",
      zoom: "8× optical-quality telephoto",
      battery: "Up to 31 hrs video",
      thickness: "8.75 mm",
      weight: "206 g",
      connectivity: "Wi-Fi 7 · USB-C 3 (10Gb/s) · Thread",
    },
  },
  {
    id: "17",
    name: "iPhone 17",
    shortName: "17",
    tagline: "Brilliant for everyone. A delightful everyday flagship.",
    base: 799,
    monthly: 33.29,
    chipShort: "A19",
    displayShort: "6.3″ ProMotion",
    image: "/img/iphone-17-lavender.jpg",
    imageAlt: "iPhone 17 in soft Lavender glass finish standing on a light gray studio surface",
    cardTone: "#ece8f1",
    finishes: [
      { id: "lavender", name: "Lavender", swatch: "#c6bcd9", frame: "#c2b8d6", back: "#cdc4de", plateau: "#b5aacb" },
      { id: "sage", name: "Sage", swatch: "#b7c4ab", frame: "#b3c1a6", back: "#bcc9b2", plateau: "#a5b294" },
      { id: "mist-blue", name: "Mist Blue", swatch: "#aec2d6", frame: "#a8bdD2", back: "#b3c6d9", plateau: "#9cb1c6" },
      { id: "black", name: "Black", swatch: "#2e2e33", frame: "#2f2f35", back: "#34343a", plateau: "#26262b" },
    ],
    storage: [
      { id: "256", label: "256GB", delta: 0 },
      { id: "512", label: "512GB", delta: 200 },
    ],
    spec: {
      display: "6.3″ Super Retina XDR, 1–120Hz ProMotion",
      chip: "A19 · 5-core GPU",
      camera: "48MP Dual Fusion system",
      zoom: "2× optical-quality telephoto",
      battery: "Up to 30 hrs video",
      thickness: "7.95 mm",
      weight: "177 g",
      connectivity: "Wi-Fi 7 · USB-C · Thread",
    },
  },
  {
    id: "air",
    name: "iPhone Air",
    shortName: "Air",
    tagline: "Impossibly thin at 5.64 mm. Power, weightlessly carried.",
    base: 999,
    monthly: 41.62,
    chipShort: "A19 Pro",
    displayShort: "6.5″ ProMotion",
    image: "/img/iphone-air-gold.jpg",
    imageAlt: "Ultra-thin iPhone Air in Light Gold levitating over a soft beige studio backdrop",
    cardTone: "#f2ecdf",
    finishes: [
      { id: "light-gold", name: "Light Gold", swatch: "#e6d8c0", frame: "#e0d0b4", back: "#e9dcc6", plateau: "#d6c4a4" },
      { id: "sky-blue", name: "Sky Blue", swatch: "#bcd4e8", frame: "#b6cfe5", back: "#c2d8ea", plateau: "#a9c1d8" },
      { id: "cloud-white", name: "Cloud White", swatch: "#f2f2f0", frame: "#e9e9e6", back: "#f4f4f2", plateau: "#dededa" },
      { id: "space-black", name: "Space Black", swatch: "#34353b", frame: "#35363c", back: "#3a3b41", plateau: "#2b2c31" },
    ],
    storage: [
      { id: "256", label: "256GB", delta: 0 },
      { id: "512", label: "512GB", delta: 200 },
      { id: "1tb", label: "1TB", delta: 400 },
    ],
    spec: {
      display: "6.5″ Super Retina XDR, 1–120Hz ProMotion",
      chip: "A19 Pro · 5-core GPU",
      camera: "48MP Fusion single camera",
      zoom: "2× optical-quality telephoto",
      battery: "Up to 27 hrs video",
      thickness: "5.64 mm",
      weight: "165 g",
      connectivity: "Wi-Fi 7 · USB-C · Thread",
    },
  },
];

export const HERO_MODEL = MODELS[0];

export const fmt = (n: number) =>
  n.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: n % 1 ? 2 : 0 });

export const findModel = (id: string) => MODELS.find((m) => m.id === id) ?? MODELS[0];
export const findFinish = (modelId: string, finishId: string) => {
  const m = findModel(modelId);
  return m.finishes.find((f) => f.id === finishId) ?? m.finishes[0];
};
export const findStorage = (modelId: string, storageId: string) => {
  const m = findModel(modelId);
  return m.storage.find((s) => s.id === storageId) ?? m.storage[0];
};
export const priceFor = (modelId: string, storageId: string) =>
  findModel(modelId).base + findStorage(modelId, storageId).delta;

export const CARE_PLUS_PRICE = 199;

export const MARQUEE_ITEMS = [
  "A19 Pro chip",
  "6.9″ ProMotion display",
  "48MP Fusion camera",
  "8× optical zoom",
  "37-hour battery life",
  "Ceramic Shield 2",
  "Wi-Fi 7",
  "USB-C · USB 3 speeds",
];
