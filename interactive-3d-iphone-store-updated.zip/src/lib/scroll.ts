import { useEffect } from "react";
import type Lenis from "lenis";

let lenis: Lenis | null = null;

/** Reference count so stacked panels (e.g. sign-in over the bag) share one lock */
let lockCount = 0;
let savedOverflow: { html: string; body: string } | null = null;
let savedPadding = "";

export function registerLenis(instance: Lenis | null) {
  lenis = instance;
  // A panel may already be open when a new Lenis instance is created
  if (instance && lockCount > 0) instance.stop();
}

export function scrollToId(id: string) {
  const el = document.getElementById(id);
  if (!el) return;
  if (lenis) {
    lenis.scrollTo(el, { offset: -72, duration: 1.35 });
  } else {
    el.scrollIntoView({ behavior: "smooth", block: "start" });
  }
}

/**
 * Freeze the homepage behind an open panel: stop Lenis, hide overflow and
 * compensate the scrollbar gutter. Returns the matching unlock function.
 */
function lockScroll(): () => void {
  lockCount += 1;
  if (lockCount === 1) {
    const html = document.documentElement;
    const body = document.body;
    savedOverflow = { html: html.style.overflow, body: body.style.overflow };
    html.style.overflow = "hidden";
    body.style.overflow = "hidden";
    // Keep page content from jumping when the scrollbar disappears
    const gap = window.innerWidth - html.clientWidth;
    if (gap > 0) {
      savedPadding = body.style.paddingRight;
      body.style.paddingRight = `${gap}px`;
    }
    lenis?.stop();
  }
  return () => {
    lockCount = Math.max(0, lockCount - 1);
    if (lockCount === 0) {
      const html = document.documentElement;
      if (savedOverflow) {
        html.style.overflow = savedOverflow.html;
        document.body.style.overflow = savedOverflow.body;
        savedOverflow = null;
      }
      document.body.style.paddingRight = savedPadding;
      savedPadding = "";
      lenis?.start();
    }
  };
}

/** Lock the background page while `active` (a panel/modal is open). */
export function useScrollLock(active: boolean) {
  useEffect(() => {
    if (!active) return;
    return lockScroll();
  }, [active]);
}
