import * as THREE from "three";

function roundedRectPath2d(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.arcTo(x + w, y, x + w, y + r, r);
  ctx.lineTo(x + w, y + h - r);
  ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
  ctx.lineTo(x + r, y + h);
  ctx.arcTo(x, y + h, x, y + h - r, r);
  ctx.lineTo(x, y + r);
  ctx.arcTo(x, y, x + r, y, r);
  ctx.closePath();
}

function blob(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, color: string) {
  const g = ctx.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, color);
  g.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
}

/** Fallback wallpaper — used until (or if) the home-screen image loads. */
function drawFallbackWallpaper(ctx: CanvasRenderingContext2D, w: number, h: number) {
  ctx.fillStyle = "#07060f";
  ctx.fillRect(0, 0, w, h);
  if ("filter" in ctx) ctx.filter = "blur(80px)";
  blob(ctx, 130, 210, 260, "#20337f");
  blob(ctx, 440, 330, 230, "#5b2fae");
  blob(ctx, 150, 800, 270, "#b04a24");
  blob(ctx, 430, 980, 240, "#123f52");
  blob(ctx, 260, 560, 200, "#1a1440");
  if ("filter" in ctx) ctx.filter = "none";
}

/** Draw an image cover-fit into a rect. */
function drawCover(
  ctx: CanvasRenderingContext2D,
  img: CanvasImageSource & { width: number; height: number },
  x: number,
  y: number,
  w: number,
  h: number,
) {
  const scale = Math.max(w / img.width, h / img.height);
  const dw = img.width * scale;
  const dh = img.height * scale;
  ctx.drawImage(img, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
}

/**
 * Home-screen chrome on top of the wallpaper: status bar, a glass dock
 * with app tiles, page dots and the home indicator.
 */
function drawHomeChrome(ctx: CanvasRenderingContext2D, w: number, h: number, pad: number) {
  const left = pad;
  const right = w - pad;
  const top = pad;
  const bottom = h - pad;

  /* —— Status bar —— */
  ctx.fillStyle = "rgba(255,255,255,0.95)";
  ctx.textAlign = "left";
  ctx.font = "600 36px Inter, system-ui, sans-serif";
  ctx.fillText("9:41", left + 44, top + 62);

  // Signal bars
  const barX = right - 150;
  for (let i = 0; i < 4; i++) {
    const bh = 10 + i * 5;
    ctx.globalAlpha = i === 3 ? 0.45 : 0.95;
    ctx.fillRect(barX + i * 12, top + 58 - bh, 7, bh);
  }
  ctx.globalAlpha = 0.95;

  // Wi-Fi glyph — three arcs
  const wifiX = right - 86;
  const wifiY = top + 52;
  ctx.lineWidth = 5;
  ctx.strokeStyle = "rgba(255,255,255,0.95)";
  ctx.lineCap = "round";
  for (let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.arc(wifiX, wifiY + 8, 8 + i * 11, Math.PI * 1.25, Math.PI * 1.75);
    ctx.stroke();
  }
  ctx.beginPath();
  ctx.arc(wifiX, wifiY + 10, 3, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(255,255,255,0.95)";
  ctx.fill();

  // Battery
  const batX = right - 56;
  const batY = top + 38;
  ctx.lineWidth = 3.5;
  ctx.strokeStyle = "rgba(255,255,255,0.85)";
  roundedRectPath2d(ctx, batX, batY, 42, 22, 7);
  ctx.stroke();
  ctx.fillRect(batX + 5, batY + 5, 26, 12);
  ctx.globalAlpha = 0.55;
  ctx.fillRect(batX + 44, batY + 7, 4, 8);
  ctx.globalAlpha = 1;

  /* —— Page dots —— */
  const dotY = bottom - 178;
  for (let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.arc(w / 2 - 22 + i * 22, dotY, i === 0 ? 6 : 4.5, 0, Math.PI * 2);
    ctx.fillStyle = i === 0 ? "rgba(255,255,255,0.95)" : "rgba(255,255,255,0.4)";
    ctx.fill();
  }

  /* —— Glass dock —— */
  const dockW = w - pad * 2 - 72;
  const dockH = 148;
  const dockX = (w - dockW) / 2;
  const dockY = bottom - 158;
  ctx.fillStyle = "rgba(255,255,255,0.16)";
  roundedRectPath2d(ctx, dockX, dockY, dockW, dockH, 48);
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.strokeStyle = "rgba(255,255,255,0.22)";
  roundedRectPath2d(ctx, dockX, dockY, dockW, dockH, 48);
  ctx.stroke();

  /* —— App tiles —— */
  const tiles: Array<{ tint: string; glyph: "phone" | "message" | "music" | "camera" }> = [
    { tint: "rgba(74,222,128,0.85)", glyph: "phone" },
    { tint: "rgba(96,165,250,0.85)", glyph: "message" },
    { tint: "rgba(244,114,182,0.8)", glyph: "music" },
    { tint: "rgba(255,255,255,0.28)", glyph: "camera" },
  ];
  const tile = 88;
  const gap = (dockW - tiles.length * tile) / (tiles.length + 1);
  tiles.forEach((t, i) => {
    const x = dockX + gap + i * (tile + gap);
    const y = dockY + (dockH - tile) / 2;
    ctx.fillStyle = t.tint;
    roundedRectPath2d(ctx, x, y, tile, tile, 24);
    ctx.fill();

    ctx.strokeStyle = "rgba(255,255,255,0.92)";
    ctx.fillStyle = "rgba(255,255,255,0.92)";
    ctx.lineWidth = 5;
    ctx.lineCap = "round";
    const cx = x + tile / 2;
    const cy = y + tile / 2;
    if (t.glyph === "phone") {
      ctx.beginPath();
      ctx.arc(cx, cy, 17, Math.PI * 0.2, Math.PI * 0.8);
      ctx.stroke();
    } else if (t.glyph === "message") {
      roundedRectPath2d(ctx, cx - 19, cy - 15, 38, 28, 12);
      ctx.stroke();
    } else if (t.glyph === "music") {
      ctx.beginPath();
      ctx.arc(cx - 8, cy + 12, 8, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillRect(cx - 2, cy - 16, 5, 28);
      ctx.fillRect(cx - 2, cy - 16, 14, 5);
    } else {
      roundedRectPath2d(ctx, cx - 20, cy - 14, 40, 28, 9);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(cx, cy, 8, 0, Math.PI * 2);
      ctx.stroke();
    }
  });

  /* —— Home indicator —— */
  ctx.fillStyle = "rgba(255,255,255,0.85)";
  roundedRectPath2d(ctx, w / 2 - 82, bottom - 8, 164, 11, 6);
  ctx.fill();
}

/**
 * Generates the iPhone home screen with the project wallpaper
 * (public/img/home-screen.jpg) and a black bezel baked in.
 */
export function makeScreenTexture(): THREE.CanvasTexture {
  const w = 512;
  const h = 1098;
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d")!;

  const pad = 24;
  let tex: THREE.CanvasTexture | null = null;

  const draw = (wallpaper: (CanvasImageSource & { width: number; height: number }) | null) => {
    // Full-bleed home-screen wallpaper — covers the entire 3D display
    if (wallpaper) {
      drawCover(ctx, wallpaper, 0, 0, w, h);
    } else {
      drawFallbackWallpaper(ctx, w, h);
    }

    // Gentle sheen so the glass reads as glass
    const sheen = ctx.createLinearGradient(0, 0, w, h * 0.6);
    sheen.addColorStop(0, "rgba(255,255,255,0.1)");
    sheen.addColorStop(0.45, "rgba(255,255,255,0.02)");
    sheen.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = sheen;
    ctx.fillRect(0, 0, w, h);

    drawHomeChrome(ctx, w, h, pad);

    if (tex) tex.needsUpdate = true;
  };

  // Immediate paint — fallback wallpaper until the image arrives
  draw(null);

  tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;

  const img = new Image();
  img.onload = () => draw(img);
  img.src = "/img/home-screen.jpg";

  return tex;
}
