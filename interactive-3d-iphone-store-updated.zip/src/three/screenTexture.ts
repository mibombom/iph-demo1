import * as THREE from "three";

function roundedRectPath2d(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.arcTo(x + w, y, x + w, y + r, r);
  ctx.lineTo(x + w, y + h - r);
  ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
  ctx.lineTo(x + r, y + h);
  ctx.arcTo(x, y + h, x, y + h - r, r);
  ctx.lineTo(x, y + r);
  ctx.arcTo(x, y, x + r, y, r);
  ctx.closePath();
}

function blob(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, color: string) {
  const g = ctx.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, color);
  g.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
}

/** Generates a rich OLED-style lock-screen wallpaper with a black bezel baked in. */
export function makeScreenTexture(): THREE.CanvasTexture {
  const w = 512;
  const h = 1098;
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d")!;

  // Bezel — pitch black surround
  ctx.fillStyle = "#000000";
  ctx.fillRect(0, 0, w, h);

  const pad = 24;
  ctx.save();
  ctx.beginPath();
  roundedRectPath2d(ctx, pad, pad, w - pad * 2, h - pad * 2, 92);
  ctx.clip();

  // Wallpaper base
  ctx.fillStyle = "#07060f";
  ctx.fillRect(0, 0, w, h);

  if ("filter" in ctx) ctx.filter = "blur(80px)";
  blob(ctx, 130, 210, 260, "#20337f");
  blob(ctx, 440, 330, 230, "#5b2fae");
  blob(ctx, 150, 800, 270, "#b04a24");
  blob(ctx, 430, 980, 240, "#123f52");
  blob(ctx, 260, 560, 200, "#1a1440");
  if ("filter" in ctx) ctx.filter = "none";

  // Fine vertical sheen, like light across glass
  const sheen = ctx.createLinearGradient(0, 0, w, h * 0.6);
  sheen.addColorStop(0, "rgba(255,255,255,0.12)");
  sheen.addColorStop(0.4, "rgba(255,255,255,0.02)");
  sheen.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = sheen;
  ctx.fillRect(0, 0, w, h);

  // Top status hint — subtle time rendering
  ctx.fillStyle = "rgba(255,255,255,0.92)";
  ctx.font = "600 118px Inter, system-ui, sans-serif";
  ctx.textAlign = "center";
  ctx.globalAlpha = 0.9;
  ctx.fillText("9:41", w / 2, 260);
  ctx.font = "500 34px Inter, system-ui, sans-serif";
  ctx.globalAlpha = 0.72;
  ctx.fillText("Tuesday, September 9", w / 2, 152);
  ctx.globalAlpha = 1;

  ctx.restore();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  return tex;
}
