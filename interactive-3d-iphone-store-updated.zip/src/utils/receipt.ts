/**
 * Digital receipt — generated at checkout, previewable in-app, and
 * downloadable as a self-contained, printable HTML file from any browser
 * (Print → Save as PDF for a PDF copy). Never includes payment card data.
 */

export interface ReceiptItem {
  title: string;
  meta: string;
  qty: number;
  unitPrice: number;
}

export interface ReceiptData {
  id: string;
  date: string;
  eta: string;
  customer: {
    name: string;
    email: string;
    address: string;
    city: string;
    zip: string;
  };
  items: ReceiptItem[];
  total: number;
}

const money = (n: number) =>
  n.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 });

const esc = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

/** Render the full receipt HTML (used for previews and downloads). */
export function receiptHtml(r: ReceiptData): string {
  const rows = r.items
    .map(
      (it) => `
      <tr>
        <td>
          <p class="item-title">${esc(it.title)}</p>
          <p class="item-meta">${esc(it.meta)}</p>
        </td>
        <td class="center">${it.qty}</td>
        <td class="right">${money(it.unitPrice)}</td>
        <td class="right strong">${money(it.unitPrice * it.qty)}</td>
      </tr>`,
    )
    .join("");

  const hasAddress = Boolean(r.customer.address || r.customer.city || r.customer.zip);

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>AURA receipt ${esc(r.id)}</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    background: #ece8df; color: #141417; padding: 32px 16px;
    -webkit-print-color-adjust: exact; print-color-adjust: exact;
  }
  .sheet {
    max-width: 640px; margin: 0 auto; background: #f5f3ee; border: 1px solid rgba(20,20,23,0.12);
    border-radius: 24px; overflow: hidden;
  }
  header {
    display: flex; justify-content: space-between; align-items: flex-start;
    padding: 28px 32px 22px; border-bottom: 1px solid rgba(20,20,23,0.1);
  }
  .brand { font-size: 15px; font-weight: 800; letter-spacing: 0.22em; text-transform: uppercase; }
  .tag { margin-top: 6px; font-size: 11px; letter-spacing: 0.14em; text-transform: uppercase; color: #8b8b92; }
  .status {
    background: rgba(22,163,74,0.12); color: #15803d; border-radius: 999px;
    padding: 6px 12px; font-size: 11px; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase;
  }
  .meta { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; padding: 22px 32px; }
  .meta-block { background: rgba(20,20,23,0.04); border-radius: 16px; padding: 14px 16px; }
  .label { font-size: 10px; font-weight: 700; letter-spacing: 0.14em; text-transform: uppercase; color: #8b8b92; }
  .value { margin-top: 5px; font-size: 13px; line-height: 1.55; }
  .mono { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-weight: 700; letter-spacing: 0.06em; }
  table { width: 100%; border-collapse: collapse; padding: 0 32px; }
  th {
    font-size: 10px; letter-spacing: 0.12em; text-transform: uppercase; color: #8b8b92;
    text-align: left; padding: 10px 8px; border-bottom: 1px solid rgba(20,20,23,0.12);
  }
  td { padding: 12px 8px; font-size: 13px; border-bottom: 1px solid rgba(20,20,23,0.07); vertical-align: top; }
  .item-title { font-weight: 700; }
  .item-meta { margin-top: 2px; font-size: 11px; color: #8b8b92; }
  .center { text-align: center; }
  .right { text-align: right; }
  .strong { font-weight: 700; }
  .total-row td { border-bottom: none; font-size: 15px; padding-top: 16px; }
  .total-label { text-align: right; font-size: 11px; letter-spacing: 0.14em; text-transform: uppercase; color: #8b8b92; padding-right: 16px; }
  .note {
    margin: 18px 32px 0; padding: 14px 16px; border: 1px dashed rgba(20,20,23,0.2);
    border-radius: 14px; font-size: 11.5px; line-height: 1.6; color: #55555c;
  }
  footer {
    margin-top: 20px; padding: 18px 32px 26px; border-top: 1px solid rgba(20,20,23,0.1);
    font-size: 10.5px; line-height: 1.7; color: #8b8b92;
  }
  .accent { color: #c8522b; font-weight: 700; }
  @media print {
    body { background: #fff; padding: 0; }
    .sheet { border: none; border-radius: 0; max-width: none; }
  }
</style>
</head>
<body>
  <div class="sheet">
    <header>
      <div>
        <p class="brand">Aura</p>
        <p class="tag">Digital receipt · Interactive 3D iPhone Store</p>
      </div>
      <span class="status">Order confirmed</span>
    </header>

    <div class="meta">
      <div class="meta-block">
        <p class="label">Receipt</p>
        <p class="value mono">${esc(r.id)}</p>
        <p class="value">Placed ${esc(new Date(r.date).toLocaleString("en-US", { dateStyle: "long", timeStyle: "short" }))}</p>
        <p class="value">Estimated arrival: ${esc(r.eta)}</p>
      </div>
      <div class="meta-block">
        <p class="label">Delivered to</p>
        <p class="value"><span class="strong">${esc(r.customer.name || "AURA customer")}</span><br />
        ${esc(r.customer.email || "")}${hasAddress ? `<br />${esc(r.customer.address)}<br />${esc(r.customer.city)}${r.customer.zip ? `, ${esc(r.customer.zip)}` : ""}` : ""}</p>
      </div>
    </div>

    <table>
      <thead>
        <tr>
          <th>Item</th>
          <th class="center">Qty</th>
          <th class="right">Unit price</th>
          <th class="right">Line total</th>
        </tr>
      </thead>
      <tbody>
        ${rows}
        <tr class="total-row">
          <td colspan="3" class="total-label">Order total</td>
          <td class="right strong">${money(r.total)}</td>
        </tr>
      </tbody>
    </table>

    <div class="note">
      <span class="accent">Payment:</span> processed securely at checkout.
      No card numbers or payment credentials are stored or printed on this receipt.
      Delivery is free — taxes, where applicable, are included in the order total.
    </div>

    <footer>
      Thank you for shopping with AURA. Keep this receipt for your records —
      it can be re-downloaded anytime from Account → Orders while signed in.
      Use your browser's <span class="accent">Print → Save as PDF</span> for a PDF copy.<br />
      Generated ${esc(new Date().toLocaleString())} · AURA demo store · aura.demo
    </footer>
  </div>
</body>
</html>`;
}

/** File name used for downloads */
export const receiptFileName = (r: ReceiptData) => `AURA-receipt-${r.id}.html`;

function receiptBlobUrl(r: ReceiptData): string {
  const blob = new Blob([receiptHtml(r)], { type: "text/html;charset=utf-8" });
  return URL.createObjectURL(blob);
}

/** Result of a save attempt — UI uses this to explain what happened. */
export type SaveOutcome = "downloaded" | "saver" | "blocked";

/**
 * Trigger a browser download of the receipt as a standalone HTML file.
 * Works from any modern browser: the anchor carries the `download`
 * attribute and the blob URL is kept alive long enough for slow saves.
 */
export function downloadReceipt(receipt: ReceiptData) {
  const url = receiptBlobUrl(receipt);
  const a = document.createElement("a");
  a.href = url;
  a.download = receiptFileName(receipt);
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
  // Delayed revoke — immediate revocation can cancel the save in some browsers
  window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
}

/**
 * Open a top-level "Save receipt" helper tab. The tab runs outside any
 * preview frame, so its Download button saves the file even when the
 * store is embedded in a sandboxed iframe that blocks automatic downloads.
 * Returns false when the browser blocks the pop-up.
 */
export function openReceiptSaver(receipt: ReceiptData): boolean {
  const url = receiptBlobUrl(receipt);
  const name = receiptFileName(receipt);
  const win = window.open("", "_blank");
  if (!win) return false;
  try {
    win.opener = null;
  } catch {
    /* ignore */
  }
  win.document.write(`<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Save ${name}</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background: #ece8df; color: #141417; }
  .bar { display: flex; flex-wrap: wrap; align-items: center; gap: 12px; padding: 18px 22px; background: #f5f3ee; border-bottom: 1px solid rgba(20,20,23,0.12); }
  .title { font-size: 15px; font-weight: 800; }
  .sub { margin-top: 3px; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 11px; color: #8b8b92; }
  .actions { margin-left: auto; display: flex; flex-wrap: wrap; gap: 8px; }
  button { cursor: pointer; border: none; border-radius: 999px; padding: 12px 20px; font-size: 13px; font-weight: 700; }
  #dl { background: #141417; color: #f5f3ee; }
  #dl:hover { background: #c8522b; }
  #print { background: transparent; color: #141417; border: 1px solid rgba(20,20,23,0.2); }
  #print:hover { background: #141417; color: #f5f3ee; }
  .hint { padding: 12px 22px 18px; font-size: 11.5px; line-height: 1.7; color: #55555c; }
  .hint b { color: #c8522b; }
  iframe { display: block; width: calc(100% - 32px); height: 62vh; margin: 16px; border: 1px solid rgba(20,20,23,0.12); border-radius: 16px; background: #fff; }
</style>
</head>
<body>
  <div class="bar">
    <div>
      <p class="title">Save your AURA receipt</p>
      <p class="sub">${name}</p>
    </div>
    <div class="actions">
      <button id="dl" type="button">Download file</button>
      <button id="print" type="button">Print / Save as PDF</button>
    </div>
  </div>
  <iframe id="f" title="Receipt preview" src="${url}"></iframe>
  <p class="hint">
    Press <b>Download file</b> to save the receipt as a standalone HTML file.
    If your browser asks, choose <b>Save</b> / <b>Downloads</b>. For a PDF copy,
    use <b>Print → Save as PDF</b>. You can close this tab once the file is saved.
  </p>
  <script>
    document.getElementById("dl").addEventListener("click", function () {
      var a = document.createElement("a");
      a.href = ${JSON.stringify(url)};
      a.download = ${JSON.stringify(name)};
      document.body.appendChild(a);
      a.click();
      a.remove();
    });
    document.getElementById("print").addEventListener("click", function () {
      var f = document.getElementById("f");
      (f.contentWindow || window).print();
    });
  </script>
</body>
</html>`);
  win.document.close();
  window.setTimeout(() => URL.revokeObjectURL(url), 300_000);
  return true;
}

/**
 * Save the receipt with the best mechanism this browsing context allows.
 * - Top-level tabs: the plain download starts immediately.
 * - Embedded preview frames (which often block automatic downloads): a
 *   top-level "Save receipt" tab opens so the save always has a home.
 * - Pop-ups blocked too: reports "blocked" so the UI can guide the user.
 */
export function saveReceipt(receipt: ReceiptData): SaveOutcome {
  const framed = window.self !== window.top;
  downloadReceipt(receipt);
  if (!framed) return "downloaded";
  return openReceiptSaver(receipt) ? "saver" : "blocked";
}

/**
 * Open the receipt in a new browser tab: from there the user can read it,
 * download it, or print/save as PDF with the browser's own controls.
 * Returns the blob URL, or null when the browser blocked the pop-up and
 * same-tab navigation is not safe (e.g. inside an embedded preview frame).
 */
export function openReceiptTab(receipt: ReceiptData): string | null {
  const url = receiptBlobUrl(receipt);
  const win = window.open(url, "_blank");
  if (win) {
    try {
      win.opener = null;
    } catch {
      /* ignore */
    }
    window.setTimeout(() => URL.revokeObjectURL(url), 120_000);
    return url;
  }
  // Pop-up blocked: navigate the current tab only at top level — inside a
  // preview frame that would tear the store out of view.
  if (window.self === window.top) {
    window.location.href = url;
    return url;
  }
  return null;
}

/** Build receipt data from a stored account order (for re-downloads). */
export function receiptFromOrder(
  order: {
    id: string;
    date: string;
    eta: string;
    total: number;
    items: { title: string; meta: string; qty: number; unitPrice: number }[];
  },
  customer: { name: string; email: string; address?: string; city?: string; zip?: string },
): ReceiptData {
  return {
    id: order.id,
    date: order.date,
    eta: order.eta,
    customer: {
      name: customer.name,
      email: customer.email,
      address: customer.address ?? "",
      city: customer.city ?? "",
      zip: customer.zip ?? "",
    },
    items: order.items.map(({ title, meta, qty, unitPrice }) => ({ title, meta, qty, unitPrice })),
    total: order.total,
  };
}
