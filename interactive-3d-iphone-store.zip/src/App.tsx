import { useEffect } from "react";
import Lenis from "lenis";
import { StoreProvider, useStore } from "./context/Store";
import { AuthProvider } from "./context/Auth";
import { SettingsProvider, usePrefersCalm, useSettings } from "./context/Settings";
import { registerLenis } from "./lib/scroll";
import SettingsPanel from "./components/SettingsPanel";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Marquee from "./components/Marquee";
import Models from "./components/Models";
import Catalogue from "./components/Catalogue";
import Studio from "./components/Studio";
import Craft from "./components/Craft";
import { Compare, Specs } from "./components/Specs";
import Buy from "./components/Buy";
import Bag from "./components/Bag";
import AuthModal from "./components/AuthModal";
import AccountDrawer from "./components/AccountDrawer";
import Footer from "./components/Footer";

function useLenis() {
  const { smoothScroll } = useSettings();
  const calm = usePrefersCalm();
  useEffect(() => {
    if (calm || !smoothScroll) {
      registerLenis(null);
      return;
    }
    const lenis = new Lenis({ lerp: 0.1, wheelMultiplier: 0.95, touchMultiplier: 1.4 });
    registerLenis(lenis);
    let raf = 0;
    const loop = (time: number) => {
      lenis.raf(time);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      lenis.destroy();
      registerLenis(null);
    };
  }, [calm, smoothScroll]);
}

function LiveAnnouncer() {
  const { bagCount } = useStore();
  return (
    <div aria-live="polite" className="sr-only">
      {bagCount > 0 ? `${bagCount} item${bagCount === 1 ? "" : "s"} in your bag.` : ""}
    </div>
  );
}

function Site() {
  useLenis();
  return (
    <>
      <Navbar />
      <main id="main">
        <Hero />
        <Marquee />
        <Studio />
        <Models />
        <Catalogue />
        <Craft />
        <Specs />
        <Compare />
        <Buy />
      </main>
      <Footer />
      <Bag />
      <AuthModal />
      <AccountDrawer />
      <SettingsPanel />
      <LiveAnnouncer />
    </>
  );
}

export default function App() {
  return (
    <SettingsProvider>
      <StoreProvider>
        <AuthProvider>
          <Site />
        </AuthProvider>
      </StoreProvider>
    </SettingsProvider>
  );
}
