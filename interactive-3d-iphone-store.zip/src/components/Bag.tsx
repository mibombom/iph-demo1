import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, ArrowRight, CheckCircle2, CircleUserRound, Loader2, Lock, Minus, Plus, ShoppingBag, Trash2, X } from "lucide-react";
import { useStore } from "../context/Store";
import { useAuth } from "../context/Auth";
import { fmt } from "../data/products";
import { cn } from "../utils/cn";

function Field({
  id,
  label,
  type = "text",
  placeholder,
  value,
  onChange,
  autoComplete,
  className,
  maxLength,
}: {
  id: string;
  label: string;
  type?: string;
  placeholder?: string;
  value: string;
  onChange: (v: string) => void;
  autoComplete?: string;
  className?: string;
  maxLength?: number;
}) {
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1.5 block text-[12px] font-semibold uppercase tracking-[0.1em] text-ink-faint">
        {label}
      </label>
      <input
        id={id}
        type={type}
        required
        placeholder={placeholder}
        value={value}
        maxLength={maxLength}
        autoComplete={autoComplete}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-2xl border border-line bg-bone px-4 py-3 text-[14.5px] outline-none transition-shadow placeholder:text-ink-faint/60 focus:ring-2 focus:ring-ink"
      />
    </div>
  );
}

export default function Bag() {
  const { state, bagTotal, updateQty, removeItem, closeDrawer, setStep, placeOrder, resetOrder } = useStore();
  const { user, openAuth, recordOrder } = useAuth();
  const [placing, setPlacing] = useState(false);
  const closeRef = useRef<HTMLButtonElement>(null);

  const [form, setForm] = useState({
    email: "",
    name: "",
    address: "",
    city: "",
    zip: "",
    card: "",
    exp: "",
    cvc: "",
  });
  const set = (k: keyof typeof form) => (v: string) => setForm((f) => ({ ...f, [k]: v }));

  // Prefill contact info from the signed-in account
  useEffect(() => {
    if (state.drawerStep === "checkout" && user) {
      setForm((f) => ({
        ...f,
        email: f.email || user.email,
        name: f.name || user.name,
      }));
    }
  }, [state.drawerStep, user]);

  // Scroll lock + escape
  useEffect(() => {
    if (!state.drawerOpen) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeDrawer();
    };
    window.addEventListener("keydown", onKey);
    setTimeout(() => closeRef.current?.focus(), 80);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [state.drawerOpen, closeDrawer]);

  const submitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setPlacing(true);
    const id = `AURA-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
    if (user) {
      recordOrder({
        id,
        date: new Date().toISOString(),
        eta: new Date(Date.now() + 4 * 864e5).toLocaleDateString("en-US", {
          weekday: "long",
          month: "short",
          day: "numeric",
        }),
        total: bagTotal,
        items: state.bag.map((b) => ({
          title: b.title,
          meta: b.meta,
          qty: b.qty,
          unitPrice: b.unitPrice,
          tintA: b.tintA,
          tintB: b.tintB,
        })),
      });
    }
    window.setTimeout(() => {
      placeOrder(id);
      setPlacing(false);
    }, 1500);
  };

  const steps = ["Bag", "Checkout", "Done"];
  const stepIndex = state.drawerStep === "bag" ? 0 : state.drawerStep === "checkout" ? 1 : 2;

  return (
    <AnimatePresence>
      {state.drawerOpen && (
        <>
          <motion.div
            key="scrim"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-[70] bg-ink/45 backdrop-blur-sm"
            onClick={closeDrawer}
            aria-hidden="true"
          />
          <motion.aside
            key="panel"
            role="dialog"
            aria-modal="true"
            aria-label="Shopping bag"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 300 }}
            className="fixed bottom-0 right-0 top-0 z-[80] flex w-full max-w-md flex-col bg-bone shadow-2xl"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-line px-6 py-4">
              <div>
                <h2 className="text-[18px] font-bold tracking-tight">
                  {state.drawerStep === "done" ? "Order confirmed" : state.drawerStep === "checkout" ? "Checkout" : "Your Bag"}
                </h2>
                {/* Step indicator */}
                <div className="mt-1.5 flex items-center gap-1.5" aria-hidden="true">
                  {steps.map((s, i) => (
                    <span
                      key={s}
                      className={cn(
                        "h-1 rounded-full transition-all duration-400",
                        i === stepIndex ? "w-8 bg-accent" : i < stepIndex ? "w-4 bg-ink" : "w-4 bg-ink/15",
                      )}
                    />
                  ))}
                </div>
              </div>
              <button
                ref={closeRef}
                onClick={closeDrawer}
                aria-label="Close bag"
                className="grid size-10 place-items-center rounded-full transition-colors hover:bg-ink/5"
              >
                <X className="size-5" strokeWidth={1.8} />
              </button>
            </div>

            {/* ——— STEP: BAG ——— */}
            {state.drawerStep === "bag" && (
              <>
                <div className="slim-scroll flex-1 overflow-y-auto px-6 py-5">
                  {state.bag.length === 0 ? (
                    <div className="flex h-full flex-col items-center justify-center gap-4 text-center">
                      <span className="grid size-16 place-items-center rounded-full bg-ink/[0.045]">
                        <ShoppingBag className="size-7 text-ink-faint" strokeWidth={1.5} />
                      </span>
                      <div>
                        <p className="text-[16px] font-semibold">Your bag is empty</p>
                        <p className="mt-1 text-[13.5px] text-ink-faint">Configure an iPhone below to begin.</p>
                      </div>
                      <button
                        onClick={() => {
                          closeDrawer();
                          document.getElementById("buy")?.scrollIntoView({ behavior: "smooth" });
                        }}
                        className="rounded-full bg-ink px-6 py-3 text-[13.5px] font-semibold text-bone transition-colors hover:bg-accent"
                      >
                        Start configuring
                      </button>
                    </div>
                  ) : (
                    <ul className="space-y-5">
                      <AnimatePresence initial={false}>
                        {state.bag.map((item) => {
                          const line = item.unitPrice * item.qty;
                          return (
                            <motion.li
                              key={item.key}
                              layout
                              initial={{ opacity: 0, y: 14 }}
                              animate={{ opacity: 1, y: 0 }}
                              exit={{ opacity: 0, x: 40, height: 0, marginBottom: 0 }}
                              className="flex gap-4 rounded-3xl surface p-4 hairline"
                            >
                              <span
                                className="grid size-16 shrink-0 place-items-center rounded-2xl"
                                style={{ background: `linear-gradient(135deg, ${item.tintA}, ${item.tintB})` }}
                                aria-hidden="true"
                              >
                                <span className="size-5 rounded-full border-2 border-black/25" />
                              </span>
                              <div className="min-w-0 flex-1">
                                <p className="truncate text-[14.5px] font-bold">{item.title}</p>
                                <p className="mt-0.5 truncate text-[12px] text-ink-faint">{item.meta}</p>
                                <div className="mt-2.5 flex items-center justify-between">
                                  <div className="flex items-center gap-1 rounded-full bg-ink/[0.05] p-0.5" role="group" aria-label={`Quantity for ${item.title}`}>
                                    <button
                                      onClick={() => updateQty(item.key, item.qty - 1)}
                                      aria-label="Decrease quantity"
                                      className="grid size-7 place-items-center rounded-full transition-colors hover:bg-ink/10"
                                    >
                                      <Minus className="size-3" />
                                    </button>
                                    <span className="w-5 text-center text-[13px] font-semibold" aria-live="polite">
                                      {item.qty}
                                    </span>
                                    <button
                                      onClick={() => updateQty(item.key, item.qty + 1)}
                                      aria-label="Increase quantity"
                                      className="grid size-7 place-items-center rounded-full transition-colors hover:bg-ink/10"
                                    >
                                      <Plus className="size-3" />
                                    </button>
                                  </div>
                                  <p className="text-[14px] font-bold">{fmt(line)}</p>
                                </div>
                              </div>
                              <button
                                onClick={() => removeItem(item.key)}
                                aria-label={`Remove ${item.title} from bag`}
                                className="self-start rounded-full p-1.5 text-ink-faint transition-colors hover:text-accent"
                              >
                                <Trash2 className="size-4" />
                              </button>
                            </motion.li>
                          );
                        })}
                      </AnimatePresence>
                    </ul>
                  )}
                </div>

                {state.bag.length > 0 && (
                  <div className="border-t border-line px-6 py-5">
                    <dl className="space-y-1.5 text-[13.5px]">
                      <div className="flex justify-between text-ink-soft">
                        <dt>Subtotal</dt>
                        <dd>{fmt(bagTotal)}</dd>
                      </div>
                      <div className="flex justify-between text-ink-soft">
                        <dt>Shipping</dt>
                        <dd className="text-emerald-600">Free</dd>
                      </div>
                      <div className="flex justify-between pt-1 text-[17px] font-bold">
                        <dt>Total</dt>
                        <dd>{fmt(bagTotal)}</dd>
                      </div>
                    </dl>
                    <button
                      onClick={() => setStep("checkout")}
                      className="group mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-ink py-4 text-[15px] font-bold text-bone transition-colors hover:bg-accent"
                    >
                      Continue to checkout
                      <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
                    </button>
                  </div>
                )}
              </>
            )}

            {/* ——— STEP: CHECKOUT ——— */}
            {state.drawerStep === "checkout" && (
              <form onSubmit={submitOrder} className="slim-scroll flex flex-1 flex-col overflow-y-auto px-6 py-5">
                <div className="space-y-4">
                  {user ? (
                    <p className="flex items-center gap-2.5 rounded-2xl bg-emerald-500/10 px-4 py-3 text-[12.5px] font-semibold text-emerald-700">
                      <CircleUserRound className="size-4.5 shrink-0" aria-hidden="true" />
                      Checking out as {user.name} — this order will be saved to your account.
                    </p>
                  ) : (
                    <button
                      type="button"
                      onClick={() => openAuth("signin")}
                      className="group flex w-full items-center gap-2.5 rounded-2xl px-4 py-3 text-left text-[12.5px] font-semibold text-ink-soft hairline transition-colors hover:bg-ink hover:text-bone"
                    >
                      <CircleUserRound className="size-4.5 shrink-0 text-accent" aria-hidden="true" />
                      Shopping as guest — sign in for faster checkout and order tracking
                    </button>
                  )}
                  <Field id="ck-email" label="Email" type="email" placeholder="you@example.com" value={form.email} onChange={set("email")} autoComplete="email" />
                  <Field id="ck-name" label="Full name" placeholder="Ava Chen" value={form.name} onChange={set("name")} autoComplete="name" />
                  <Field id="ck-address" label="Address" placeholder="767 Fifth Avenue" value={form.address} onChange={set("address")} autoComplete="street-address" />
                  <div className="grid grid-cols-2 gap-3">
                    <Field id="ck-city" label="City" placeholder="New York" value={form.city} onChange={set("city")} autoComplete="address-level2" />
                    <Field id="ck-zip" label="ZIP" placeholder="10153" value={form.zip} onChange={set("zip")} autoComplete="postal-code" maxLength={10} />
                  </div>
                  <div className="rounded-3xl bg-ink/[0.03] p-4 hairline">
                    <p className="mb-3 flex items-center gap-2 text-[12px] font-semibold uppercase tracking-[0.12em] text-ink-faint">
                      <Lock className="size-3.5" aria-hidden="true" /> Payment — encrypted
                    </p>
                    <div className="space-y-3">
                      <Field id="ck-card" label="Card number" placeholder="4242 4242 4242 4242" value={form.card} onChange={set("card")} autoComplete="cc-number" maxLength={19} />
                      <div className="grid grid-cols-2 gap-3">
                        <Field id="ck-exp" label="Expiry" placeholder="MM / YY" value={form.exp} onChange={set("exp")} autoComplete="cc-exp" maxLength={7} />
                        <Field id="ck-cvc" label="CVC" placeholder="123" value={form.cvc} onChange={set("cvc")} autoComplete="cc-csc" maxLength={4} />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-auto space-y-3 pt-6">
                  <button
                    type="submit"
                    disabled={placing}
                    className="flex w-full items-center justify-center gap-2 rounded-full bg-ink py-4 text-[15px] font-bold text-bone transition-colors hover:bg-accent disabled:opacity-70"
                  >
                    {placing ? (
                      <>
                        <Loader2 className="size-4 animate-spin" aria-hidden="true" />
                        Processing…
                      </>
                    ) : (
                      <>Pay {fmt(bagTotal)}</>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => setStep("bag")}
                    className="flex w-full items-center justify-center gap-2 py-2 text-[13.5px] font-semibold text-ink-soft transition-colors hover:text-ink"
                  >
                    <ArrowLeft className="size-4" aria-hidden="true" />
                    Back to bag
                  </button>
                  <p className="text-center text-[11.5px] text-ink-faint">
                    Concept checkout — no payment is processed.
                  </p>
                </div>
              </form>
            )}

            {/* ——— STEP: DONE ——— */}
            {state.drawerStep === "done" && (
              <div className="flex flex-1 flex-col items-center justify-center gap-5 px-8 text-center">
                <motion.span
                  initial={{ scale: 0.4, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ type: "spring", damping: 14, stiffness: 200 }}
                  className="grid size-20 place-items-center rounded-full bg-emerald-500/12 text-emerald-600"
                >
                  <CheckCircle2 className="size-10" strokeWidth={1.6} />
                </motion.span>
                <div>
                  <p className="text-[22px] font-bold tracking-tight">Thank you{form.name ? `, ${form.name.split(" ")[0]}` : ""}.</p>
                  <p className="mt-2 text-[14px] leading-relaxed text-ink-soft">
                    Your order is confirmed. A receipt is on its way to{" "}
                    <span className="font-semibold text-ink">{form.email || "your inbox"}</span>.
                  </p>
                </div>
                <div className="w-full rounded-3xl bg-ink/[0.04] px-5 py-4">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-ink-faint">Order number</p>
                  <p className="mt-1 font-mono text-[17px] font-bold tracking-wider">{state.orderId}</p>
                  <p className="mt-2 text-[12.5px] text-ink-faint">Arrives in 2 business days — free delivery</p>
                  {user && (
                    <p className="mt-2 flex items-center justify-center gap-1.5 border-t border-ink/10 pt-2.5 text-[12px] font-semibold text-emerald-600">
                      <CircleUserRound className="size-3.5" aria-hidden="true" />
                      Saved to your account — track it under Account → Orders
                    </p>
                  )}
                </div>
                {!user && (
                  <button
                    onClick={() => openAuth("signup")}
                    className="flex w-full items-center justify-center gap-2 rounded-full py-3 text-[13px] font-bold text-ink hairline transition-colors hover:bg-ink hover:text-bone"
                  >
                    <CircleUserRound className="size-4 text-accent" aria-hidden="true" />
                    Create an account to track future orders
                  </button>
                )}
                <button
                  onClick={() => {
                    resetOrder();
                    closeDrawer();
                  }}
                  className="rounded-full bg-ink px-8 py-3.5 text-[14px] font-bold text-bone transition-colors hover:bg-accent"
                >
                  Continue shopping
                </button>
              </div>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
