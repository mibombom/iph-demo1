import { useState } from "react";
import { ArrowUpRight, Info } from "lucide-react";
import { IPHONE_IMAGES } from "../data/catalog";
import { Eyebrow, Reveal } from "./ui/Reveal";

/* ——————————————————————————————————————————————————————————————
   Content adapted from "iphone_picture_catalogue.html" (Google Drive):
   model-by-model picture gallery links, iPhone 11 → 18 Pro Max,
   actual released variants only.
———————————————————————————————————————————————————————————————— */

interface Preview {
  model: string;
  img: string;
  source: string;
  /** Catalog id used for the local fallback photo */
  id: string;
}

interface GalleryRow {
  year: string;
  model: string;
  gallery: string;
}

const PREVIEWS: Preview[] = [
  {
    model: "iPhone 11",
    img: "https://media.tatacroma.com/Croma%20Assets/Communication/Mobiles/Images/230107_6_jf2mq7.png",
    source: "https://www.croma.com/apple-iphone-11-64gb-white-/p/230107",
    id: "iphone-11",
  },
  {
    model: "iPhone 13 mini",
    img: "https://media.ldlc.com/r1600/ld/products/00/05/88/61/LD0005886172_1.jpg",
    source: "https://www.ldlc.com/fiche/PB00460282.html",
    id: "iphone-13-mini",
  },
  {
    model: "iPhone 16 Pro Max",
    img: "https://static01.galaxus.com/productimages/5/9/1/2/4/1/9/2/6/5/8/3/0/9/0/0/6/2/7ff4ca9c-9ea3-4318-b04a-51a391dfaedc_cropped.jpg_sea.jpeg",
    source:
      "https://www.galaxus.de/de/s1/product/apple-iphone-16-pro-max-256-gb-desert-titanium-690-sim-esim-5g-smartphone-49221247",
    id: "iphone-16-pro-max",
  },
  {
    model: "iPhone 18 Pro Max",
    img: "https://www.telia.fi/yrityksille/kauppa/_assets/Products/Devices/Product/Apple/iPhone%2018%20Pro%20Max/apple-iphone-18-pro-max-burgundy-01.png",
    source: "https://www.telia.fi/yrityksille/kauppa/tuote/apple-iphone-18-pro-max",
    id: "iphone-18-pro-max",
  },
];

const GALLERIES: GalleryRow[] = [
  { year: "2019", model: "iPhone 11", gallery: "https://www.gsmarena.com/apple_iphone_11-pictures-9848.php" },
  { year: "2019", model: "iPhone 11 Pro", gallery: "https://www.gsmarena.com/apple_iphone_11_pro-pictures-9847.php" },
  { year: "2019", model: "iPhone 11 Pro Max", gallery: "https://www.gsmarena.com/apple_iphone_11_pro_max-pictures-9891.php" },
  { year: "2020", model: "iPhone 12 mini", gallery: "https://www.gsmarena.com/apple_iphone_12_mini-pictures-10510.php" },
  { year: "2020", model: "iPhone 12", gallery: "https://www.gsmarena.com/apple_iphone_12-pictures-10509.php" },
  { year: "2020", model: "iPhone 12 Pro", gallery: "https://www.gsmarena.com/apple_iphone_12_pro-pictures-10508.php" },
  { year: "2020", model: "iPhone 12 Pro Max", gallery: "https://www.gsmarena.com/apple_iphone_12_pro_max-pictures-10237.php" },
  { year: "2021", model: "iPhone 13 mini", gallery: "https://www.gsmarena.com/apple_iphone_13_mini-pictures-11104.php" },
  { year: "2021", model: "iPhone 13", gallery: "https://www.gsmarena.com/apple_iphone_13-pictures-11103.php" },
  { year: "2021", model: "iPhone 13 Pro", gallery: "https://www.gsmarena.com/apple_iphone_13_pro-pictures-11102.php" },
  { year: "2021", model: "iPhone 13 Pro Max", gallery: "https://www.gsmarena.com/apple_iphone_13_pro_max-pictures-11089.php" },
  { year: "2022", model: "iPhone 14", gallery: "https://www.gsmarena.com/apple_iphone_14-pictures-11861.php" },
  { year: "2022", model: "iPhone 14 Plus", gallery: "https://www.gsmarena.com/apple_iphone_14_plus-pictures-11862.php" },
  { year: "2022", model: "iPhone 14 Pro", gallery: "https://www.gsmarena.com/apple_iphone_14_pro-pictures-11860.php" },
  { year: "2022", model: "iPhone 14 Pro Max", gallery: "https://www.gsmarena.com/apple_iphone_14_pro_max-pictures-11773.php" },
  { year: "2023", model: "iPhone 15", gallery: "https://www.gsmarena.com/apple_iphone_15-pictures-12559.php" },
  { year: "2023", model: "iPhone 15 Plus", gallery: "https://www.gsmarena.com/apple_iphone_15_plus-pictures-12558.php" },
  { year: "2023", model: "iPhone 15 Pro", gallery: "https://www.gsmarena.com/apple_iphone_15_pro-pictures-12557.php" },
  { year: "2023", model: "iPhone 15 Pro Max", gallery: "https://www.gsmarena.com/apple_iphone_15_pro_max-pictures-12548.php" },
  { year: "2024", model: "iPhone 16", gallery: "https://www.gsmarena.com/apple_iphone_16-pictures-13317.php" },
  { year: "2024", model: "iPhone 16 Plus", gallery: "https://www.gsmarena.com/apple_iphone_16_plus-pictures-13316.php" },
  { year: "2024", model: "iPhone 16 Pro", gallery: "https://www.gsmarena.com/apple_iphone_16_pro-pictures-13315.php" },
  { year: "2024", model: "iPhone 16 Pro Max", gallery: "https://www.gsmarena.com/apple_iphone_16_pro_max-pictures-dummylink" },
  { year: "2025", model: "iPhone Air", gallery: "https://www.gsmarena.com/apple_iphone_air-pictures-13903.php" },
  { year: "2025", model: "iPhone 17", gallery: "https://www.gsmarena.com/apple_iphone_17-pictures-13902.php" },
  { year: "2025", model: "iPhone 17 Pro", gallery: "https://www.gsmarena.com/apple_iphone_17_pro-pictures-13901.php" },
  { year: "2025", model: "iPhone 17 Pro Max", gallery: "https://www.gsmarena.com/apple_iphone_17_pro_max-pictures-13900.php" },
  { year: "2026", model: "iPhone 17e", gallery: "https://www.gsmarena.com/apple_iphone_17e-pictures-13920.php" },
  {
    year: "2026",
    model: "iPhone 18 Pro",
    gallery: "https://www.apple.com/newsroom/2026/09/apple-debuts-iphone-18-pro-and-iphone-18-pro-max/",
  },
  {
    year: "2026",
    model: "iPhone 18 Pro Max",
    gallery: "https://www.apple.com/newsroom/2026/09/apple-debuts-iphone-18-pro-and-iphone-18-pro-max/",
  },
];

const APPLE_COMPARE = "https://www.apple.com/iphone/compare/";
const APPLE_18 =
  "https://www.apple.com/newsroom/2026/09/apple-debuts-iphone-18-pro-and-iphone-18-pro-max/";

function PreviewCard({ p, index }: { p: Preview; index: number }) {
  const [failed, setFailed] = useState(false);
  const fallback = IPHONE_IMAGES[p.id];
  return (
    <Reveal delay={index * 0.07} className="h-full">
      <article className="card-lift surface hairline flex h-full flex-col rounded-[24px] p-3">
        <a
          href={p.source}
          target="_blank"
          rel="noopener noreferrer"
          className="group block overflow-hidden rounded-[16px] bg-white"
          aria-label={`${p.model} — open source image page`}
        >
          {failed && !fallback ? (
            <div className="grid aspect-[4/3] place-items-center bg-gradient-to-br from-ink/[0.05] to-ink/[0.12]">
              <span className="text-[12px] font-semibold text-ink-faint">Preview unavailable</span>
            </div>
          ) : (
            <img
              src={failed ? fallback : p.img}
              alt={`${p.model} authentic product image`}
              loading="lazy"
              referrerPolicy="no-referrer"
              onError={() => setFailed(true)}
              className="aspect-[4/3] w-full object-contain transition-transform duration-700 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.05]"
            />
          )}
        </a>
        <div className="flex flex-1 flex-col px-2 pb-1 pt-3">
          <h3 className="text-[15px] font-bold tracking-tight">{p.model}</h3>
          <p className="mt-0.5 text-[12px] text-ink-faint">Open source image page</p>
          <a
            href={p.source}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-2 inline-flex items-center gap-1 text-[12.5px] font-semibold text-accent hover:underline"
          >
            View source
            <ArrowUpRight className="size-3.5" aria-hidden="true" />
          </a>
        </div>
      </article>
    </Reveal>
  );
}

export default function Catalogue() {
  return (
    <section
      id="catalogue"
      className="scroll-mt-16 bg-bone-deep py-24 md:py-32"
      aria-labelledby="catalogue-title"
    >
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="max-w-3xl">
          <Reveal>
            <Eyebrow>Picture catalogue</Eyebrow>
          </Reveal>
          <Reveal delay={0.06}>
            <h2
              id="catalogue-title"
              className="display-tight mt-4 text-[11vw] font-bold sm:text-6xl md:text-7xl"
            >
              iPhone 11 to 18 Pro Max,{" "}
              <span className="serif-accent font-normal">in pictures.</span>
            </h2>
          </Reveal>
          <Reveal delay={0.12}>
            <p className="mt-5 max-w-2xl text-[15px] text-ink-soft">
              Model-by-model picture gallery links — actual released variants only. Ported
              from the iPhone Picture Catalogue.
            </p>
          </Reveal>
        </div>

        <Reveal delay={0.16} className="mt-8">
          <div className="surface hairline flex items-start gap-3 rounded-[22px] p-5">
            <Info className="mt-0.5 size-4.5 shrink-0 text-accent" aria-hidden="true" />
            <p className="text-[13px] leading-relaxed text-ink-soft">
              <strong className="font-semibold text-ink">How to use:</strong> sample product
              images load from their source websites when you have internet access. Use
              “Open picture gallery” to see more product images for each model. Images are
              hosted by their respective source websites; this is an independent reference
              catalogue, not an Apple publication.
            </p>
          </div>
        </Reveal>

        {/* Product picture previews */}
        <div
          className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4"
          role="list"
          aria-label="Product picture previews"
        >
          {PREVIEWS.map((p, i) => (
            <div role="listitem" key={p.model} className="h-full">
              <PreviewCard p={p} index={i} />
            </div>
          ))}
        </div>

        {/* All released variants */}
        <Reveal delay={0.1} className="mt-14">
          <h3 className="text-[22px] font-bold tracking-tight">
            All released model variants in this range
          </h3>
          <p className="mt-2 max-w-2xl text-[14px] leading-relaxed text-ink-soft">
            Not every generation had a mini or Air version. The table lists actual models and
            links to picture galleries or Apple’s official announcement.
          </p>
        </Reveal>

        <Reveal delay={0.14} className="mt-6">
          <div
            className="slim-scroll overflow-x-auto rounded-[28px] border border-line"
            tabIndex={0}
            role="region"
            aria-label="iPhone picture gallery links, scroll horizontally"
          >
            <table className="w-full min-w-[560px] border-collapse text-left">
              <thead>
                <tr className="border-b border-line">
                  <th scope="col" className="w-28 p-5 align-bottom">
                    <span className="eyebrow text-ink-faint">Year</span>
                  </th>
                  <th scope="col" className="p-5 align-bottom">
                    <span className="eyebrow text-ink-faint">iPhone model</span>
                  </th>
                  <th scope="col" className="p-5 align-bottom">
                    <span className="eyebrow text-ink-faint">Pictures</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {GALLERIES.map((row, i) => {
                  const thumb = IPHONE_IMAGES[row.model.toLowerCase().replace(/\s+/g, "-")];
                  return (
                    <tr key={row.model} className={i % 2 ? "bg-ink/[0.025]" : ""}>
                      <td className="p-5 align-top text-[13px] font-medium text-ink-faint">
                        {row.year}
                      </td>
                      <th scope="row" className="p-5 align-top text-[14px] font-semibold">
                        <span className="flex items-center gap-3">
                          {thumb && (
                            <img
                              src={thumb}
                              alt=""
                              aria-hidden="true"
                              loading="lazy"
                              className="size-10 shrink-0 rounded-lg bg-white object-contain p-0.5"
                            />
                          )}
                          {row.model}
                        </span>
                      </th>
                      <td className="p-5 align-top">
                        <a
                          href={row.gallery}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-[13px] font-semibold text-accent hover:underline"
                        >
                          Open picture gallery
                          <ArrowUpRight className="size-3.5" aria-hidden="true" />
                        </a>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Reveal>

        <Reveal delay={0.1} className="mt-8">
          <p className="text-[12.5px] leading-relaxed text-ink-faint">
            Official Apple reference:{" "}
            <a
              className="font-semibold text-accent hover:underline"
              href={APPLE_COMPARE}
              target="_blank"
              rel="noopener noreferrer"
            >
              Compare iPhone models
            </a>
            {" · "}
            <a
              className="font-semibold text-accent hover:underline"
              href={APPLE_18}
              target="_blank"
              rel="noopener noreferrer"
            >
              Apple’s iPhone 18 Pro announcement
            </a>
            {" · "}
            <a
              className="font-semibold text-accent hover:underline"
              href="/iphone-picture-catalogue.html"
              target="_blank"
              rel="noopener noreferrer"
            >
              Open the standalone catalogue file
            </a>
            <br />
            Images and gallery links belong to their respective publishers. Product lineups
            may vary by region.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
