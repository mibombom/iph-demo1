import { useMemo, useRef, useState } from "react";
import { AnimatePresence, LayoutGroup, motion, useReducedMotion } from "framer-motion";
import { ArrowUpRight, ChevronLeft, ChevronRight, Cpu, Plus, Sparkles } from "lucide-react";
import { useStore } from "../context/Store";
import { CATALOG, CATEGORIES, GENERATIONS, type Category, type CatalogProduct } from "../data/catalog";
import { fmt, MODELS } from "../data/products";
import { scrollToId } from "../lib/scroll";
import { cn } from "../utils/cn";
import ProductTile from "./ProductTile";
import { Eyebrow, Reveal } from "./ui/Reveal";

const spring = { type: "spring", stiffness: 380, damping: 34, mass: 0.85 } as const;
const easeOut = [0.22, 1, 0.36, 1] as const;

/* ————————————————— Spotlight strip (photography) ————————————————— */

const SPOTLIGHT = [
  { model: MODELS[0], kicker: "New" },
  { model: MODELS[3], kicker: "Thinnest ever" },
  { model: MODELS[2], kicker: "For everyone" },
];

function Spotlight() {
  const { setModel } = useStore();
  const trackRef = useRef<HTMLDivElement>(null);
  const nudge = (dir: number) => {
    trackRef.current?.scrollBy({ left: dir * 320, behavior: "smooth" });
  };

  return (
    <div className="relative">
      <div
        ref={trackRef}
        className="slim-scroll flex snap-x snap-mandatory gap-4 overflow-x-auto pb-2 lg:grid lg:grid-cols-3 lg:overflow-visible"
        role="list"
        aria-label="Featured products"
      >
        {SPOTLIGHT.map(({ model: m, kicker }, i) => (
          <motion.article
            key={m.id}
            role="listitem"
            initial={{ opacity: 0, y: 34 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.85, delay: i * 0.09, ease: easeOut }}
            className="card-lift group relative min-w-[300px] snap-start overflow-hidden rounded-[28px] sm:min-w-[340px] lg:min-w-0"
            style={{ background: m.cardTone }}
          >
            <button
              className="relative block aspect-[16/10] w-full overflow-hidden text-left"
              onClick={() => {
                setModel(m.id);
                scrollToId("buy");
              }}
              aria-label={`Configure ${m.name}`}
            >
              <img
                src={m.image}
                alt={m.imageAlt}
                loading="lazy"
                className="absolute inset-0 size-full object-cover transition-transform duration-[1400ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.06]"
              />
              <span className="absolute inset-0 bg-gradient-to-t from-black/45 via-black/0 to-black/0" aria-hidden="true" />
              <span className="absolute left-4 top-4 rounded-full bg-white/85 px-3 py-1 text-[11px] font-bold uppercase tracking-[0.14em] text-[#141417] backdrop-blur-md">
                {kicker}
              </span>
              <span className="absolute bottom-4 left-5 right-5 flex items-end justify-between gap-3 text-white">
                <span>
                  <span className="block text-[22px] font-bold tracking-tight">{m.name}</span>
                  <span className="block text-[12.5px] text-white/75">
                    {m.chipShort} · From {fmt(m.base)}
                  </span>
                </span>
                <span className="grid size-10 shrink-0 place-items-center rounded-full bg-white text-ink transition-transform duration-500 group-hover:scale-110 group-hover:bg-accent group-hover:text-white">
                  <ArrowUpRight className="size-5" aria-hidden="true" />
                </span>
              </span>
            </button>
          </motion.article>
        ))}
      </div>

      <div className="mt-3 flex justify-end gap-2 lg:hidden" aria-hidden="true">
        <button onClick={() => nudge(-1)} tabIndex={-1} className="grid size-9 place-items-center rounded-full hairline">
          <ChevronLeft className="size-4" />
        </button>
        <button onClick={() => nudge(1)} tabIndex={-1} className="grid size-9 place-items-center rounded-full hairline">
          <ChevronRight className="size-4" />
        </button>
      </div>
    </div>
  );
}

/* ————————————————— Product card ————————————————— */

function ProductCard({ product, index }: { product: CatalogProduct; index: number }) {
  const { setModel, configureProduct } = useStore();
  const reduce = useReducedMotion();
  const tint = product.colors[0];

  const routeToConfigure = () => {
    // Current-generation iPhones open in the full studio configurator,
    // everything else enters quick-configure mode inside the same section.
    const flagship = MODELS.find((m) => m.name === product.name);
    if (flagship) setModel(flagship.id);
    else configureProduct(product.id);
    scrollToId("buy");
  };

  return (
    <motion.li
      layout
      initial={{ opacity: 0, scale: 0.9, y: reduce ? 0 : 26 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.88, transition: { duration: 0.22, ease: "easeIn" } }}
      transition={{ ...spring, delay: reduce ? 0 : Math.min(index * 0.028, 0.42) }}
      className="group relative flex flex-col overflow-hidden rounded-[26px] p-5 transition-[box-shadow] duration-500 hover:shadow-[0_30px_60px_-26px_rgba(20,20,23,0.35)]"
      style={{ background: `color-mix(in srgb, ${tint} 15%, var(--color-bone))` }}
    >
      {/* Condition badge */}
      {product.condition !== "New" && (
        <span
          className={cn(
            "absolute left-4 top-4 z-10 rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.14em] backdrop-blur-sm",
            product.condition === "Concept" ? "bg-ink text-bone" : "surface text-ink-soft",
          )}
        >
          {product.condition === "Concept" ? "Concept" : "Renewed"}
        </span>
      )}

      {/* Quick add */}
      <motion.button
        onClick={routeToConfigure}
        aria-label={`Configure ${product.name} — from ${fmt(product.price)}`}
        whileTap={{ scale: 0.82 }}
        className="absolute right-4 top-4 z-10 grid size-9 place-items-center rounded-full surface text-ink opacity-100 shadow-sm backdrop-blur-sm transition-all duration-300 hover:bg-ink hover:text-bone lg:opacity-0 lg:group-hover:opacity-100"
      >
        <Plus className="size-4.5" strokeWidth={2.2} aria-hidden="true" />
      </motion.button>

      {/* Artwork */}
      <div className="grid h-44 place-items-center">
        <ProductTile
          product={product}
          className="h-full w-auto drop-shadow-[0_18px_22px_rgba(20,20,23,0.18)] transition-transform duration-700 ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:-translate-y-1.5 group-hover:rotate-[-2.5deg]"
        />
      </div>

      {/* Meta */}
      <div className="mt-auto pt-4">
        <h3 className="text-[15.5px] font-bold tracking-tight">{product.name}</h3>
        <p className="mt-1 flex items-center gap-1.5 text-[12px] text-ink-faint">
          <Cpu className="size-3" aria-hidden="true" />
          {product.chip} · {product.info}
        </p>

        <div className="mt-3.5 flex items-center justify-between border-t border-ink/10 pt-3.5">
          <div className="flex items-center gap-1.5" aria-label={`Available in ${product.colorNames.join(", ")}`}>
            {product.colors.map((c, i) => (
              <span
                key={i}
                title={product.colorNames[i]}
                className="size-3.5 rounded-full ring-1 ring-black/15"
                style={{ background: c }}
              />
            ))}
          </div>
          <p className="text-right">
            <span className="block text-[14.5px] font-bold leading-none">{fmt(product.price)}</span>
            <span className="mt-0.5 block text-[10.5px] text-ink-faint">
              {fmt(Math.round((product.price / 24) * 100) / 100)}/mo
            </span>
          </p>
        </div>
      </div>
    </motion.li>
  );
}

/* ————————————————— Catalog section ————————————————— */

export default function Models() {
  const [category, setCategory] = useState<Category | "all">("all");
  const [gen, setGen] = useState<number | "all">("all");
  const reduce = useReducedMotion();

  const products = useMemo(
    () =>
      CATALOG.filter((p) => {
        if (category !== "all" && p.category !== category) return false;
        if (gen !== "all") return p.generation === gen;
        return true;
      }),
    [category, gen],
  );

  const activeGen = gen === "all" ? null : GENERATIONS.find((g) => g.gen === gen);

  return (
    <section id="models" className="scroll-mt-16 py-24 md:py-32" aria-labelledby="models-title">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        {/* Heading */}
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <Reveal>
              <Eyebrow>The Catalog</Eyebrow>
            </Reveal>
            <Reveal delay={0.08}>
              <h2 id="models-title" className="display-tight mt-4 text-[11vw] font-bold sm:text-6xl md:text-7xl">
                Every era.
                <br />
                <span className="serif-accent text-ink-soft">Every expression.</span>
              </h2>
            </Reveal>
          </div>
          <Reveal delay={0.15}>
            <p className="max-w-sm pb-1 text-[14.5px] leading-relaxed text-ink-soft">
              iPhone 11 through the new iPhone 18 — every mini, Plus, Pro, Pro Max
              and Air — alongside the watches, Macs, iPads and accessories built
              to travel with them.
            </p>
          </Reveal>
        </div>

        {/* Spotlight */}
        <div className="mt-12">
          <Reveal>
            <p className="eyebrow mb-4 flex items-center gap-2 text-ink-faint">
              <Sparkles className="size-3.5 text-accent" aria-hidden="true" /> Spotlight
            </p>
          </Reveal>
          <Spotlight />
        </div>

        {/* ——— Filters ——— */}
        <LayoutGroup>
          <div className="sticky top-16 z-30 -mx-5 mt-12 px-5 py-3 md:mx-0 md:px-0">
            <div
              role="tablist"
              aria-label="Product categories"
              className="flex w-full gap-1 overflow-x-auto rounded-full p-1 glass-nav hairline slim-scroll md:w-fit"
            >
              {CATEGORIES.map((c) => {
                const active = category === c.id;
                return (
                  <button
                    key={c.id}
                    role="tab"
                    aria-selected={active}
                    onClick={() => {
                      setCategory(c.id);
                      setGen("all");
                    }}
                    className={cn(
                      "relative shrink-0 rounded-full px-5 py-2.5 text-[13.5px] font-semibold transition-colors duration-300",
                      active ? "text-bone" : "text-ink-soft hover:text-ink",
                    )}
                  >
                    {active && (
                      <motion.span
                        layoutId="cat-pill"
                        className="absolute inset-0 rounded-full bg-ink"
                        transition={spring}
                      />
                    )}
                    <span className="relative z-10">{c.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Generation rail */}
          <AnimatePresence initial={false}>
            {(category === "iphone" || category === "all") && (
              <motion.div
                key="gen-rail"
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.45, ease: easeOut }}
                className="overflow-hidden"
              >
                <div className="mt-5 flex items-center gap-2 overflow-x-auto pb-1 slim-scroll" role="group" aria-label="Filter by iPhone generation">
                  <span className="mr-1 shrink-0 text-[11px] font-bold uppercase tracking-[0.18em] text-ink-faint">
                    iPhone
                  </span>
                  {GENERATIONS.map((g) => {
                    const active = gen === g.gen;
                    return (
                      <button
                        key={g.gen}
                        onClick={() => setGen(active ? "all" : g.gen)}
                        aria-pressed={active}
                        className={cn(
                          "relative grid size-12 shrink-0 place-items-center rounded-2xl text-[15px] font-bold transition-colors duration-300",
                          active ? "text-bone" : "bg-ink/[0.045] text-ink-soft hover:bg-ink/10 hover:text-ink",
                        )}
                      >
                        {active && (
                          <motion.span
                            layoutId="gen-pill"
                            className="absolute inset-0 rounded-2xl bg-ink"
                            transition={spring}
                          />
                        )}
                        <span className="relative z-10">{g.gen}</span>
                      </button>
                    );
                  })}
                  {gen !== "all" && (
                    <button
                      onClick={() => setGen("all")}
                      className="shrink-0 rounded-full px-4 py-2 text-[12.5px] font-semibold text-accent underline-offset-4 hover:underline"
                    >
                      Reset
                    </button>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </LayoutGroup>

        {/* Era banner */}
        <div className="mt-8 flex min-h-12 items-end justify-between gap-4 overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.h3
              key={`${category}-${gen}`}
              initial={{ y: reduce ? 0 : 26, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: reduce ? 0 : -20, opacity: 0 }}
              transition={{ duration: 0.5, ease: easeOut }}
              className="display-tight text-[26px] font-bold sm:text-[34px]"
            >
              {activeGen ? (
                <>
                  iPhone {activeGen.gen} <span className="serif-accent font-normal text-ink-faint">· {activeGen.year}</span>
                </>
              ) : (
                <>Browse everything <span className="serif-accent font-normal text-accent">({products.length})</span></>
              )}
            </motion.h3>
          </AnimatePresence>
          <p className="hidden shrink-0 pb-1 text-[12.5px] text-ink-faint sm:block" aria-live="polite">
            {products.length} product{products.length === 1 ? "" : "s"}
          </p>
        </div>

        {/* ——— Animated grid ——— */}
        <motion.ul layout className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          <AnimatePresence mode="popLayout" initial={false}>
            {products.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </AnimatePresence>
        </motion.ul>
      </div>
    </section>
  );
}
