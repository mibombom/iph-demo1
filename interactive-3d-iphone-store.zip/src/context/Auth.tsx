import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export interface OrderLine {
  title: string;
  meta: string;
  qty: number;
  unitPrice: number;
  tintA: string;
  tintB: string;
}

export interface OrderRecord {
  id: string;
  date: string;
  eta: string;
  total: number;
  items: OrderLine[];
}

export interface UserProfile {
  name: string;
  email: string;
  joinedAt: string;
}

interface StoredUser extends UserProfile {
  /** Demo-grade obfuscation only — not real cryptography */
  secret: string;
}

export type AuthView = "signin" | "signup";

interface AuthApi {
  user: UserProfile | null;
  orders: OrderRecord[];
  authOpen: boolean;
  authView: AuthView;
  accountOpen: boolean;
  openAuth: (view?: AuthView) => void;
  closeAuth: () => void;
  openAccount: () => void;
  closeAccount: () => void;
  signUp: (name: string, email: string, password: string) => string | null;
  signIn: (email: string, password: string) => string | null;
  signOut: () => void;
  recordOrder: (order: OrderRecord) => void;
}

const LS_USERS = "aura-users";
const LS_SESSION = "aura-session";
const ordersKey = (email: string) => `aura-orders:${email.toLowerCase()}`;

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage unavailable — session only */
  }
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function seedIfEmpty() {
  const users = read<StoredUser[]>(LS_USERS, []);
  if (users.length > 0) return;
  const demo: StoredUser = {
    name: "Ava Chen",
    email: "ava@demo.aura",
    joinedAt: new Date(Date.now() - 96 * 864e5).toISOString(),
    secret: "ZGVtbzEyMzQ=", // demo1234
  };
  write(LS_USERS, [demo]);
  const past = new Date(Date.now() - 9 * 864e5);
  const eta = new Date(Date.now() + 3 * 864e5);
  write(ordersKey(demo.email), [
    {
      id: "AURA-7KQ2MD",
      date: past.toISOString(),
      eta: eta.toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" }),
      total: 1338,
      items: [
        {
          title: "iPhone 17 Pro",
          meta: "Deep Blue · A19 Pro · 512GB",
          qty: 1,
          unitPrice: 1299,
          tintA: "#4b5976",
          tintB: "#39445c",
        },
        {
          title: "MagSafe Charger",
          meta: "White · 25W wireless",
          qty: 1,
          unitPrice: 39,
          tintA: "#f4f4f6",
          tintB: "#dcdce0",
        },
      ],
    } satisfies OrderRecord,
  ]);
}

const AuthContext = createContext<AuthApi | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [orders, setOrders] = useState<OrderRecord[]>([]);
  const [authOpen, setAuthOpen] = useState(false);
  const [authView, setAuthView] = useState<AuthView>("signin");
  const [accountOpen, setAccountOpen] = useState(false);

  useEffect(() => {
    seedIfEmpty();
    const email = read<string | null>(LS_SESSION, null);
    if (email) {
      const found = read<StoredUser[]>(LS_USERS, []).find(
        (u) => u.email.toLowerCase() === email.toLowerCase(),
      );
      if (found) {
        const { secret: _secret, ...profile } = found;
        setUser(profile);
        setOrders(read<OrderRecord[]>(ordersKey(found.email), []));
      }
    }
  }, []);

  const loadSession = useCallback((profile: UserProfile) => {
    setUser(profile);
    write(LS_SESSION, profile.email);
    setOrders(read<OrderRecord[]>(ordersKey(profile.email), []));
  }, []);

  const signUp = useCallback(
    (name: string, email: string, password: string): string | null => {
      const clean = name.trim();
      if (clean.length < 2) return "Please enter your full name.";
      if (!EMAIL_RE.test(email)) return "That email address doesn't look right.";
      if (password.length < 8) return "Password needs at least 8 characters.";
      const users = read<StoredUser[]>(LS_USERS, []);
      if (users.some((u) => u.email.toLowerCase() === email.toLowerCase()))
        return "That email already has an account — try signing in.";
      const profile: UserProfile = { name: clean, email: email.toLowerCase(), joinedAt: new Date().toISOString() };
      users.push({ ...profile, secret: btoa(password) });
      write(LS_USERS, users);
      loadSession(profile);
      return null;
    },
    [loadSession],
  );

  const signIn = useCallback(
    (email: string, password: string): string | null => {
      if (!EMAIL_RE.test(email)) return "That email address doesn't look right.";
      const found = read<StoredUser[]>(LS_USERS, []).find(
        (u) => u.email.toLowerCase() === email.toLowerCase(),
      );
      if (!found) return "No account found with that email.";
      if (found.secret !== btoa(password)) return "Incorrect password — try again.";
      const { secret: _secret, ...profile } = found;
      loadSession(profile);
      return null;
    },
    [loadSession],
  );

  const signOut = useCallback(() => {
    setUser(null);
    setOrders([]);
    write(LS_SESSION, null);
  }, []);

  const recordOrder = useCallback(
    (order: OrderRecord) => {
      if (!user) return;
      setOrders((prev) => {
        const next = [order, ...prev];
        write(ordersKey(user.email), next);
        return next;
      });
    },
    [user],
  );

  const api = useMemo<AuthApi>(
    () => ({
      user,
      orders,
      authOpen,
      authView,
      accountOpen,
      openAuth: (view = "signin") => {
        setAuthView(view);
        setAuthOpen(true);
      },
      closeAuth: () => setAuthOpen(false),
      openAccount: () => setAccountOpen(true),
      closeAccount: () => setAccountOpen(false),
      signUp,
      signIn,
      signOut,
      recordOrder,
    }),
    [user, orders, authOpen, authView, accountOpen, signUp, signIn, signOut, recordOrder],
  );

  return <AuthContext.Provider value={api}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
